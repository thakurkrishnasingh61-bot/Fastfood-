import { HospitalItem } from '../types';

const DB_NAME = 'FastMedCab_DB';
const DB_VERSION = 1;
const STORE_NAME = 'imported_hospitals';

// Open or create IndexedDB
function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      return reject(new Error('IndexedDB not supported'));
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open IndexedDB'));
  });
}

// Save hospital items to IndexedDB (handles thousands of records without localStorage quota limits)
export async function saveHospitalsToIndexedDB(hospitals: HospitalItem[]): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);

      // Clear previous and put new
      store.clear();
      for (const hosp of hospitals) {
        store.put(hosp);
      }

      tx.oncomplete = () => {
        db.close();
        resolve();
      };

      tx.onerror = () => {
        db.close();
        reject(tx.error || new Error('Transaction failed'));
      };
    });
  } catch (err) {
    console.warn('Could not persist to IndexedDB (using memory only):', err);
  }
}

// Load hospital items from IndexedDB
export async function loadHospitalsFromIndexedDB(): Promise<HospitalItem[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const request = store.getAll();

      request.onsuccess = () => {
        db.close();
        resolve(request.result || []);
      };

      request.onerror = () => {
        db.close();
        reject(request.error || new Error('Failed to fetch from store'));
      };
    });
  } catch (err) {
    console.warn('Could not load from IndexedDB:', err);
    return [];
  }
}

// Clear stored hospitals
export async function clearHospitalsFromIndexedDB(): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      store.clear();

      tx.oncomplete = () => {
        db.close();
        resolve();
      };

      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    });
  } catch (err) {
    console.warn('Could not clear IndexedDB:', err);
  }
}
