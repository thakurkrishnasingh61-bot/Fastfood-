import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { FastMedCabNavbar } from './components/FastMedCabNavbar';
import { FastMedCabHero } from './components/FastMedCabHero';
import { QuickSearch } from './components/QuickSearch';
import { ServiceDirectory } from './components/ServiceDirectory';
import { HowItWorks } from './components/HowItWorks';
import { WhyUs } from './components/WhyUs';
import { FirstAidGuide } from './components/FirstAidGuide';
import { FastMedCabFooter } from './components/FastMedCabFooter';

// Modals
import { SosModal } from './components/SosModal';
import { AmbulanceDispatchModal } from './components/AmbulanceDispatchModal';
import { AmbulanceTrackerModal } from './components/AmbulanceTrackerModal';
import { BloodRequestModal } from './components/BloodRequestModal';
import { AyushmanInsuranceModal } from './components/AyushmanInsuranceModal';
import { HospitalDetailModal } from './components/HospitalDetailModal';
import { AuthModal } from './components/AuthModal';

// Types & Data
import { 
  ServiceCategory, 
  BloodGroup, 
  HospitalItem, 
  AmbulanceItem, 
  BloodDonorItem, 
  DoctorItem, 
  PharmacyItem, 
  DiagnosticLabItem 
} from './types';
import { 
  HOSPITALS_DATA, 
  AMBULANCES_DATA, 
  BLOOD_DONORS_DATA, 
  DOCTORS_DATA, 
  PHARMACIES_DATA, 
  LABS_DATA,
  deduplicateById
} from './data/mockData';
import { generateCityEmergencyFacilities } from './data/cityEmergencyEngine';
import { ShieldAlert, Ambulance, Map, PhoneCall } from 'lucide-react';
import { 
  saveHospitalsToIndexedDB, 
  loadHospitalsFromIndexedDB, 
  clearHospitalsFromIndexedDB 
} from './utils/hospitalDb';

export default function App() {
  // Navigation & Category state
  const [activeCategory, setActiveCategory] = useState<ServiceCategory>('hospital');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [isHindi, setIsHindi] = useState(false);

  // Search & Filter state
  const [searchLocation, setSearchLocation] = useState<string>('All India');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedState, setSelectedState] = useState<string>('ALL');
  const [selectedTier, setSelectedTier] = useState<string>('ALL');
  const [ayushmanOnly, setAyushmanOnly] = useState<boolean>(false);
  const [filter247, setFilter247] = useState<boolean>(false);
  const [selectedBloodGroup, setSelectedBloodGroup] = useState<BloodGroup | 'ALL'>('ALL');

  // Modal states
  const [isSosOpen, setIsSosOpen] = useState<boolean>(false);
  const [isAmbulanceDispatchOpen, setIsAmbulanceDispatchOpen] = useState<boolean>(false);
  const [isAmbulanceTrackerOpen, setIsAmbulanceTrackerOpen] = useState<boolean>(false);
  const [trackedAmbulance, setTrackedAmbulance] = useState<AmbulanceItem | null>(null);
  const [isBloodModalOpen, setIsBloodModalOpen] = useState<boolean>(false);
  const [isAyushmanModalOpen, setIsAyushmanModalOpen] = useState<boolean>(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [selectedHospitalForModal, setSelectedHospitalForModal] = useState<HospitalItem | null>(null);

  // Dynamic live data state
  const [customHospitals, setCustomHospitals] = useState<HospitalItem[]>([]);
  const [hospitalsList, setHospitalsList] = useState<HospitalItem[]>(HOSPITALS_DATA);
  const [ambulancesList, setAmbulancesList] = useState<AmbulanceItem[]>(AMBULANCES_DATA);
  const [bloodDonorsList, setBloodDonorsList] = useState<BloodDonorItem[]>(BLOOD_DONORS_DATA);
  const [doctorsList, setDoctorsList] = useState<DoctorItem[]>(DOCTORS_DATA);
  const [pharmaciesList, setPharmaciesList] = useState<PharmacyItem[]>(PHARMACIES_DATA);
  const [labsList, setLabsList] = useState<DiagnosticLabItem[]>(LABS_DATA);
  const [isLoadingLiveLocation, setIsLoadingLiveLocation] = useState<boolean>(false);

  // Load custom hospitals asynchronously from IndexedDB on startup & clear any quota-busting localStorage
  useEffect(() => {
    try {
      localStorage.removeItem('fastmedcab_custom_hospitals');
    } catch {
      // ignore
    }

    loadHospitalsFromIndexedDB()
      .then(saved => {
        if (saved && saved.length > 0) {
          setCustomHospitals(saved);
          setHospitalsList(prev => deduplicateById([...saved, ...prev]));
        }
      })
      .catch(err => {
        console.warn('Could not load hospitals from IndexedDB:', err);
      });
  }, []);

  const handleImportHospitals = useCallback((newHospitals: HospitalItem[]) => {
    setCustomHospitals(prev => {
      const merged = deduplicateById([...newHospitals, ...prev]);
      // Save asynchronously to IndexedDB (virtually unlimited quota, no localStorage failure)
      saveHospitalsToIndexedDB(merged).catch(err => {
        console.warn('Failed to save hospitals to IndexedDB:', err);
      });
      return merged;
    });

    setHospitalsList(prev => deduplicateById([...newHospitals, ...prev]));
  }, []);

  const handleClearCustomHospitals = useCallback(() => {
    setCustomHospitals([]);
    clearHospitalsFromIndexedDB().catch(console.warn);
    try {
      localStorage.removeItem('fastmedcab_custom_hospitals');
    } catch {
      // ignore
    }
    setHospitalsList(HOSPITALS_DATA);
  }, []);

  // Dynamic city / village emergency generation and live Overpass fetch
  useEffect(() => {
    const loc = searchLocation.trim();
    if (!loc || loc.toLowerCase() === 'all india') {
      setHospitalsList(deduplicateById([...customHospitals, ...HOSPITALS_DATA]));
      setAmbulancesList(AMBULANCES_DATA);
      setBloodDonorsList(BLOOD_DONORS_DATA);
      setDoctorsList(DOCTORS_DATA);
      setPharmaciesList(PHARMACIES_DATA);
      setLabsList(LABS_DATA);
      return;
    }

    // Generate local emergency infrastructure for this city / village
    const proceduralFacilities = generateCityEmergencyFacilities(loc, selectedState !== 'ALL' ? selectedState : undefined);

    let isSubscribed = true;
    setIsLoadingLiveLocation(true);

    // Call live village & town hospital API in background
    fetch(`/api/live-village-hospitals?q=${encodeURIComponent(loc)}&state=${encodeURIComponent(selectedState)}`)
      .then(res => res.json())
      .then(data => {
        if (!isSubscribed) return;
        if (data && data.success && Array.isArray(data.hospitals) && data.hospitals.length > 0) {
          // Keep core verified hospitals and merge live hospitals
          setHospitalsList(deduplicateById([...customHospitals, ...HOSPITALS_DATA, ...data.hospitals]));
        } else {
          setHospitalsList(deduplicateById([...customHospitals, ...HOSPITALS_DATA, ...proceduralFacilities.hospitals]));
        }
        setAmbulancesList(deduplicateById(proceduralFacilities.ambulances));
        setBloodDonorsList(deduplicateById(proceduralFacilities.bloodDonors));
        setDoctorsList(deduplicateById(proceduralFacilities.doctors));
        setPharmaciesList(deduplicateById(proceduralFacilities.pharmacies));
        setLabsList(deduplicateById(proceduralFacilities.labs));
      })
      .catch(() => {
        if (!isSubscribed) return;
        setHospitalsList(deduplicateById([...customHospitals, ...HOSPITALS_DATA, ...proceduralFacilities.hospitals]));
        setAmbulancesList(deduplicateById(proceduralFacilities.ambulances));
        setBloodDonorsList(deduplicateById(proceduralFacilities.bloodDonors));
        setDoctorsList(deduplicateById(proceduralFacilities.doctors));
        setPharmaciesList(deduplicateById(proceduralFacilities.pharmacies));
        setLabsList(deduplicateById(proceduralFacilities.labs));
      })
      .finally(() => {
        if (isSubscribed) {
          setIsLoadingLiveLocation(false);
        }
      });

    return () => {
      isSubscribed = false;
    };
  }, [searchLocation, selectedState, customHospitals]);

  // Handlers for Tracking & Booking
  const handleStartTracking = useCallback((amb: AmbulanceItem) => {
    setTrackedAmbulance(amb);
    setIsAmbulanceDispatchOpen(false);
    setIsAmbulanceTrackerOpen(true);
  }, []);

  const handleTrackFromDirectory = useCallback((amb: AmbulanceItem) => {
    setTrackedAmbulance(amb);
    setIsAmbulanceTrackerOpen(true);
  }, []);

  const handleAddDonor = useCallback((newDonor: BloodDonorItem) => {
    setBloodDonorsList(prev => [newDonor, ...prev.filter(d => d.id !== newDonor.id)]);
  }, []);

  // Filtered Hospitals - comprehensive search across name, specialties, area, district, city
  const filteredHospitals = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();
    const isAllIndiaState = !selectedState || selectedState === 'ALL' || selectedState.toLowerCase() === 'all india';

    return hospitalsList.filter(h => {
      const matchesQuery = !q || 
        h.name.toLowerCase().includes(q) || 
        (h.hindiName && h.hindiName.toLowerCase().includes(q)) ||
        h.city.toLowerCase().includes(q) || 
        h.area.toLowerCase().includes(q) || 
        (h.address && h.address.toLowerCase().includes(q)) ||
        h.specialties.some(s => s.toLowerCase().includes(q)) ||
        (h.district && h.district.toLowerCase().includes(q)) ||
        (h.cmoName && h.cmoName.toLowerCase().includes(q)) ||
        (h.type && h.type.toLowerCase().includes(q));

      const matchesLocation = !loc || loc === 'all india' ||
        h.city.toLowerCase().includes(loc) ||
        loc.includes(h.city.toLowerCase()) ||
        (h.district && (h.district.toLowerCase().includes(loc) || loc.includes(h.district.toLowerCase()))) ||
        h.area.toLowerCase().includes(loc) ||
        loc.includes(h.area.toLowerCase()) ||
        (h.address && h.address.toLowerCase().includes(loc)) ||
        h.name.toLowerCase().includes(loc) ||
        (h.hindiName && h.hindiName.toLowerCase().includes(loc)) ||
        (h.state && (h.state.toLowerCase().includes(loc) || loc.includes(h.state.toLowerCase())));

      const matchesState = isAllIndiaState || h.state.toLowerCase() === selectedState.toLowerCase();
      const matchesTier = selectedTier === 'ALL' || h.tier === selectedTier;
      const matchesAyushman = !ayushmanOnly || h.ayushmanBharat === true;
      const matches247 = !filter247 || h.open247 === true;

      return matchesQuery && matchesLocation && matchesState && matchesTier && matchesAyushman && matches247;
    });
  }, [hospitalsList, searchQuery, searchLocation, selectedState, selectedTier, ayushmanOnly, filter247]);

  // Filtered Ambulances
  const filteredAmbulances = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();
    const isAllIndiaState = !selectedState || selectedState === 'ALL' || selectedState.toLowerCase() === 'all india';

    return ambulancesList.filter(a => {
      const matchesQuery = !q || 
        a.providerName.toLowerCase().includes(q) || 
        a.ambulanceType.toLowerCase().includes(q) || 
        a.city.toLowerCase().includes(q) || 
        a.baseLocation.toLowerCase().includes(q) ||
        a.driverName.toLowerCase().includes(q);

      const matchesLocation = !loc || loc === 'all india' ||
        a.city.toLowerCase().includes(loc) ||
        loc.includes(a.city.toLowerCase()) ||
        a.baseLocation.toLowerCase().includes(loc);

      const matchesState = isAllIndiaState || !a.state || a.state.toLowerCase() === selectedState.toLowerCase();
      const matches247 = !filter247 || a.available === true;

      return matchesQuery && matchesLocation && matchesState && matches247;
    });
  }, [ambulancesList, searchQuery, searchLocation, selectedState, filter247]);

  // Filtered Blood Donors
  const filteredBloodDonors = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();

    return bloodDonorsList.filter(b => {
      const matchesQuery = !q || 
        b.name.toLowerCase().includes(q) || 
        b.city.toLowerCase().includes(q) || 
        b.area.toLowerCase().includes(q) || 
        b.donorType.toLowerCase().includes(q);

      const matchesLocation = !loc || loc === 'all india' ||
        b.city.toLowerCase().includes(loc) ||
        loc.includes(b.city.toLowerCase()) ||
        b.area.toLowerCase().includes(loc);

      const matchesGroup = selectedBloodGroup === 'ALL' || b.bloodGroup === selectedBloodGroup;

      return matchesQuery && matchesLocation && matchesGroup;
    });
  }, [bloodDonorsList, searchQuery, searchLocation, selectedBloodGroup]);

  // Filtered Doctors
  const filteredDoctors = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();
    const isAllIndiaState = !selectedState || selectedState === 'ALL' || selectedState.toLowerCase() === 'all india';

    return doctorsList.filter(d => {
      const matchesQuery = !q || 
        d.name.toLowerCase().includes(q) || 
        d.specialty.toLowerCase().includes(q) || 
        d.hospital.toLowerCase().includes(q) || 
        d.city.toLowerCase().includes(q);

      const matchesLocation = !loc || loc === 'all india' ||
        d.city.toLowerCase().includes(loc) ||
        loc.includes(d.city.toLowerCase()) ||
        (d.hospital && d.hospital.toLowerCase().includes(loc));

      const matchesState = isAllIndiaState || !d.state || d.state.toLowerCase() === selectedState.toLowerCase();
      const matches247 = !filter247 || d.availableNow === true;

      return matchesQuery && matchesLocation && matchesState && matches247;
    });
  }, [doctorsList, searchQuery, searchLocation, selectedState, filter247]);

  // Filtered Pharmacies
  const filteredPharmacies = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();

    return pharmaciesList.filter(p => {
      const matchesQuery = !q || 
        p.name.toLowerCase().includes(q) || 
        p.address.toLowerCase().includes(q) || 
        p.city.toLowerCase().includes(q) || 
        p.area.toLowerCase().includes(q);

      const matchesLocation = !loc || loc === 'all india' ||
        p.city.toLowerCase().includes(loc) ||
        loc.includes(p.city.toLowerCase()) ||
        p.area.toLowerCase().includes(loc);

      const matches247 = !filter247 || p.open247 === true;

      return matchesQuery && matchesLocation && matches247;
    });
  }, [pharmaciesList, searchQuery, searchLocation, filter247]);

  // Filtered Diagnostic Labs
  const filteredLabs = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    const loc = searchLocation.toLowerCase().trim();

    return labsList.filter(l => {
      const matchesQuery = !q || 
        l.name.toLowerCase().includes(q) || 
        l.address.toLowerCase().includes(q) || 
        l.city.toLowerCase().includes(q) || 
        l.area.toLowerCase().includes(q) ||
        l.testsAvailable.some(t => t.toLowerCase().includes(q));

      const matchesLocation = !loc || loc === 'all india' ||
        l.city.toLowerCase().includes(loc) ||
        loc.includes(l.city.toLowerCase()) ||
        l.area.toLowerCase().includes(loc);

      return matchesQuery && matchesLocation;
    });
  }, [labsList, searchQuery, searchLocation]);

  // Active category results count
  const currentCategoryCount = useMemo(() => {
    switch (activeCategory) {
      case 'hospital': return filteredHospitals.length;
      case 'ambulance': return filteredAmbulances.length;
      case 'blood': return filteredBloodDonors.length;
      case 'doctor': return filteredDoctors.length;
      case 'pharmacy': return filteredPharmacies.length;
      case 'lab': return filteredLabs.length;
      default: return 0;
    }
  }, [activeCategory, filteredHospitals, filteredAmbulances, filteredBloodDonors, filteredDoctors, filteredPharmacies, filteredLabs]);

  return (
    <div className="min-h-screen flex flex-col bg-[#040b12] text-white selection:bg-rose-500 selection:text-white font-sans antialiased pb-20 sm:pb-0">
      
      {/* FastMedCab Navbar */}
      <FastMedCabNavbar 
        activeCategory={activeCategory}
        onSelectCategory={setActiveCategory}
        onOpenSos={() => setIsSosOpen(true)}
        onOpenAmbulanceDispatch={() => setIsAmbulanceDispatchOpen(true)}
        onOpenBloodRequest={() => setIsBloodModalOpen(true)}
        onOpenAyushman={() => setIsAyushmanModalOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onToggleMapView={() => setViewMode(prev => prev === 'list' ? 'map' : 'list')}
        isMapView={viewMode === 'map'}
        isHindi={isHindi}
        setIsHindi={setIsHindi}
      />

      {/* Hero Section with Quick SOS, Ambulance & Blood Actions */}
      <FastMedCabHero 
        onOpenSos={() => setIsSosOpen(true)}
        onOpenAmbulanceDispatch={() => setIsAmbulanceDispatchOpen(true)}
        onOpenBloodRequest={() => setIsBloodModalOpen(true)}
        isHindi={isHindi}
      />

      {/* Main Search & Interactive Filters */}
      <main className="flex-1">
        <QuickSearch 
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          searchLocation={searchLocation}
          onLocationChange={setSearchLocation}
          searchQuery={searchQuery}
          onQueryChange={setSearchQuery}
          selectedState={selectedState}
          onStateChange={setSelectedState}
          selectedTier={selectedTier}
          onTierChange={setSelectedTier}
          ayushmanOnly={ayushmanOnly}
          onToggleAyushman={() => setAyushmanOnly(prev => !prev)}
          selectedBloodGroup={selectedBloodGroup}
          onBloodGroupChange={setSelectedBloodGroup}
          filter247={filter247}
          onToggle247={() => setFilter247(prev => !prev)}
          resultsCount={currentCategoryCount}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          isHindi={isHindi}
          onImportHospitals={handleImportHospitals}
          customHospitalsCount={customHospitals.length}
          onClearCustomHospitals={handleClearCustomHospitals}
        />

        {/* Directory & Interactive Leaflet Map Grid */}
        <ServiceDirectory 
          category={activeCategory}
          hospitals={filteredHospitals}
          ambulances={filteredAmbulances}
          bloodDonors={filteredBloodDonors}
          doctors={filteredDoctors}
          pharmacies={filteredPharmacies}
          labs={filteredLabs}
          onTrackAmbulance={handleTrackFromDirectory}
          onRequestBlood={() => setIsBloodModalOpen(true)}
          onSelectCategory={setActiveCategory}
          onSelectHospital={(hosp) => setSelectedHospitalForModal(hosp)}
          searchLocation={searchLocation}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          onLocationDetected={(loc) => {
            setSearchLocation(loc);
          }}
        />

        {/* How It Works Section */}
        <HowItWorks />

        {/* Emergency First Aid Protocols */}
        <FirstAidGuide />

        {/* Why FastMedCab Section */}
        <WhyUs />
      </main>

      {/* FastMedCab Footer */}
      <FastMedCabFooter 
        onOpenSos={() => setIsSosOpen(true)}
        onOpenAmbulanceDispatch={() => setIsAmbulanceDispatchOpen(true)}
        onOpenBloodRequest={() => setIsBloodModalOpen(true)}
        onOpenAyushman={() => setIsAyushmanModalOpen(true)}
        isHindi={isHindi}
      />

      {/* Floating Bottom Quick Action Bar for Mobile Devices */}
      <aside aria-label="Mobile Emergency Toolbar" className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#03090e]/95 backdrop-blur-md border-t border-slate-800 px-3 py-2 flex items-center justify-between gap-2 shadow-2xl">
        <button
          onClick={() => setIsSosOpen(true)}
          className="flex-1 bg-gradient-to-r from-rose-600 to-red-600 text-white font-black py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(255,49,80,0.5)] animate-pulse"
        >
          <ShieldAlert className="w-4 h-4" />
          <span>SOS ALARM</span>
        </button>

        <button
          onClick={() => setIsAmbulanceDispatchOpen(true)}
          className="flex-1 bg-amber-500 text-slate-950 font-black py-2.5 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-md"
        >
          <Ambulance className="w-4 h-4" />
          <span>AMBULANCE</span>
        </button>

        <button
          onClick={() => setViewMode(prev => prev === 'list' ? 'map' : 'list')}
          className="p-2.5 rounded-xl bg-slate-800 text-cyan-300 border border-slate-700 text-xs flex items-center justify-center"
          title="Toggle Map / List View"
        >
          <Map className="w-4 h-4" />
        </button>
      </aside>

      {/* Modals Container */}
      <SosModal 
        isOpen={isSosOpen}
        onClose={() => setIsSosOpen(false)}
      />

      <AmbulanceDispatchModal 
        isOpen={isAmbulanceDispatchOpen}
        onClose={() => setIsAmbulanceDispatchOpen(false)}
        onStartTracking={handleStartTracking}
      />

      <AmbulanceTrackerModal 
        isOpen={isAmbulanceTrackerOpen}
        onClose={() => setIsAmbulanceTrackerOpen(false)}
        ambulance={trackedAmbulance}
      />

      <BloodRequestModal 
        isOpen={isBloodModalOpen}
        onClose={() => setIsBloodModalOpen(false)}
        onAddDonor={handleAddDonor}
      />

      <AyushmanInsuranceModal 
        isOpen={isAyushmanModalOpen}
        onClose={() => setIsAyushmanModalOpen(false)}
        isHindi={isHindi}
      />

      <HospitalDetailModal 
        hospital={selectedHospitalForModal}
        onClose={() => setSelectedHospitalForModal(null)}
        onDispatchAmbulance={(hosp) => {
          setSelectedHospitalForModal(null);
          setIsAmbulanceDispatchOpen(true);
        }}
      />

      <AuthModal 
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        isHindi={isHindi}
      />

    </div>
  );
}
