import { HealthPackageItem, SuryaDoctorProfile } from '../types';

export const SURYA_HOSPITAL = {
  name: "SURYA HOSPITAL & MEDICAL RESEARCH CENTRE",
  hindiName: "सूर्य हॉस्पिटल एवं मेडिकल रिसर्च सेंटर",
  shortName: "Surya Hospital",
  tagline: "Super Speciality Healthcare, Critical Care & Advanced Diagnostics",
  hindiTagline: "सुपर स्पेशलिटी स्वास्थ्य सेवाएं, क्रिटिकल केयर एवं आधुनिक डायग्नोस्टिक्स",
  accreditation: "NABH & NABL Accredited Super Speciality Hospital",
  emergencyPhone: "+91 1800-890-7879",
  ambulancePhone: "+91 22 6900 8000",
  receptionPhone: "+91 22 6900 8111",
  email: "care@suryahospital.org",
  website: "www.suryahospital.org",
  address: "Surya Hospital Medical Enclave, S.V. Road & Central Avenue Junction, Mumbai - 400054",
  opdHours: "Monday to Saturday: 8:00 AM – 8:00 PM | Sunday: 9:00 AM – 2:00 PM",
  emergencyHours: "24x7 Open (365 Days Emergency, Trauma, ICU & Blood Bank)",
  stats: {
    beds: "350+ Beds",
    icuBeds: "65+ Critical ICU Beds",
    doctors: "120+ Specialists",
    patientsHealed: "4,50,000+",
    rating: "4.9 ★ (12,400+ Verified Patient Reviews)"
  },
  facilities: [
    "24/7 Level-3 Respiratory & Medical ICU (MICU)",
    "Extracorporeal Membrane Oxygenation (ECMO) Life-Support",
    "Negative-Pressure Airborne Isolation Suites",
    "NABL-Accredited Molecular Diagnostics & Virology Lab",
    "High-Resolution 128-Slice Low-Dose CT Scanner",
    "Advanced 24x7 Blood Component Separation & Apheresis",
    "Advanced Life Support (ALS) GPS-Tracked Ambulance Fleet"
  ]
};

export const SURYA_DOCTORS: SuryaDoctorProfile[] = [
  {
    id: "dr-rajesh-suryavanshi",
    name: "Dr. Rajesh Suryavanshi",
    hindiName: "डॉ. राजेश सूर्यवंशी",
    qualification: "MBBS, MD (Internal Medicine), FICP",
    designation: "Director & Chief of Infectious Diseases",
    department: "Infectious Diseases & Tropical Medicine",
    experienceYears: 19,
    languages: ["English", "Hindi", "Marathi"],
    opdTimings: "Mon, Wed, Fri (10:00 AM – 2:00 PM)",
    rating: 4.98,
    reviewsCount: 420,
    consultationFee: "₹900",
    focusAreas: [
      "Zoonotic Infections & Viral Fevers (Hantavirus, Dengue, Leptospirosis)",
      "Sepsis & Severe Antimicrobial Resistance (AMR)",
      "Tropical Diseases & Unexplained Prolonged Fevers (PUO)",
      "Adult Immunization & Pre-Travel Medicine"
    ],
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "dr-ananya-sharma",
    name: "Dr. Ananya Sharma",
    hindiName: "डॉ. अनन्या शर्मा",
    qualification: "MBBS, MD (Pulmonary Medicine), FCCP (USA), EDIC",
    designation: "Head of Pulmonology & Critical Care",
    department: "Pulmonology & Respiratory Medicine",
    experienceYears: 16,
    languages: ["English", "Hindi", "Gujarati"],
    opdTimings: "Tue, Thu, Sat (11:00 AM – 4:00 PM)",
    rating: 4.96,
    reviewsCount: 385,
    consultationFee: "₹1,000",
    focusAreas: [
      "Acute Respiratory Distress Syndrome (ARDS) & HPS",
      "Lung Protective Mechanical Ventilation & ECMO Therapy",
      "Severe Bronchial Asthma & COPD Interventions",
      "Interventional Bronchoscopy & Pulmonary Function Testing"
    ],
    image: "https://images.unsplash.com/photo-1594824813583-7278d91c7f5f?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "dr-vikramaditya-rathore",
    name: "Dr. Vikramaditya Rathore",
    hindiName: "डॉ. विक्रमादित्य राठौर",
    qualification: "MBBS, MD (Emergency Medicine), MRCEM (UK)",
    designation: "Head of Emergency & Trauma Services",
    department: "24/7 Emergency & Casualty",
    experienceYears: 14,
    languages: ["English", "Hindi"],
    opdTimings: "24/7 Emergency On-Duty Rotation",
    rating: 4.95,
    reviewsCount: 512,
    consultationFee: "₹800",
    focusAreas: [
      "Acute Resuscitation & Cardiopulmonary Shock Management",
      "Triage & Rapid Response Protocols for Hypoxia",
      "Animal Bites & Zoonotic Post-Exposure Prophylaxis (PEP)",
      "Critical Bedside Ultrasound & Airway Management"
    ],
    image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "dr-priya-verma",
    name: "Dr. Priya Verma",
    hindiName: "डॉ. प्रिया वर्मा",
    qualification: "MBBS, MD (General Medicine), DNB (Nephrology)",
    designation: "Senior Consultant Nephrologist & Renal Transplant Physician",
    department: "Nephrology & Dialysis Unit",
    experienceYears: 15,
    languages: ["English", "Hindi", "Punjabi"],
    opdTimings: "Mon, Tue, Thu, Fri (2:00 PM – 6:00 PM)",
    rating: 4.93,
    reviewsCount: 298,
    consultationFee: "₹950",
    focusAreas: [
      "Hemorrhagic Fever with Renal Syndrome (HFRS) & AKI",
      "Continuous Renal Replacement Therapy (CRRT) in Sepsis",
      "Glomerulonephritis & Hemodialysis Care",
      "Hypertensive Nephropathy"
    ],
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&auto=format&fit=crop&q=80"
  }
];

export const SURYA_HEALTH_PACKAGES: HealthPackageItem[] = [
  {
    id: "viral-fever-infectious-panel",
    name: "Surya Comprehensive Viral Fever & Infectious Screening Panel",
    hindiName: "सूर्य संपूर्ण वायरल फीवर एवं संक्रामक रोग प्रोफाइल",
    category: "Infectious & Tropical",
    tagline: "Essential diagnostic workup for acute fever, severe body ache, platelet drops, and suspected rodent/vector exposures.",
    price: 1499,
    originalPrice: 2999,
    discountPercentage: 50,
    turnaroundTime: "Same-Day Report (Within 6 Hours)",
    fastingRequired: "Not required (Random sample)",
    testsCount: 42,
    parameters: [
      "Complete Blood Count (CBC) with Platelet Indices & Differential",
      "Dengue NS1 Antigen + IgM/IgG Antibodies ELISA",
      "Malaria Rapid Antigen (Pv / Pf) & Peripheral Blood Smear",
      "Typhoid IgM Widal Rapid Test",
      "C-Reactive Protein (CRP Quantitative - Inflammatory marker)",
      "Erythrocyte Sedimentation Rate (ESR)",
      "Liver Function Test (SGOT, SGPT, Bilirubin total & direct)",
      "Kidney Function Test (Blood Urea, Serum Creatinine, Electrolytes)",
      "Urine Routine & Microscopic Examination"
    ],
    popular: true,
    recommendedFor: "Patients with acute high fever, severe muscle ache, chills, or sudden onset illness after outdoor/storage exposure."
  },
  {
    id: "pulmonary-respiratory-executive",
    name: "Surya Advanced Pulmonary & Respiratory Health Check",
    hindiName: "सूर्य उन्नत फेफड़ा एवं श्वसन स्वास्थ्य जांच",
    category: "Pulmonology",
    tagline: "Comprehensive evaluation of lung volume, airway resistance, oxygen saturation, and early parenchymal infiltrates.",
    price: 2199,
    originalPrice: 4200,
    discountPercentage: 48,
    turnaroundTime: "Same-Day (Report + Specialist Consultation)",
    fastingRequired: "Fasting not required (Avoid heavy meals 2 hrs before spirometry)",
    testsCount: 28,
    parameters: [
      "Digital High-Resolution Chest X-Ray (PA & Lateral Views)",
      "Computerized Spirometry (Pulmonary Function Test - PFT)",
      "Continuous Pulse Oximetry (SpO2 at Rest & 6-Minute Walk Test)",
      "Arterial Blood Gas (ABG) Analysis (if indicated)",
      "Complete Blood Count with Absolute Eosinophil Count (AEC)",
      "Total Serum IgE (Allergy marker)",
      "Consultation with Senior Consultant Pulmonologist"
    ],
    popular: false,
    recommendedFor: "Individuals experiencing persistent cough, shortness of breath, dust exposure, smoking history, or asthma."
  },
  {
    id: "surya-full-body-shield",
    name: "Surya Comprehensive Master Health Checkup (A-Z Shield)",
    hindiName: "सूर्य संपूर्ण शरीर मास्टर हेल्थ चेकअप (A-Z शील्ड)",
    category: "Preventive Wellness",
    tagline: "Full-spectrum screening covering heart, lungs, liver, kidneys, metabolism, thyroid, vitamins, and infectious risks.",
    price: 2899,
    originalPrice: 6500,
    discountPercentage: 55,
    turnaroundTime: "Within 12 Hours",
    fastingRequired: "10-12 Hours Fasting Required",
    testsCount: 78,
    parameters: [
      "Complete Hemogram (28 parameters)",
      "Comprehensive Lipid Profile (Cholesterol, HDL, LDL, Triglycerides, VLDL)",
      "Liver Function Profile (11 parameters)",
      "Kidney & Renal Health Profile (BUN, Creatinine, Uric Acid, Calcium)",
      "Fasting Blood Glucose & Glycated Hemoglobin (HbA1c - 3 Months Sugar)",
      "Thyroid Profile Total (T3, T4, TSH Ultra-sensitive)",
      "Vitamin D3 (25-Hydroxy) & Vitamin B12 Levels",
      "Resting 12-Lead Electrocardiogram (ECG)",
      "Digital Chest Radiograph",
      "Detailed Physical Examination & Physician Review"
    ],
    popular: true,
    recommendedFor: "Annual health surveillance for adults aged 25-65 seeking early detection of silent lifestyle or organ dysfunctions."
  },
  {
    id: "monsoon-vector-rodent-shield",
    name: "Surya Monsoon Vector & Zoonotic Fever Profile",
    hindiName: "सूर्य मॉनसून वेक्टर एवं जूनोटिक फीवर प्रोफाइल",
    category: "Seasonal & Zoonotic",
    tagline: "Targeted rapid screening for waterlogged, rodent-borne, and vector illnesses: Leptospirosis, Scrub Typhus, Dengue & Malaria.",
    price: 1899,
    originalPrice: 3800,
    discountPercentage: 50,
    turnaroundTime: "Within 4 Hours (STAT)",
    fastingRequired: "No fasting needed",
    testsCount: 35,
    parameters: [
      "Leptospira IgM Serological Antibody Screen",
      "Scrub Typhus IgM ELISA (Orientia tsutsugamushi)",
      "Dengue NS1 Antigen & IgM/IgG Combo",
      "Malaria Dual Antigen (Pf/Pv) Card Test",
      "Complete Blood Count with Platelet Count & MPV",
      "Procalcitonin (Bacterial sepsis marker) screening",
      "Serum Creatinine & Bilirubin for organ involvement"
    ],
    popular: false,
    recommendedFor: "Anyone with fever after exposure to flood water, sewage, farm fields, overgrown brush, or rodent droppings."
  }
];
