export interface HantavirusContent {
  meta: {
    title: string;
    hindiTitle: string;
    subtitle: string;
    hindiSubtitle: string;
    category: string;
    readTime: string;
    updatedDate: string;
    reviewedBy: {
      name: string;
      role: string;
      credentials: string;
      department: string;
    };
  };
  summaryPoints: string[];
  tableOfContents: { id: string; title: string; hindiTitle: string }[];
  faqs: { question: string; hindiQuestion: string; answer: string; hindiAnswer: string }[];
  stages: {
    phase: string;
    timeframe: string;
    severity: 'Warning' | 'Emergency' | 'Critical';
    title: string;
    symptoms: string[];
    clinicalNote: string;
  }[];
  cleanupSteps: {
    step: number;
    title: string;
    description: string;
    warning?: string;
  }[];
  diagnosticTests: {
    testName: string;
    purpose: string;
    suryaFacility: string;
    turnaround: string;
  }[];
}

export const HANTAVIRUS_ARTICLE: HantavirusContent = {
  meta: {
    title: "Hantavirus: Symptoms, Causes, Treatment & Prevention",
    hindiTitle: "हंतावायरस: लक्षण, कारण, उपचार और बचाव के उपाय",
    subtitle: "A comprehensive clinical guide by Surya Hospital on rodent-borne Hantavirus Pulmonary Syndrome (HPS) and Hemorrhagic Fever with Renal Syndrome (HFRS).",
    hindiSubtitle: "सूर्य हॉस्पिटल का संपूर्ण क्लिनिकल गाइड: चूहों से फैलने वाले हंतावायरस के शुरुआती लक्षण, श्वसन संबंधी जटिलताएं, आईसीयू उपचार और रोकथाम।",
    category: "A-Z Diseases · Viral & Zoonotic Infections",
    readTime: "7 Min Read",
    updatedDate: "March 2025 (Medically Reviewed)",
    reviewedBy: {
      name: "Dr. Rajesh Suryavanshi, MD (Medicine), FICP",
      role: "Head of Infectious Diseases & Critical Care",
      credentials: "MBBS, MD, Fellowship in Infectious Diseases (CMC), 18+ Yrs Exp.",
      department: "Department of Infectious Diseases & Pulmonology, Surya Hospital"
    }
  },
  summaryPoints: [
    "Hantavirus is a family of zoonotic viruses transmitted primarily through infected rodents, including deer mice, white-footed mice, and cotton rats.",
    "Humans contract the virus predominantly by inhaling aerosolized dust containing dried rodent urine, saliva, or droppings in enclosed areas like sheds and basements.",
    "Two severe clinical syndromes exist: Hantavirus Pulmonary Syndrome (HPS - lungs fill with fluid) and Hemorrhagic Fever with Renal Syndrome (HFRS - kidney failure and bleeding).",
    "Early symptoms mimic influenza (high fever, severe muscle aches in thighs and back, fatigue, headache) before sudden respiratory deterioration occurs 4-10 days later.",
    "There is no specific antiviral cure; immediate Level-3 ICU supportive care (mechanical ventilation, ECMO, hemodynamic stabilization) at Surya Hospital is life-saving.",
    "Crucial safety rule: NEVER sweep or vacuum dry rodent droppings. Always wet-decontaminate using a 1:9 bleach-water solution while wearing an N95 mask."
  ],
  tableOfContents: [
    { id: "what-is-hantavirus", title: "1. What is Hantavirus?", hindiTitle: "1. हंतावायरस क्या है?" },
    { id: "transmission-causes", title: "2. Causes & How It Spreads", hindiTitle: "2. फैलने के कारण और माध्यम" },
    { id: "symptoms-timeline", title: "3. Symptoms & Clinical Stages", hindiTitle: "3. लक्षण और चरणबद्ध समयसीमा" },
    { id: "hps-vs-hfrs", title: "4. HPS vs HFRS: Two Major Forms", hindiTitle: "4. HPS बनाम HFRS: दो मुख्य प्रकार" },
    { id: "diagnosis-tests", title: "5. Diagnosis & Lab Testing at Surya", hindiTitle: "5. जांच और डायग्नोस्टिक्स" },
    { id: "treatment-icu", title: "6. Treatment & Intensive Care Management", hindiTitle: "6. उपचार और आईसीयू प्रबंधन" },
    { id: "rodent-cleanup", title: "7. Safe Rodent Cleanup Protocol (CDC)", hindiTitle: "7. चूहों के अपशिष्ट की सुरक्षित सफाई" },
    { id: "prevention-tips", title: "8. Long-Term Prevention Guidelines", hindiTitle: "8. रोकथाम के महत्वपूर्ण नियम" },
    { id: "when-to-see-doctor", title: "9. When to Seek Emergency Care", hindiTitle: "9. डॉक्टर से तुरंत कब संपर्क करें" },
    { id: "faqs", title: "10. Frequently Asked Questions", hindiTitle: "10. अक्सर पूछे जाने वाले सवाल" }
  ],
  stages: [
    {
      phase: "Stage 1: Early Prodromal Phase",
      timeframe: "Days 1 to 8 after incubation",
      severity: "Warning",
      title: "Flu-Like Initial Presentation",
      symptoms: [
        "Persistent High Fever (>101°F / 38.3°C) and violent chills",
        "Severe Myalgia (intense muscle pain in thighs, hips, lower back, and shoulders)",
        "Profound fatigue, generalized exhaustion, and lightheadedness",
        "Frontal headache and retro-orbital pain",
        "Gastrointestinal distress: nausea, vomiting, abdominal cramping, and watery diarrhea"
      ],
      clinicalNote: "Often misdiagnosed as common flu, dengue, or malaria. Crucial differentiator: absence of upper respiratory symptoms (no runny nose or sore throat in early stage)."
    },
    {
      phase: "Stage 2: Cardiopulmonary / Acute Phase",
      timeframe: "Days 4 to 10 (Rapid Onset)",
      severity: "Emergency",
      title: "Hantavirus Pulmonary Syndrome (HPS)",
      symptoms: [
        "Sudden, severe shortness of breath (dyspnea) at rest",
        "Persistent non-productive cough progressing to pink frothy sputum",
        "Non-cardiogenic pulmonary edema (lungs rapidly accumulate fluid)",
        "Severe hypoxemia (SpO2 dropping under 88% on room air)",
        "Tachypnea (>26 breaths per minute) with intercostal retractions"
      ],
      clinicalNote: "Medical Emergency: Capillary leak syndrome causes fluid to flood alveolar airspaces within 24–48 hours, requiring urgent endotracheal intubation."
    },
    {
      phase: "Stage 3: Hemodynamic Collapse / Shock",
      timeframe: "Late Acute Phase (Hours count)",
      severity: "Critical",
      title: "Cardiogenic Shock & Multi-Organ Failure",
      symptoms: [
        "Profound arterial hypotension (Systolic BP < 80 mmHg)",
        "Depressed cardiac index and decreased myocardial contractility",
        "Severe metabolic acidosis and elevated serum lactate",
        "Oliguria / anuria (severe drop in urine output) signaling acute kidney injury",
        "Disseminated intravascular coagulation (DIC) in HFRS presentation"
      ],
      clinicalNote: "Requires Level-3 Intensive Care with invasive arterial line monitoring, high-dose vasopressors, and ECMO (Extracorporeal Membrane Oxygenation) backup."
    }
  ],
  cleanupSteps: [
    {
      step: 1,
      title: "Ventilate the Space (Do NOT enter immediately)",
      description: "Open all doors and external windows for at least 30 to 60 minutes prior to cleaning. Step away into fresh air while cross-ventilation clears stale, trapped air.",
      warning: "NEVER use an electric fan inside before ventilating, as it can blow viral particles directly into your breathing zone."
    },
    {
      step: 2,
      title: "Don Personal Protective Equipment (PPE)",
      description: "Wear an N95 or FFP2 respirator mask (tight-fitting over nose and mouth), heavy-duty rubber or nitrile gloves, and eye protection goggles.",
      warning: "Cloth masks or surgical masks do not adequately filter airborne viral aerosols."
    },
    {
      step: 3,
      title: "Wet-Decontaminate (NEVER Sweep or Vacuum)",
      description: "Prepare a fresh disinfectant: mix 1.5 cups of household chlorine bleach with 1 gallon of water (1:9 dilution ratio), or use hospital-grade viral disinfectant. Thoroughly spray the droppings, urine, and nesting material until completely soaked. Let soak undisturbed for 10 minutes.",
      warning: "STRICT RULE: Sweeping with a broom or vacuuming dry droppings aerosolizes the virus into microscopic airborne droplets that you inhale."
    },
    {
      step: 4,
      title: "Wipe Up with Disposable Towels",
      description: "Use disposable paper towels, wipes, or damp mops to gently collect the wet debris. Wipe down the entire surrounding flooring and baseboards with disinfectant solution.",
      warning: "Do not reuse cleaning sponges or towels. Dispose immediately after single contact."
    },
    {
      step: 5,
      title: "Double-Bag and Disinfect Hands",
      description: "Place soaked paper towels and rodent debris into a heavy-duty plastic garbage bag. Seal tightly, place inside a second bag, and seal again. Wash gloved hands in disinfectant, remove gloves carefully turning them inside out, and scrub bare hands with antiseptic soap for 30 seconds.",
      warning: "Discard double-bagged waste in an outdoor covered garbage container."
    }
  ],
  diagnosticTests: [
    {
      testName: "Hantavirus IgM & IgG Serological ELISA",
      purpose: "Detects acute phase antibodies (IgM) confirms active hantaviral infection even within 2-4 days of symptom onset.",
      suryaFacility: "Surya 24/7 NABL-Accredited Molecular Virology Lab",
      turnaround: "Same-Day Report (4-6 Hours)"
    },
    {
      testName: "Reverse Transcriptase RT-PCR",
      purpose: "Direct viral RNA molecular detection from whole blood or respiratory specimens during the early viremic phase.",
      suryaFacility: "Automated Molecular Diagnostics Unit",
      turnaround: "6 to 8 Hours"
    },
    {
      testName: "High-Resolution Chest CT / Digital X-Ray",
      purpose: "Identifies early bilateral interstitial infiltrates, Kerley B lines, and alveolar fluid accumulation indicative of HPS.",
      suryaFacility: "Surya 128-Slice Low-Dose CT & Bedside Digital X-Ray",
      turnaround: "Immediate (Under 20 Minutes)"
    },
    {
      testName: "Comprehensive Critical Care Profile (CBC + Platelets + ABG)",
      purpose: "Screens for hallmark triad: severe thrombocytopenia (platelet drop < 100,000), elevated hematocrit (>50%), and atypical lymphocytosis.",
      suryaFacility: "Surya Stat ICU Blood Gas & Hematology Lab",
      turnaround: "Stat / 15 Minutes"
    }
  ],
  faqs: [
    {
      question: "Can Hantavirus spread from person to person?",
      hindiQuestion: "क्या हंतावायरस एक व्यक्ति से दूसरे व्यक्ति में फैलता है?",
      answer: "In almost all cases worldwide, Hantavirus cannot be transmitted from person to person. It is exclusively contracted through inhalation of rodent-contaminated dust or direct contact with rodent saliva, urine, or droppings. The only documented rare exception is the Andes virus strain in South America, where limited human-to-human transmission has been observed among close household contacts.",
      hindiAnswer: "ज्यादातर मामलों में हंतावायरस एक इंसान से दूसरे इंसान में नहीं फैलता है। यह मुख्य रूप से संक्रमित चूहों के मल-मूत्र, लार या उनकी धूल सांस द्वारा फेफड़ों में जाने से होता है। केवल दक्षिण अमेरिका में पाए जाने वाले एंडीज स्ट्रेन में बहुत दुर्लभ घरेलू संपर्कों के बीच इसका फैलाव देखा गया है।"
    },
    {
      question: "How long after exposure do Hantavirus symptoms appear?",
      hindiQuestion: "चूहों के संपर्क में आने के कितने दिनों बाद लक्षण दिखाई देते हैं?",
      answer: "The incubation period typically ranges from 1 to 8 weeks (average 2 to 3 weeks). Early symptoms resemble a severe flu with high fever and heavy muscle pain. Because of this incubation delay, patients often do not connect their current illness with cleaning a dusty shed, garage, or attic weeks earlier.",
      hindiAnswer: "संक्रमण के संपर्क में आने के बाद लक्षण 1 से 8 सप्ताह (औसतन 2 से 3 सप्ताह) के भीतर दिखाई देते हैं। शुरुआती लक्षण तेज बुखार और मांसपेशियों में दर्द के रूप में आते हैं, जिससे लोग अक्सर पुरानी सफाई को बीमारी से नहीं जोड़ पाते।"
    },
    {
      question: "Is there an antiviral cure or vaccine for Hantavirus?",
      hindiQuestion: "क्या हंतावायरस का कोई विशिष्ट एंटीवायरल इलाज या टीका मौजूद है?",
      answer: "Currently, there is no FDA or WHO-approved antiviral cure or widely available preventative vaccine for Hantavirus Pulmonary Syndrome (HPS). Treatment relies entirely on aggressive supportive critical care in an ICU setting, including mechanical ventilation, oxygenation, blood pressure stabilization, and fluid control. Patients who receive early ICU care at advanced centers like Surya Hospital have significantly higher survival rates.",
      hindiAnswer: "वर्तमान में हंतावायरस के लिए कोई विशेष एंटीवायरल दवा या स्वीकृत टीका उपलब्ध नहीं है। इलाज मुख्य रूप से आईसीयू में सपोर्टिव केयर (ऑक्सीजन, वेंटिलेटर, ब्लड प्रेशर नियंत्रण और फेफड़ों के पानी को नियंत्रित करना) पर निर्भर करता है। समय पर सही इलाज मिलने पर मरीज स्वस्थ हो जाते हैं।"
    },
    {
      question: "Why is sweeping mouse droppings so dangerous?",
      hindiQuestion: "चूहों के मल को झाड़ू से साफ करना खतरनाक क्यों माना जाता है?",
      answer: "When you sweep dry rodent droppings or vacuum them with a standard household cleaner, the friction crushes the desiccated material and aerosolizes millions of microscopic viral particles into the air. When you inhale these airborne aerosols, the virus penetrates deep into your pulmonary alveoli, initiating infection. Always wet-decontaminate with bleach first.",
      hindiAnswer: "सूखे मल पर झाड़ू लगाने या वैक्यूम करने से वायरस के सूक्ष्म कण हवा में तैरने लगते हैं। जब आप सांस लेते हैं तो यह सीधे फेफड़ों में प्रवेश कर जाता है। इसलिए हमेशा पहले ब्लीच या कीटाणुनाशक का छिड़काव कर गीला करके ही पोंछना चाहिए।"
    },
    {
      question: "What is the difference between HPS and HFRS?",
      hindiQuestion: "HPS और HFRS में क्या मुख्य अंतर है?",
      answer: "Hantavirus manifests primarily in two distinct clinical syndromes: 1) HPS (Hantavirus Pulmonary Syndrome), common in the Americas, which primarily attacks the lungs leading to severe fluid buildup and respiratory failure; 2) HFRS (Hemorrhagic Fever with Renal Syndrome), common in Asia and Europe, which causes severe kidney failure, internal hemorrhaging, and sudden blood pressure drops.",
      hindiAnswer: "HPS मुख्य रूप से फेफड़ों पर असर डालता है जिससे फेफड़ों में पानी भर जाता है और सांस लेना मुश्किल हो जाता है। वहीं HFRS गुर्दे (किडनी) को प्रभावित करता है, जिससे पेशाब कम होना, किडनी फेल होना और रक्तस्राव की समस्या हो सकती है।"
    },
    {
      question: "What facilities does Surya Hospital have for acute respiratory failure?",
      hindiQuestion: "सूर्य हॉस्पिटल में गंभीर श्वसन विफलता के लिए क्या सुविधाएं हैं?",
      answer: "Surya Hospital features a 24/7 dedicated Level-3 Medical & Respiratory Intensive Care Unit (MICU) equipped with negative-pressure isolation suites, advanced high-frequency mechanical ventilators, Extracorporeal Membrane Oxygenation (ECMO) life-support, round-the-clock intensivist coverage, and an on-site molecular virology lab for rapid pathogen profiling.",
      hindiAnswer: "सूर्य हॉस्पिटल में 24 घंटे समर्पित लेवल-3 रेस्पिरेटरी आईसीयू, नेगेटिव-प्रेशर आइसोलेशन रूम, आधुनिक मैकेनिकल वेंटिलेटर, एक्मो (ECMO) लाइफ सपोर्ट और वरिष्ठ क्रिटिकल केयर डॉक्टरों की टीम 24/7 तैनात रहती है।"
    }
  ]
};
