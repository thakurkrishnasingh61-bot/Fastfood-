export interface IndianStateInfo {
  name: string;
  code: string;
  emergencyHelpline: string;
  capital: string;
  districts: string[];
}

export const POPULAR_INDIAN_CITIES = [
  'All India',
  'New Delhi',
  'Mumbai',
  'Bengaluru',
  'Lucknow',
  'Kolkata',
  'Hyderabad',
  'Chennai',
  'Ahmedabad',
  'Jaipur',
  'Patna',
  'Pune',
  'Chandigarh',
  'Bhopal',
  'Varanasi',
  'Gorakhpur',
  'Kanpur',
  'Ranchi',
  'Guwahati',
  'Dehradun',
  'Indore',
  'Nagpur',
  'Surat',
  'Cuttack',
  'Bhubaneswar',
  'Kochi',
  'Visakhapatnam',
  'Srinagar',
  'Jammu',
  'Shimla',
  'Meerut',
  'Agra',
  'Gaya',
  'Muzaffarpur',
  'Udaipur',
  'Jodhpur',
  'Kota',
  'Gwalior',
  'Jabalpur',
  'Amritsar',
  'Ludhiana',
  'Rohtak',
  'Hubballi',
  'Mangaluru',
  'Mysuru',
  'Coimbatore',
  'Madurai',
  'Siliguri',
  'Asansol',
  'Raipur',
  'Panaji'
];

export const INDIAN_STATES: IndianStateInfo[] = [
  {
    name: 'All India',
    code: 'IN',
    emergencyHelpline: '112',
    capital: 'New Delhi',
    districts: ['All Districts', ...POPULAR_INDIAN_CITIES.filter(c => c !== 'All India')]
  },
  {
    name: 'Delhi NCR',
    code: 'DL',
    emergencyHelpline: '112 / 108',
    capital: 'New Delhi',
    districts: ['All Delhi NCR', 'New Delhi', 'South Extension', 'Okhla', 'Dwarka', 'Rohini', 'Connaught Place', 'Saket', 'Noida', 'Greater Noida', 'Gurugram', 'Ghaziabad', 'Faridabad']
  },
  {
    name: 'Uttar Pradesh',
    code: 'UP',
    emergencyHelpline: '112 / 108 / 102',
    capital: 'Lucknow',
    districts: ['All UP', 'Lucknow', 'Kanpur', 'Varanasi', 'Prayagraj (Allahabad)', 'Agra', 'Meerut', 'Gorakhpur', 'Bareilly', 'Aligarh', 'Moradabad', 'Jhansi', 'Mathura', 'Ayodhya', 'Saharanpur', 'Barabanki', 'Chandauli', 'Muzaffarnagar']
  },
  {
    name: 'Maharashtra',
    code: 'MH',
    emergencyHelpline: '112 / 108',
    capital: 'Mumbai',
    districts: ['All Maharashtra', 'Mumbai', 'Bandra West', 'Andheri East', 'Parel', 'Thane', 'Navi Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Chhatrapati Sambhaji Nagar', 'Kolhapur', 'Solapur', 'Amravati']
  },
  {
    name: 'Karnataka',
    code: 'KA',
    emergencyHelpline: '112 / 108',
    capital: 'Bengaluru',
    districts: ['All Karnataka', 'Bengaluru', 'Indiranagar', 'Whitefield', 'Mysuru', 'Mangaluru', 'Hubballi-Dharwad', 'Belagavi', 'Kalaburagi', 'Davanagere', 'Ballari', 'Udupi', 'Shivamogga']
  },
  {
    name: 'Bihar',
    code: 'BR',
    emergencyHelpline: '112 / 102 / 108',
    capital: 'Patna',
    districts: ['All Bihar', 'Patna', 'Gaya', 'Muzaffarpur', 'Bhagalpur', 'Darbhanga', 'Purnia', 'Bihar Sharif', 'Arrah', 'Begusarai', 'Katihar', 'Bodh Gaya']
  },
  {
    name: 'West Bengal',
    code: 'WB',
    emergencyHelpline: '112 / 108 / 102',
    capital: 'Kolkata',
    districts: ['All West Bengal', 'Kolkata', 'Howrah', 'Siliguri', 'Asansol', 'Durgapur', 'Bardhaman', 'Kalyani', 'Kharagpur', 'Malda', 'Darjeeling']
  },
  {
    name: 'Tamil Nadu',
    code: 'TN',
    emergencyHelpline: '112 / 108',
    capital: 'Chennai',
    districts: ['All Tamil Nadu', 'Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Vellore', 'Erode', 'Thanjavur', 'Dindigul', 'Kanyakumari']
  },
  {
    name: 'Gujarat',
    code: 'GJ',
    emergencyHelpline: '112 / 108',
    capital: 'Gandhinagar',
    districts: ['All Gujarat', 'Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Gandhinagar', 'Junagadh', 'Anand', 'Bharuch']
  },
  {
    name: 'Rajasthan',
    code: 'RJ',
    emergencyHelpline: '112 / 108',
    capital: 'Jaipur',
    districts: ['All Rajasthan', 'Jaipur', 'Jodhpur', 'Kota', 'Bikaner', 'Ajmer', 'Udaipur', 'Bhilwara', 'Alwar', 'Sikar', 'Pali', 'Sumerpur', 'Sri Ganganagar']
  },
  {
    name: 'Madhya Pradesh',
    code: 'MP',
    emergencyHelpline: '112 / 108',
    capital: 'Bhopal',
    districts: ['All MP', 'Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna', 'Ratlam', 'Rewa', 'Singrauli']
  },
  {
    name: 'Telangana',
    code: 'TS',
    emergencyHelpline: '112 / 108',
    capital: 'Hyderabad',
    districts: ['All Telangana', 'Hyderabad', 'Secunderabad', 'Warangal', 'Nizamabad', 'Karimnagar', 'Khammam', 'Ramagundam', 'Mahbubnagar', 'Nalgonda']
  },
  {
    name: 'Andhra Pradesh',
    code: 'AP',
    emergencyHelpline: '112 / 108',
    capital: 'Amaravati',
    districts: ['All AP', 'Visakhapatnam', 'Vijayawada', 'Guntur', 'Nellore', 'Kurnool', 'Rajahmundry', 'Tirupati', 'Kakinada', 'Kadapa', 'Anantapur']
  },
  {
    name: 'Punjab & Haryana',
    code: 'PB_HR',
    emergencyHelpline: '112 / 108',
    capital: 'Chandigarh',
    districts: ['All Punjab & Haryana', 'Chandigarh', 'Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Rohtak', 'Gurugram', 'Faridabad', 'Panipat', 'Karnal', 'Hisar', 'Ambala', 'Rewari']
  },
  {
    name: 'Kerala',
    code: 'KL',
    emergencyHelpline: '112 / 108',
    capital: 'Thiruvananthapuram',
    districts: ['All Kerala', 'Thiruvananthapuram', 'Kochi (Ernakulam)', 'Kozhikode', 'Thrissur', 'Kollam', 'Kannur', 'Alappuzha', 'Palakkad', 'Kottayam', 'Malappuram']
  },
  {
    name: 'Odisha',
    code: 'OD',
    emergencyHelpline: '112 / 108',
    capital: 'Bhubaneswar',
    districts: ['All Odisha', 'Bhubaneswar', 'Cuttack', 'Rourkela', 'Berhampur', 'Sambalpur', 'Puri', 'Balasore', 'Bhadrak', 'Baripada']
  },
  {
    name: 'Jharkhand',
    code: 'JH',
    emergencyHelpline: '112 / 108',
    capital: 'Ranchi',
    districts: ['All Jharkhand', 'Ranchi', 'Jamshedpur', 'Dhanbad', 'Bokaro Steel City', 'Deoghar', 'Hazaribagh', 'Giridih', 'Ramgarh']
  },
  {
    name: 'Chhattisgarh',
    code: 'CG',
    emergencyHelpline: '112 / 108',
    capital: 'Raipur',
    districts: ['All Chhattisgarh', 'Raipur', 'Bhilai-Durg', 'Bilaspur', 'Korba', 'Rajnandgaon', 'Jagdalpur', 'Ambikapur']
  },
  {
    name: 'Assam & North East',
    code: 'NE',
    emergencyHelpline: '112 / 108',
    capital: 'Guwahati',
    districts: ['All North East', 'Guwahati', 'Dibrugarh', 'Silchar', 'Jorhat', 'Tezpur', 'Shillong', 'Agartala', 'Imphal', 'Aizawl', 'Kohima', 'Gangtok', 'Itanagar']
  },
  {
    name: 'Uttarakhand',
    code: 'UK',
    emergencyHelpline: '112 / 108',
    capital: 'Dehradun',
    districts: ['All Uttarakhand', 'Dehradun', 'Haridwar', 'Rishikesh', 'Roorkee', 'Haldwani', 'Rudrapur', 'Nainital', 'Almora', 'Kashipur']
  },
  {
    name: 'Himachal Pradesh',
    code: 'HP',
    emergencyHelpline: '112 / 108',
    capital: 'Shimla',
    districts: ['All Himachal', 'Shimla', 'Dharamshala', 'Solan', 'Mandi', 'Kullu', 'Baddi', 'Hamirpur', 'Bilaspur', 'Una', 'Chamba']
  },
  {
    name: 'Jammu & Kashmir',
    code: 'JK',
    emergencyHelpline: '112 / 108 / 102',
    capital: 'Srinagar / Jammu',
    districts: ['All J&K', 'Srinagar', 'Jammu', 'Anantnag', 'Baramulla', 'Udhampur', 'Kathua', 'Sopore']
  },
  {
    name: 'Goa',
    code: 'GA',
    emergencyHelpline: '112 / 108',
    capital: 'Panaji',
    districts: ['All Goa', 'Panaji', 'Margao', 'Vasco da Gama', 'Mapusa', 'Ponda', 'Bambolim']
  },
  {
    name: 'Puducherry & UTs',
    code: 'UT',
    emergencyHelpline: '112 / 108',
    capital: 'Puducherry',
    districts: ['All UTs', 'Puducherry', 'Karaikal', 'Port Blair', 'Daman', 'Diu', 'Silvassa', 'Kavaratti']
  }
];

export const NATIONAL_EMERGENCY_HELPLINES = [
  {
    service: 'National Unified Emergency Helpline',
    number: '112',
    badge: 'Pan-India 24/7',
    description: 'Single national emergency number for Ambulance, Police, and Fire services across all Indian States.',
    type: 'national',
  },
  {
    service: 'National Medical Emergency & Ambulance',
    number: '108',
    badge: 'Free Ambulance 108',
    description: 'Government 24/7 free medical dispatch ambulance service operating in all states and districts.',
    type: 'ambulance',
  },
  {
    service: 'Maternity & Infant Neonatal Emergency',
    number: '102',
    badge: 'Free Janani Shishu',
    description: 'Free emergency transport for pregnant mothers, newborns, and child health emergencies (JSSK).',
    type: 'maternity',
  },
  {
    service: 'Ayushman Bharat PM-JAY Toll Free',
    number: '14555',
    badge: 'Cashless Care ₹5 Lakh',
    description: 'Verify PM-JAY golden card status and find empaneled hospitals for free cashless emergency treatment.',
    type: 'ayushman',
  },
  {
    service: 'National Tele-Consultation (eSanjeevani)',
    number: '1075',
    badge: 'Govt Free Tele-OPD',
    description: 'Ministry of Health national tele-consultation service connecting patients directly to senior MD doctors.',
    type: 'doctor',
  },
  {
    service: 'e-RaktKosh National Blood Helpline',
    number: '1800-11-0031',
    badge: 'Blood & Platelets 24x7',
    description: 'Indian Red Cross & Ministry of Health national blood bank stock availability and donor coordination.',
    type: 'blood',
  },
  {
    service: 'Tele-MANAS Mental Health Support',
    number: '14416',
    badge: '24x7 Crisis Support',
    description: 'Government toll-free mental health counseling and psychiatric emergency support in all Indian languages.',
    type: 'mental_health',
  },
  {
    service: 'National Poison Information Centre (AIIMS)',
    number: '1800-116-117',
    badge: 'Toxin & Snakebite Hub',
    description: 'AIIMS New Delhi round-the-clock emergency guidance on chemical, pesticide, and snake venom toxins.',
    type: 'poison',
  }
];
