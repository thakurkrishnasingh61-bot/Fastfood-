export interface SpecialtyDetail {
  id: string;
  name: string;
  hindiName: string;
  shortDesc: string;
  fullDesc: string;
  icon: string;
  color: string;
  features: string[];
  headDoctor: string;
  timing: string;
  stats: string;
}

export interface Doctor {
  id: string;
  name: string;
  qualification: string;
  department: string;
  experience: string;
  availability: string;
  timings: string;
  languages: string[];
  focus: string[];
  image: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  initials: string;
  rating: number;
  timeAgo: string;
  verified: boolean;
  content: string;
  treatment: string;
  likes: number;
}

export interface FAQItem {
  question: string;
  hindiQuestion?: string;
  answer: string;
}

export const HOSPITAL_INFO = {
  name: "NOVA SHEKHAR HOSPITAL",
  hindiName: "नोवा शेखर हॉस्पिटल",
  tagline: "24/7 Multi-Speciality, Critical ICU, Eye Hospital & Hemodialysis Centre",
  hindiTagline: "24 घंटे आपातकालीन, आईसीयू, नेत्र चिकित्सालय एवं डायलिसिस केंद्र",
  address: "MGIMT CAMPUS, KANPUR -ROAD (NH-25), BANTHARA, Uttar Pradesh 226401",
  shortAddress: "MGIMT Campus, Kanpur Road (NH-25), Banthara, UP",
  city: "Banthara, Lucknow / Kanpur Road Corridor",
  state: "Uttar Pradesh",
  pincode: "226401",
  landmark: "Inside MGIMT Campus, on National Highway 25 (Kanpur - Lucknow Road)",
  phone: "095550 14545",
  formattedPhone: "+91 95550 14545",
  emergencyPhone: "095550 14545",
  ambulancePhone: "095550 14545",
  email: "info@novashekharhospital.com",
  opdHours: "Open · OPD Closes 5:00 PM (Monday – Sunday: 9:00 AM – 5:00 PM)",
  emergencyHours: "24 Hours Open (365 Days Emergency, ICU & Trauma)",
  googleRating: 5.04,
  totalReviews: "4+ Verified Reviews",
  ratingSnippet: "5.0 ★ Google reviews (Highest rated hospital in Banthara / Khandedev)",
  coordinates: {
    lat: 26.6976,
    lng: 80.8258
  },
  coreServices: [
    "HOSPITAL",
    "EMERGENCY 24x7",
    "ICU (INTENSIVE CARE)",
    "EYE HOSPITAL",
    "MODULAR OT",
    "DIALYSIS UNIT",
    "GYNECOLOGIST & MATERNITY"
  ]
};

export const SPECIALTIES_DATA: SpecialtyDetail[] = [
  {
    id: "emergency",
    name: "24/7 Emergency & Trauma Care",
    hindiName: "24 घंटे आपातकालीन एवं ट्रामा सेंटर",
    shortDesc: "Rapid highway trauma resuscitation, cardiac first response, and 24x7 casualty team on NH-25.",
    fullDesc: "Strategically located on Kanpur Road (NH-25) at Banthara, our 24/7 Emergency & Trauma Centre delivers immediate life-saving medical care for road accidents, cardiac arrests, stroke, poisoning, and acute medical emergencies with zero delay.",
    icon: "ShieldAlert",
    color: "rose",
    features: [
      "Immediate Highway Triage on NH-25 Kanpur Road",
      "Dedicated Resuscitation Bay with Defibrillators & Crash Carts",
      "On-duty Emergency Medical Officers (EMO) 24 hours",
      "Direct Priority Transfer to In-house ICU & Modular OT",
      "Advanced Life Support (ALS) Ambulance Standby"
    ],
    headDoctor: "Emergency Casualty Medical Team",
    timing: "Open 24 Hours · Every Day",
    stats: "< 3 Min Triage Time"
  },
  {
    id: "icu",
    name: "ICU (Intensive Care Unit)",
    hindiName: "गहन चिकित्सा इकाई (ICU)",
    shortDesc: "Multi-channel bedside monitors, invasive mechanical ventilators, central oxygen, and continuous intensivist monitoring.",
    fullDesc: "Our modern Intensive Care Unit is engineered for critically ill patients requiring continuous hemodynamic support, mechanical ventilation, and multi-organ monitoring with strict infection control protocols.",
    icon: "HeartPulse",
    color: "red",
    features: [
      "High-end Invasive & Non-Invasive Mechanical Ventilators",
      "Multi-Para Cardiac & Blood Gas Monitoring Systems",
      "Centralized Medical Oxygen & High-Pressure Suction",
      "1:1 Specialized Critical Care Nursing Ratio",
      "Isolation Beds for Airborne and Severe Infections"
    ],
    headDoctor: "Dr. Shekhar Sharma (MD, Critical Care)",
    timing: "24/7 Active ICU Services",
    stats: "100% Monitored Beds"
  },
  {
    id: "eye",
    name: "Nova Eye Hospital (Netra Chikitsalaya)",
    hindiName: "नोवा नेत्र चिकित्सालय (आँखों का विशेष अस्पताल)",
    shortDesc: "Micro-incision Cataract Surgery (Phaco), Computerized Vision Checkup, Glaucoma & Retina Care.",
    fullDesc: "Nova Eye Hospital offers comprehensive ophthalmic diagnosis and painless micro-surgical procedures. From stitchless Phaco cataract surgeries with foldable IOL implants to diabetic eye screenings, we bring world-class eye care to Banthara and surrounding rural areas.",
    icon: "Eye",
    color: "sky",
    features: [
      "Stitchless Phaco Cataract Surgery with Premium Monofocal/Multifocal IOLs",
      "Computerized Refraction & Vision Testing Equipment",
      "Glaucoma Screening, Tonometry & Visual Field Analysis",
      "Diabetic Retinopathy & Hypertensive Eye Screenings",
      "Pterygium Excision & Complete Spectacle Counter"
    ],
    headDoctor: "Dr. R. K. Srivastava (MS Ophthalmology)",
    timing: "OPD: 9:00 AM - 5:00 PM",
    stats: "Stitchless & Painless"
  },
  {
    id: "ot",
    name: "Modular Operation Theatres (OT)",
    hindiName: "अत्याधुनिक मॉड्युलर ऑपरेशन थिएटर",
    shortDesc: "Ultra-clean laminar airflow OT with HEPA filtration, C-Arm imaging, and laparoscopic surgical suites.",
    fullDesc: "Our Modular Operation Theatres maintain strict sterile airflow to ensure zero postoperative infections. Equipped for general surgery, orthopedic trauma fixation, laparoscopic procedures, and emergency cesarean sections.",
    icon: "Activity",
    color: "emerald",
    features: [
      "Laminar Airflow with Class 100 HEPA Filtration",
      "High-Resolution Laparoscopic Video Tower",
      "Digital C-Arm X-Ray Machine for Precision Orthopedic Surgery",
      "Multi-gas Anesthesia Workstations with Integrated Monitoring",
      "Dedicated Post-Operative Recovery Ward"
    ],
    headDoctor: "Dr. Manish Kumar (MS Gen & Laparoscopic Surgery)",
    timing: "Scheduled & 24/7 Emergency Surgeries",
    stats: "Zero-Infection Protocol"
  },
  {
    id: "dialysis",
    name: "Hemodialysis Unit",
    hindiName: "किडनी डायलिसिस यूनिट",
    shortDesc: "Modern dialysis machines with dedicated RO water filtration, nephrologist supervision, and separate virus-isolated stations.",
    fullDesc: "Patients with acute kidney injury or chronic kidney disease (CKD) receive safe, affordable, and compassionate hemodialysis under trained nephrology technicians. We adhere to stringent single-use or high-grade reprocessing standards.",
    icon: "Droplets",
    color: "blue",
    features: [
      "High-Flux Dialyzers with Medical RO Water Purification System",
      "Dedicated Isolated Stations for Seronegative / Seropositive Patients",
      "Comfortable Ergonomic Dialysis Recliners with Nurse Call",
      "Continuous Blood Pressure, Heart Rate & SpO2 Tracking",
      "Emergency Backup Power & Central Oxygen for Every Bed"
    ],
    headDoctor: "Dr. Pradeep Tiwari (MD, Nephrology Consultant)",
    timing: "Morning & Evening Shifts (Emergency Dialysis 24/7)",
    stats: "Pure RO Water System"
  },
  {
    id: "gynecologist",
    name: "Obstetrics & Gynecologist (Maternity)",
    hindiName: "स्त्री एवं प्रसूति रोग विशेषज्ञ (महिला चिकित्सा)",
    shortDesc: "Safe deliveries (Normal & Painless C-Section), high-risk pregnancy care, infertility guidance, and women's health.",
    fullDesc: "Dedicated to comprehensive women's health from adolescence to motherhood and menopause. Equipped with a modern labour delivery room, fetal Doppler monitoring, neonatal resuscitation, and specialized female laparoscopic surgery.",
    icon: "Baby",
    color: "pink",
    features: [
      "Comfortable Labour Delivery Room (LDR) with Foetal Heart Monitors",
      "Normal Delivery & Emergency Cesarean Section OT readiness",
      "Antenatal Checkups (ANC), Ultrasound Monitoring & Nutrition Advice",
      "Management of PCOD, Fibroids, Infertility & Menstrual Irregularities",
      "Newborn Care Corner with Phototherapy & Radiant Warmers"
    ],
    headDoctor: "Dr. Ananya Verma (MBBS, MS, DGO)",
    timing: "OPD: 9:00 AM - 5:00 PM (Emergency Delivery 24/7)",
    stats: "24/7 Maternity OT"
  },
  {
    id: "medicine",
    name: "General Medicine & Diagnostics",
    hindiName: "जनरल मेडिसिन एवं संपूर्ण जांच केंद्र",
    shortDesc: "Specialized fever management (Dengue/Malaria/Typhoid), Diabetes, Hypertension, Digital X-Ray, Pathology & 24/7 Pharmacy.",
    fullDesc: "Comprehensive internal medicine care for chronic lifestyle disorders and acute seasonal fevers. Our on-campus computerized pathology lab and 24/7 pharmacy ensure accurate diagnostics and instant medicine dispensing.",
    icon: "Stethoscope",
    color: "teal",
    features: [
      "Accurate Diagnosis for Dengue, Chikungunya, Malaria & Typhoid",
      "Comprehensive Blood Chemistry, CBC, Liver/Kidney Function Tests",
      "Digital X-Ray, 12-Lead ECG & Ultrasound Sonography",
      "Hypertension, Thyroid & Diabetic Management Programs",
      "24/7 In-House Pharmacy with Genuine Medicines"
    ],
    headDoctor: "Dr. S. P. Gupta (MD General Medicine)",
    timing: "OPD: 9:00 AM - 5:00 PM (Pharmacy & Lab 24/7)",
    stats: "Same Day Lab Results"
  }
];

export const DOCTORS_DATA: Doctor[] = [
  {
    id: "doc-1",
    name: "Dr. Shekhar Sharma",
    qualification: "MBBS, MD (Critical Care & General Medicine)",
    department: "Emergency, ICU & Critical Care",
    experience: "16+ Years Experience",
    availability: "Mon - Sat (24/7 Emergency on Call)",
    timings: "9:00 AM – 2:00 PM & Emergency Rounds",
    languages: ["Hindi", "English"],
    focus: ["Sepsis & Septic Shock", "Ventilator Management", "Cardiopulmonary Trauma", "Internal Medicine"],
    image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "doc-2",
    name: "Dr. Ananya Verma",
    qualification: "MBBS, MS (Obstetrics & Gynecology), DGO",
    department: "Gynecology, Obstetrics & Maternity",
    experience: "12+ Years Experience",
    availability: "Mon - Sun (Emergency 24x7)",
    timings: "9:30 AM – 4:30 PM",
    languages: ["Hindi", "English", "Awadhi"],
    focus: ["High-Risk Pregnancy", "Normal & Painless Deliveries", "Laparoscopic Hysterectomy", "Infertility Management"],
    image: "https://images.unsplash.com/photo-1594824813755-e51c89288e2c?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "doc-3",
    name: "Dr. R. K. Srivastava",
    qualification: "MBBS, MS (Ophthalmology), Fellow in Phaco & Retina",
    department: "Nova Eye Hospital (Netra Chikitsalaya)",
    experience: "15+ Years Experience",
    availability: "Mon, Wed, Fri, Sat",
    timings: "10:00 AM – 4:30 PM",
    languages: ["Hindi", "English"],
    focus: ["Micro-incision Cataract (Phaco)", "Glaucoma Care", "Diabetic Eye Screening", "Corneal Disorders"],
    image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "doc-4",
    name: "Dr. Manish Kumar",
    qualification: "MBBS, MS (General Surgery & Laparoscopy)",
    department: "Modular Operation Theatre & Surgery",
    experience: "14+ Years Experience",
    availability: "Mon - Sat",
    timings: "10:00 AM – 4:00 PM (Emergency OT 24/7)",
    languages: ["Hindi", "English"],
    focus: ["Gallbladder Stones (Laparoscopy)", "Hernia & Appendix", "Highway Trauma Surgeries", "Piles & Fissure"],
    image: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "doc-5",
    name: "Dr. Pradeep Tiwari",
    qualification: "MBBS, MD, Fellowship in Clinical Nephrology",
    department: "Dialysis & Renal Care",
    experience: "11+ Years Experience",
    availability: "Tue, Thu, Sat",
    timings: "11:00 AM – 4:30 PM",
    languages: ["Hindi", "English"],
    focus: ["Chronic Kidney Disease (CKD)", "Hemodialysis Protocol", "Diabetic Nephropathy", "Hypertensive Renal Care"],
    image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=400"
  },
  {
    id: "doc-6",
    name: "Dr. S. P. Gupta",
    qualification: "MBBS, MD (General Medicine)",
    department: "General Medicine & Lifestyle Diseases",
    experience: "18+ Years Experience",
    availability: "Mon - Sun",
    timings: "9:00 AM – 5:00 PM",
    languages: ["Hindi", "English"],
    focus: ["Dengue / Malaria / Viral Fevers", "Diabetes Mellitus", "Chest & Asthma Inhaler Care", "Geriatric Medicine"],
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=400"
  }
];

export const GOOGLE_REVIEWS_DATA: ReviewItem[] = [
  {
    id: "rev-1",
    author: "Virendra Pratap Singh",
    initials: "VS",
    rating: 5,
    timeAgo: "2 weeks ago",
    verified: true,
    content: "Kanpur road par banthara ke paas Nova Shekhar Hospital sabse best hai. Raat ko accident ke baad emergency me hamare dost ko admit karwaya tha. ICU doctor aur staff ne turant treatment start kiya. Excellent care and clean atmosphere!",
    treatment: "Highway Emergency & ICU Trauma",
    likes: 12
  },
  {
    id: "rev-2",
    author: "Shanti Devi (Banthara)",
    initials: "SD",
    rating: 5,
    timeAgo: "1 month ago",
    verified: true,
    content: "Meri dadi ka motiyabindu (cataract) ka operation Nova Shekhar Eye Hospital me bina taake (phaco) ke hua. Ab unko bilkul saaf dikhta hai. Doctor Srivastava bahut vinamra hain aur charges bhi kafi wajid hain.",
    treatment: "Phaco Cataract Eye Surgery",
    likes: 9
  },
  {
    id: "rev-3",
    author: "Rameshwar Yadav",
    initials: "RY",
    rating: 5,
    timeAgo: "2 months ago",
    verified: true,
    content: "Mere pitaji ki kidney dialysis ke liye hum pehle Lucknow city jaate the jisme 2 ghanta lagta tha. Banthara me MGIMT campus me Nova Shekhar hospital me dialysis unit shuru hone se bohot suvidha ho gayi. Machine bilkul nayi aur safe hain.",
    treatment: "Hemodialysis Unit",
    likes: 16
  },
  {
    id: "rev-4",
    author: "Pooja Awasthi",
    initials: "PA",
    rating: 5,
    timeAgo: "3 months ago",
    verified: true,
    content: "Gynecologist Dr. Ananya Verma ma'am is very supportive. Normal delivery bahut safe tareeke se karwayi. Nursing staff round the clock available rehta hai. Highly recommended for maternity in Khandedev & Banthara.",
    treatment: "Maternity & Normal Delivery",
    likes: 14
  }
];

export const NEARBY_SEARCHED_HOSPITALS = [
  {
    name: "Nova Shekhar Hospital",
    rating: "5.0 ★",
    reviews: "4+ Google Reviews",
    distance: "On Highway (MGIMT Campus)",
    specialty: "ICU, Eye Hospital, Dialysis, OT, Gynecologist, 24/7 Emergency",
    highlight: "Primary Recommended Multi-Speciality Centre"
  },
  {
    name: "Lovee Shubh Hospital",
    rating: "4.2 ★",
    reviews: "Nearby Center",
    distance: "~3.5 km",
    specialty: "General Healthcare",
    highlight: "Secondary Clinic"
  },
  {
    name: "R R dental and multi speciality hospital",
    rating: "4.4 ★",
    reviews: "Dental & General",
    distance: "~4.2 km",
    specialty: "Dental Care & General OPD",
    highlight: "Dental Focused"
  },
  {
    name: "New Max Hospital",
    rating: "4.1 ★",
    reviews: "Private Clinic",
    distance: "~5.0 km",
    specialty: "Local Inpatient Care",
    highlight: "Community Hospital"
  },
  {
    name: "Shine MultiSpeciality Hospital",
    rating: "4.3 ★",
    reviews: "Kanpur Road",
    distance: "~6.8 km",
    specialty: "Multi-Speciality",
    highlight: "Highway Route Clinic"
  }
];

export const FAQS_DATA: FAQItem[] = [
  {
    question: "Where is Nova Shekhar Hospital located on Kanpur Road?",
    hindiQuestion: "नोवा शेखर हॉस्पिटल कानपुर रोड पर कहाँ स्थित है?",
    answer: "Nova Shekhar Hospital is located inside MGIMT Campus on Kanpur Road (National Highway 25), Banthara, Uttar Pradesh 226401. It is easily accessible from Banthara market, Khandedev, Amausi Airport (10 mins), and the Unnao-Lucknow highway corridor."
  },
  {
    question: "Are emergency and ICU services open at night?",
    hindiQuestion: "क्या इमरजेंसी और आईसीयू सेवाएं रात में भी खुली रहती हैं?",
    answer: "Yes! While general OPD consultations close at 5:00 PM, our Emergency Casualty, ICU, Mechanical Ventilators, Blood Bank coordination, and Ambulance services operate 24 hours a day, 365 days a year."
  },
  {
    question: "What eye treatments are provided at Nova Eye Hospital?",
    hindiQuestion: "नोवा आई हॉस्पिटल में आँखों के कौन-से इलाज उपलब्ध हैं?",
    answer: "We perform micro-incision sutureless cataract surgeries (Phacoemulsification) with high quality foldable intraocular lenses (IOL), computerized eye testing, glaucoma pressure management, diabetic retinopathy screening, and prescription spectacle dispensing."
  },
  {
    question: "Do you have kidney dialysis machines?",
    hindiQuestion: "क्या अस्पताल में किडनी डायलिसिस की सुविधा है?",
    answer: "Yes. Nova Shekhar Hospital features a state-of-the-art Hemodialysis Unit with high-purity medical RO filtration and dedicated dialysis machines under nephrology specialist supervision."
  },
  {
    question: "How can I book an appointment or call an ambulance?",
    hindiQuestion: "अपॉइंटमेंट कैसे बुक करें या एम्बुलेंस कैसे बुलाएं?",
    answer: "You can book directly using our online booking form on this website or call our 24/7 dedicated helpline at 095550 14545 for instant ambulance dispatch on Kanpur Road."
  }
];

export const INSURANCE_PARTNERS = [
  { name: "Ayushman Bharat PM-JAY", type: "Govt Scheme" },
  { name: "Star Health Insurance", type: "TPA Cashless" },
  { name: "Care Health Insurance", type: "TPA Cashless" },
  { name: "HDFC ERGO Health", type: "TPA Cashless" },
  { name: "ICICI Lombard", type: "TPA Cashless" },
  { name: "Bajaj Allianz", type: "TPA Cashless" },
  { name: "National Insurance Co.", type: "Public Sector" },
  { name: "New India Assurance", type: "Public Sector" }
];
