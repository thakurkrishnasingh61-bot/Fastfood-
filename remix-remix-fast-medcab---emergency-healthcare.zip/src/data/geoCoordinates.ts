export interface GeoCoordinate {
  lat: number;
  lon: number;
}

// Ground truth geo-coordinates for Indian cities, towns, and districts
export const KNOWN_CITY_COORDINATES: Record<string, GeoCoordinate> = {
  // Hardoi & Regional Villages/Tehsils
  'pali': { lat: 27.5255, lon: 79.8396 },
  'hardoi': { lat: 27.3948, lon: 80.1315 },
  'kachhauna': { lat: 27.2458, lon: 80.2528 },
  'sandila': { lat: 27.0783, lon: 80.5058 },
  'bilgram': { lat: 27.1772, lon: 80.0353 },
  'shahabad': { lat: 27.6432, lon: 79.9431 },

  // Eastern UP & Gorakhpur Region
  'gorakhpur': { lat: 26.7606, lon: 83.3732 },
  'pipraich': { lat: 26.8294, lon: 83.5262 },
  'babhnan': { lat: 27.0253, lon: 82.3524 },
  'basti': { lat: 26.7995, lon: 82.7669 },
  'gonda': { lat: 27.1300, lon: 81.9619 },
  'deoria': { lat: 26.5024, lon: 83.7791 },
  'kushinagar': { lat: 26.7408, lon: 83.8890 },
  'maharajganj': { lat: 27.1458, lon: 83.5615 },
  'siddharthnagar': { lat: 27.2882, lon: 82.8094 },
  'azamgarh': { lat: 26.0689, lon: 83.1836 },

  // Central & Western UP
  'lucknow': { lat: 26.8467, lon: 80.9462 },
  'kanpur': { lat: 26.4499, lon: 80.3319 },
  'varanasi': { lat: 25.3176, lon: 82.9739 },
  'prayagraj': { lat: 25.4358, lon: 81.8463 },
  'allahabad': { lat: 25.4358, lon: 81.8463 },
  'ayodhya': { lat: 26.7922, lon: 82.1998 },
  'faizabad': { lat: 26.7730, lon: 82.1460 },
  'bareilly': { lat: 28.3670, lon: 79.4304 },
  'moradabad': { lat: 28.8386, lon: 78.7733 },
  'aligarh': { lat: 27.8974, lon: 78.0880 },
  'agra': { lat: 27.1767, lon: 78.0081 },
  'mathura': { lat: 27.4924, lon: 77.6737 },
  'meerut': { lat: 28.9845, lon: 77.7064 },
  'ghaziabad': { lat: 28.6692, lon: 77.4538 },
  'noida': { lat: 28.5355, lon: 77.3910 },
  'greater noida': { lat: 28.4744, lon: 77.5040 },
  'jhansi': { lat: 25.4484, lon: 78.5685 },
  'sitapur': { lat: 27.5684, lon: 80.6780 },
  'lakhimpur': { lat: 27.9480, lon: 80.7780 },
  'unnao': { lat: 26.5393, lon: 80.4878 },
  'rae bareli': { lat: 26.2236, lon: 81.2409 },

  // Delhi NCR & North India
  'new delhi': { lat: 28.6139, lon: 77.2090 },
  'delhi': { lat: 28.6139, lon: 77.2090 },
  'gurgaon': { lat: 28.4595, lon: 77.0266 },
  'gurugram': { lat: 28.4595, lon: 77.0266 },
  'faridabad': { lat: 28.4089, lon: 77.3178 },
  'chandigarh': { lat: 30.7333, lon: 76.7794 },
  'mohali': { lat: 30.7046, lon: 76.7179 },
  'panchkula': { lat: 30.6942, lon: 76.8606 },
  'amritsar': { lat: 31.6340, lon: 74.8723 },
  'ludhiana': { lat: 30.9010, lon: 75.8573 },
  'jalandhar': { lat: 31.3260, lon: 75.5762 },
  'dehradun': { lat: 30.3165, lon: 78.0322 },
  'haridwar': { lat: 29.9457, lon: 78.1642 },
  'rishikesh': { lat: 30.0869, lon: 78.2676 },
  'shimla': { lat: 31.1048, lon: 77.1734 },
  'srinagar': { lat: 34.0837, lon: 74.7973 },
  'jammu': { lat: 32.7266, lon: 74.8570 },

  // Bihar & Jharkhand
  'patna': { lat: 25.5941, lon: 85.1376 },
  'gaya': { lat: 24.7914, lon: 85.0002 },
  'muzaffarpur': { lat: 26.1209, lon: 85.3647 },
  'bhagalpur': { lat: 25.2425, lon: 86.9842 },
  'darbhanga': { lat: 26.1542, lon: 85.8918 },
  'ranchi': { lat: 23.3441, lon: 85.3096 },
  'jamshedpur': { lat: 22.8046, lon: 86.2029 },
  'dhanbad': { lat: 23.7957, lon: 86.4304 },

  // West & Central India
  'mumbai': { lat: 19.0760, lon: 72.8777 },
  'navi mumbai': { lat: 19.0330, lon: 73.0297 },
  'thane': { lat: 19.2183, lon: 72.9781 },
  'pune': { lat: 18.5204, lon: 73.8567 },
  'nagpur': { lat: 21.1458, lon: 79.0882 },
  'nashik': { lat: 19.9975, lon: 73.7898 },
  'aurangabad': { lat: 19.8762, lon: 75.3433 },
  'ahmedabad': { lat: 23.0225, lon: 72.5714 },
  'surat': { lat: 21.1702, lon: 72.8311 },
  'vadodara': { lat: 22.3072, lon: 73.1812 },
  'rajkot': { lat: 22.3039, lon: 70.8022 },
  'jaipur': { lat: 26.9124, lon: 75.7873 },
  'jodhpur': { lat: 26.2389, lon: 73.0243 },
  'udaipur': { lat: 24.5854, lon: 73.7125 },
  'kota': { lat: 25.2138, lon: 75.8648 },
  'bhopal': { lat: 23.2599, lon: 77.4126 },
  'indore': { lat: 22.7196, lon: 75.8577 },
  'gwalior': { lat: 26.2183, lon: 78.1828 },
  'jabalpur': { lat: 23.1815, lon: 79.9864 },
  'raipur': { lat: 21.2514, lon: 81.6296 },

  // South & East India
  'bengaluru': { lat: 12.9716, lon: 77.5946 },
  'bangalore': { lat: 12.9716, lon: 77.5946 },
  'mysuru': { lat: 12.2958, lon: 76.6394 },
  'hyderabad': { lat: 17.3850, lon: 78.4867 },
  'visakhapatnam': { lat: 17.6868, lon: 83.2185 },
  'vijayawada': { lat: 16.5062, lon: 80.6480 },
  'chennai': { lat: 13.0827, lon: 80.2707 },
  'coimbatore': { lat: 11.0168, lon: 76.9558 },
  'madurai': { lat: 9.9252, lon: 78.1198 },
  'vellore': { lat: 12.9165, lon: 79.1325 },
  'kochi': { lat: 9.9312, lon: 76.2673 },
  'thiruvananthapuram': { lat: 8.5241, lon: 76.9366 },
  'calicut': { lat: 11.2588, lon: 75.7804 },
  'kolkata': { lat: 22.5726, lon: 88.3639 },
  'howrah': { lat: 22.5958, lon: 88.2636 },
  'durgapur': { lat: 23.5204, lon: 87.3119 },
  'siliguri': { lat: 26.7271, lon: 88.3953 },
  'bhubaneswar': { lat: 20.2961, lon: 85.8245 },
  'cuttack': { lat: 20.4625, lon: 85.8828 },
  'guwahati': { lat: 26.1445, lon: 91.7362 },
  'shillong': { lat: 25.5788, lon: 91.8933 },
  'panaji': { lat: 15.4909, lon: 73.8278 },
  'goa': { lat: 15.2993, lon: 74.1240 }
};

/**
 * Deterministically generates geographic coordinates for any facility.
 * Respects existing lat/lon, resolves city/town coordinates, and adds a natural
 * radial scatter to prevent overlapping pins in the same locality.
 */
export function resolveFacilityCoordinates(
  facility: { 
    id?: string;
    name?: string; 
    city?: string; 
    area?: string; 
    address?: string; 
    lat?: number; 
    lon?: number; 
  },
  index: number = 0,
  fallbackCenter?: GeoCoordinate
): GeoCoordinate {
  // If valid coordinates already provided
  if (facility.lat && facility.lon && !isNaN(facility.lat) && !isNaN(facility.lon)) {
    return { lat: facility.lat, lon: facility.lon };
  }

  // Look for match in city, area, address
  const cityKey = (facility.city || '').trim().toLowerCase();
  const areaKey = (facility.area || '').trim().toLowerCase();
  const addressKey = (facility.address || '').trim().toLowerCase();

  let baseCoord: GeoCoordinate | null = null;

  for (const [key, coord] of Object.entries(KNOWN_CITY_COORDINATES)) {
    if (cityKey.includes(key) || areaKey.includes(key) || addressKey.includes(key)) {
      baseCoord = coord;
      break;
    }
  }

  // Fallback to provided center or default Lucknow / Central UP center
  if (!baseCoord) {
    baseCoord = fallbackCenter || { lat: 26.8467, lon: 80.9462 };
  }

  // Deterministic radial spread using golden angle (137.5 degrees)
  // Ensures pins in the same neighborhood cluster neatly without overlapping
  const angle = index * 2.39996; // Golden angle in radians
  const distanceFactor = Math.min(0.045, 0.005 + (index * 0.0028));
  
  // Hash name/id for subtle non-linear jitter
  const str = (facility.id || facility.name || '') + index;
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const jitterLat = ((hash % 100) / 100 - 0.5) * 0.002;
  const jitterLon = (((hash >> 3) % 100) / 100 - 0.5) * 0.002;

  const lat = baseCoord.lat + distanceFactor * Math.cos(angle) + jitterLat;
  const lon = baseCoord.lon + (distanceFactor * 1.1) * Math.sin(angle) + jitterLon;

  return {
    lat: Number(lat.toFixed(5)),
    lon: Number(lon.toFixed(5))
  };
}

/**
 * Returns center coordinate for a search query string.
 */
export function getSearchLocationCenter(query: string): GeoCoordinate | null {
  if (!query || query.trim().length === 0) return null;
  const q = query.trim().toLowerCase();

  for (const [key, coord] of Object.entries(KNOWN_CITY_COORDINATES)) {
    if (q.includes(key) || key.includes(q)) {
      return coord;
    }
  }
  return null;
}

/**
 * Calculate Haversine distance in km between two geo-coordinates
 */
export function calculateHaversineDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) *
      Math.cos(lat2 * (Math.PI / 180)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return parseFloat((R * c).toFixed(1));
}

/**
 * Returns the nearest known city and its distance for given GPS coordinates.
 */
export function findClosestKnownCity(lat: number, lon: number): { city: string; distanceKm: number } | null {
  let closestCity: string | null = null;
  let minDistance = Infinity;

  for (const [cityKey, coord] of Object.entries(KNOWN_CITY_COORDINATES)) {
    const dist = calculateHaversineDistanceKm(lat, lon, coord.lat, coord.lon);
    if (dist < minDistance) {
      minDistance = dist;
      closestCity = cityKey.charAt(0).toUpperCase() + cityKey.slice(1);
    }
  }

  if (closestCity) {
    return { city: closestCity, distanceKm: minDistance };
  }
  return null;
}


