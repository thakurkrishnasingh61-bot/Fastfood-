import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  CheckCircle2, 
  Stethoscope, 
  Building, 
  Video, 
  Home, 
  FileText,
  AlertCircle,
  Share2
} from 'lucide-react';
import { SURYA_HOSPITAL, SURYA_DOCTORS, SURYA_HEALTH_PACKAGES } from '../data/suryaHospitalData';

interface SuryaAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialDepartment?: string;
  initialDoctorOrPackage?: string;
  isHindi: boolean;
}

export const SuryaAppointmentModal: React.FC<SuryaAppointmentModalProps> = ({
  isOpen,
  onClose,
  initialDepartment,
  initialDoctorOrPackage,
  isHindi
}) => {
  const [department, setDepartment] = useState(initialDepartment || 'Infectious Diseases');
  const [doctorOrPackage, setDoctorOrPackage] = useState(initialDoctorOrPackage || '');
  const [consultType, setConsultType] = useState<'In-Person' | 'Video' | 'Home-Collection'>('In-Person');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [timeSlot, setTimeSlot] = useState('11:00 AM - 11:30 AM');
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [isBooked, setIsBooked] = useState(false);
  const [bookingId, setBookingId] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !patientPhone) return;

    const id = `SURYA-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingId(id);
    setIsBooked(true);
  };

  const handleResetAndClose = () => {
    setIsBooked(false);
    onClose();
  };

  const timeSlots = [
    '09:30 AM - 10:00 AM',
    '10:30 AM - 11:00 AM',
    '11:30 AM - 12:00 PM',
    '02:00 PM - 02:30 PM',
    '04:00 PM - 04:30 PM',
    '05:30 PM - 06:00 PM'
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Strip */}
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white p-5 sm:p-6 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded text-white">
              Surya Hospital & Research Centre
            </span>
            <h3 className="text-xl font-extrabold mt-1">
              {isHindi ? "परामर्श एवं टेस्ट बुकिंग" : "Book Doctor Consultation / Test"}
            </h3>
          </div>
          <button
            onClick={handleResetAndClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto">
          {isBooked ? (
            /* Success Confirmation Screen */
            <div className="text-center py-4 space-y-5">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h4 className="text-xl font-extrabold text-slate-900">
                  {isHindi ? "अपॉइंटमेंट सफलतापूर्वक दर्ज हुआ!" : "Appointment Confirmed!"}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  Confirmation SMS & WhatsApp details dispatched to +91 {patientPhone}
                </p>
              </div>

              {/* Ticket Card */}
              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 text-left text-xs sm:text-sm space-y-2.5">
                <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                  <span className="text-slate-500">Booking Reference ID:</span>
                  <span className="font-extrabold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-lg text-xs">
                    {bookingId}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Patient Name:</span>
                  <span className="font-bold text-slate-900">{patientName} ({patientAge} Yrs)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Consultation / Test:</span>
                  <span className="font-bold text-slate-900">{doctorOrPackage || department}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Date & Slot:</span>
                  <span className="font-bold text-slate-900">{date} · {timeSlot}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Mode:</span>
                  <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    {consultType === 'In-Person' ? 'Hospital OPD Visit' : consultType === 'Video' ? 'Teleconsultation Call' : 'Home Sample Collection'}
                  </span>
                </div>
                <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500 flex items-start gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <span>
                    Please arrive 15 minutes before your slot at Surya Hospital Reception, Tower A, S.V. Road.
                  </span>
                </div>
              </div>

              <button
                onClick={handleResetAndClose}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-sm transition shadow"
              >
                Done
              </button>
            </div>
          ) : (
            /* Booking Form */
            <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
              
              {/* Consultation Mode */}
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  {isHindi ? "परामर्श का प्रकार" : "Consultation / Service Mode"}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setConsultType('In-Person')}
                    className={`p-2.5 rounded-xl border text-center font-semibold transition flex flex-col items-center gap-1 ${
                      consultType === 'In-Person'
                        ? 'bg-amber-50 border-amber-500 text-amber-900'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Building className="w-4 h-4" />
                    <span className="text-xs">Hospital OPD</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConsultType('Video')}
                    className={`p-2.5 rounded-xl border text-center font-semibold transition flex flex-col items-center gap-1 ${
                      consultType === 'Video'
                        ? 'bg-amber-50 border-amber-500 text-amber-900'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Video className="w-4 h-4" />
                    <span className="text-xs">Video Call</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setConsultType('Home-Collection')}
                    className={`p-2.5 rounded-xl border text-center font-semibold transition flex flex-col items-center gap-1 ${
                      consultType === 'Home-Collection'
                        ? 'bg-amber-50 border-amber-500 text-amber-900'
                        : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Home className="w-4 h-4" />
                    <span className="text-xs">Home Lab Sample</span>
                  </button>
                </div>
              </div>

              {/* Department & Doctor / Service */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "विभाग" : "Department"}
                  </label>
                  <select
                    value={department}
                    onChange={(e) => setDepartment(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  >
                    <option value="Infectious Diseases">Infectious Diseases & Fevers</option>
                    <option value="Pulmonology">Pulmonology & Chest Medicine</option>
                    <option value="Emergency & Trauma">Emergency & Trauma Care (24/7)</option>
                    <option value="Nephrology">Nephrology & Renal Medicine</option>
                    <option value="General Medicine">General Internal Medicine</option>
                    <option value="Diagnostic Lab">Diagnostic Package / Blood Test</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "डॉक्टर / पैकेज का नाम" : "Doctor or Package"}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Dr. Rajesh Suryavanshi / Viral Panel"
                    value={doctorOrPackage}
                    onChange={(e) => setDoctorOrPackage(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  />
                </div>
              </div>

              {/* Preferred Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "पसंदीदा तारीख" : "Preferred Date"}
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "समय स्लॉट" : "Preferred Time Slot"}
                  </label>
                  <select
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  >
                    {timeSlots.map((slot, idx) => (
                      <option key={idx} value={slot}>{slot}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Patient Details */}
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "मरीज का पूरा नाम *" : "Patient Full Name *"}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Ramesh Kumar"
                    value={patientName}
                    onChange={(e) => setPatientName(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "उम्र" : "Age"}
                  </label>
                  <input
                    type="number"
                    placeholder="e.g. 42"
                    value={patientAge}
                    onChange={(e) => setPatientAge(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isHindi ? "मोबाइल नंबर (व्हाट्सएप अपडेट्स हेतु) *" : "Mobile Phone Number *"}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-bold text-slate-500">+91</span>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    placeholder="98765 43210"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                    className="w-full pl-12 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  {isHindi ? "लक्षण या मुख्य शिकायत" : "Symptoms or Chief Complaint (Optional)"}
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. High fever for 4 days after cleaning shed, severe leg pain, mild cough..."
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-amber-500 bg-white text-xs"
                />
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-extrabold py-3.5 rounded-xl text-sm transition shadow-md shadow-orange-600/20 active:scale-98"
                >
                  {isHindi ? "अपॉइंटमेंट की पुष्टि करें" : "Confirm Appointment"}
                </button>
                <p className="text-[10px] text-center text-slate-400 mt-2">
                  No advance payment needed. Pay directly at hospital billing or online.
                </p>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
