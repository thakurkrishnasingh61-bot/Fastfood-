import React from 'react';
import { 
  Phone, 
  Star, 
  ShieldAlert, 
  Navigation, 
  Award,
  ArrowUp
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface FooterProps {
  onOpenAppointment: () => void;
  onOpenAmbulance: () => void;
  onOpenAyushman: () => void;
  isHindi: boolean;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenAppointment,
  onOpenAmbulance,
  onOpenAyushman,
  isHindi
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=Nova+Shekhar+Hospital+MGIMT+Campus+Banthara+Kanpur+Road+Uttar+Pradesh`;

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800">
          
          {/* Col 1 & 2: Hospital Info & Google Rating */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-extrabold text-2xl shadow-lg shadow-blue-500/20">
                N+
              </div>
              <div>
                <span className="font-black text-xl text-white tracking-tight">
                  NOVA SHEKHAR HOSPITAL
                </span>
                <p className="text-xs text-blue-400 font-medium">
                  Multi-Speciality & Trauma Centre, Banthara
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              Dedicated to delivering world-class healthcare, 24/7 emergency casualty, advanced ICU life-support, modern phaco eye surgeries, and hemodialysis on Kanpur Road (NH-25), Uttar Pradesh.
            </p>

            {/* Google review rating badge */}
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 inline-flex items-center gap-3">
              <div className="flex items-center text-amber-400">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-4 h-4 fill-amber-400" />
                ))}
              </div>
              <div>
                <div className="font-black text-white text-xs">5.04 Google Rating</div>
                <div className="text-[10px] text-slate-400">Top Rated in Khandedev & Banthara</div>
              </div>
            </div>

            {/* Emergency Hotline Box */}
            <div className="p-4 rounded-2xl bg-red-950/40 border border-red-800/40 space-y-1">
              <div className="text-[11px] font-bold text-red-400 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>24/7 Trauma Emergency Helpline</span>
              </div>
              <a
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="text-lg font-black text-white hover:text-red-400 transition block"
              >
                {HOSPITAL_INFO.phone}
              </a>
            </div>
          </div>

          {/* Col 3: Core Specialties */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Core Departments
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">24/7 Emergency & Trauma</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">Intensive Care Unit (ICU)</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">Nova Eye Hospital (Phaco)</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">Modular Operation Theatres</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">Hemodialysis Unit (RO System)</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">Obstetrics & Gynecologist</a>
              </li>
              <li>
                <a href="#specialties" className="hover:text-blue-400 transition">General Medicine & Pathology</a>
              </li>
            </ul>
          </div>

          {/* Col 4: Timings & Patient Care */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Working Hours
            </h4>
            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-amber-400 font-bold block">OPD Consultation</span>
                <span className="text-slate-300">Open · Closes 5:00 PM</span>
                <span className="text-[10px] text-slate-500 block">Mon – Sun: 9:00 AM – 5:00 PM</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-red-400 font-bold block">Casualty & ICU</span>
                <span className="text-emerald-400 font-semibold">24 Hours Active (365 Days)</span>
                <span className="text-[10px] text-slate-500 block">Immediate Highway Admission</span>
              </div>
            </div>

            <div className="pt-1">
              <button
                onClick={onOpenAyushman}
                className="text-xs text-amber-400 hover:underline flex items-center gap-1 font-semibold"
              >
                <Award className="w-3.5 h-3.5" />
                <span>Ayushman Card / Cashless TPA Info</span>
              </button>
            </div>
          </div>

          {/* Col 5: Location & Directions */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Address & Directions
            </h4>
            
            <p className="text-xs text-slate-400 leading-relaxed">
              <strong className="text-slate-200">MGIMT CAMPUS, KANPUR -ROAD(NH-25), BANTHARA,</strong><br />
              Uttar Pradesh 226401
            </p>

            <div className="space-y-2 pt-2">
              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-3 rounded-xl bg-blue-700 hover:bg-blue-600 text-white font-bold text-xs flex items-center justify-center gap-2 transition"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Get Directions (NH-25)</span>
              </a>

              <button
                onClick={onOpenAppointment}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center justify-center gap-2 transition border border-slate-700"
              >
                <span>Book OPD Appointment</span>
              </button>
            </div>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            © {new Date().getFullYear()} NOVA SHEKHAR HOSPITAL. All Rights Reserved. Banthara, Kanpur Road (NH-25), UP 226401.
          </div>

          <div className="flex items-center gap-4">
            <span className="text-slate-400">Phone: 095550 14545</span>
            <button
              onClick={scrollToTop}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-white transition flex items-center gap-1"
              title="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
              <span>Top</span>
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
