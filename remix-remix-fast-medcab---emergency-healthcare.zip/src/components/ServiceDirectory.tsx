import React, { useState, useMemo } from 'react';
import { 
  HospitalItem, 
  AmbulanceItem, 
  BloodDonorItem, 
  DoctorItem, 
  PharmacyItem, 
  DiagnosticLabItem,
  ServiceCategory 
} from '../types';
import { FacilityMapView } from './FacilityMapView';
import { 
  Phone, 
  MapPin, 
  Navigation, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Star, 
  ShieldCheck, 
  Activity, 
  Bed, 
  Wind, 
  Droplet, 
  Ambulance, 
  Hospital,
  HeartHandshake, 
  Stethoscope, 
  Pill, 
  FlaskConical, 
  ExternalLink,
  Languages,
  Video,
  Building,
  Calendar,
  Map,
  List
} from 'lucide-react';

interface ServiceDirectoryProps {
  category: ServiceCategory;
  hospitals: HospitalItem[];
  ambulances: AmbulanceItem[];
  bloodDonors: BloodDonorItem[];
  doctors: DoctorItem[];
  pharmacies: PharmacyItem[];
  labs: DiagnosticLabItem[];
  onTrackAmbulance: (ambulance: AmbulanceItem) => void;
  onRequestBlood: () => void;
  onSelectCategory: (cat: ServiceCategory) => void;
  onSelectHospital?: (hospital: HospitalItem) => void;
  searchLocation?: string;
  viewMode?: 'list' | 'map';
  onViewModeChange?: (mode: 'list' | 'map') => void;
  onLocationDetected?: (locationName: string) => void;
}

export const ServiceDirectory: React.FC<ServiceDirectoryProps> = ({
  category,
  hospitals,
  ambulances,
  bloodDonors,
  doctors,
  pharmacies,
  labs,
  onTrackAmbulance,
  onRequestBlood,
  onSelectCategory,
  onSelectHospital,
  searchLocation = '',
  viewMode: controlledViewMode,
  onViewModeChange,
  onLocationDetected
}) => {
  const [internalViewMode, setInternalViewMode] = useState<'list' | 'map'>('list');
  const activeViewMode = controlledViewMode ?? internalViewMode;

  const handleSetViewMode = (mode: 'list' | 'map') => {
    if (onViewModeChange) {
      onViewModeChange(mode);
    } else {
      setInternalViewMode(mode);
    }
  };

  const getMapsUrl = (name: string, address: string) => {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name}, ${address}`)}`;
  };

  const currentCategoryCount = useMemo(() => {
    switch (category) {
      case 'hospital': return hospitals.length;
      case 'ambulance': return ambulances.length;
      case 'blood': return bloodDonors.length;
      case 'doctor': return doctors.length;
      case 'pharmacy': return pharmacies.length;
      case 'lab': return labs.length;
      default: return 0;
    }
  }, [category, hospitals, ambulances, bloodDonors, doctors, pharmacies, labs]);

  const getTierColor = (tier?: string) => {
    switch (tier) {
      case 'AIIMS & Apex Central Institute':
        return 'bg-[#00e5ff]/15 text-[#00e5ff] border-[#00e5ff]/40';
      case 'Govt Medical College':
        return 'bg-[#00ff9d]/15 text-[#00ff9d] border-[#00ff9d]/40';
      case 'District Hospital':
        return 'bg-[#38bdf8]/15 text-[#38bdf8] border-[#38bdf8]/40';
      case 'CHC/PHC Community Center':
        return 'bg-[#ffd166]/15 text-[#ffd166] border-[#ffd166]/40';
      default:
        return 'bg-purple-500/15 text-purple-300 border-purple-500/40';
    }
  };

  return (
    <section id="services" className="py-14 px-4 sm:px-6 lg:px-8 bg-[#040b12]">
      <div className="max-w-7xl mx-auto">
        
        {/* Category Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 pb-4 border-b border-white/10 gap-4">
          <div>
            <div className="flex items-center gap-2 text-[#00e5ff] text-xs font-extrabold tracking-widest uppercase">
              <span className="w-2 h-2 rounded-full bg-[#00e5ff] animate-ping" />
              <span>LIVE PAN-INDIA EMERGENCY DIRECTORY</span>
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight mt-1 capitalize">
              {category === 'hospital' && 'Pan-India Hospitals & Trauma Centers'}
              {category === 'ambulance' && 'On-Duty Ambulances & Paramedic Fleet'}
              {category === 'blood' && 'Blood Donors & Blood Component Banks'}
              {category === 'doctor' && 'Emergency Doctors & Specialists'}
              {category === 'pharmacy' && '24x7 Pharmacies & Emergency Chemists'}
              {category === 'lab' && 'Diagnostic Laboratories & STAT Testing'}
            </h2>
            <p className="text-xs sm:text-sm text-gray-400 mt-1">
              Real-time directory covering all Indian states, metros, district headquarters, and community health centers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {category === 'ambulance' && (
              <span className="text-xs font-semibold text-[#00ff9d] px-3 py-1 rounded-full bg-[#00ff9d]/10 border border-[#00ff9d]/30">
                ● Fleet Online with Live Paramedics
              </span>
            )}
            {category === 'blood' && (
              <button
                type="button"
                id="dir-req-blood-btn"
                onClick={onRequestBlood}
                className="px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-[#ff3150] hover:bg-[#ff1744] shadow-[0_0_12px_rgba(255,49,80,0.4)] transition-all"
              >
                + Post Blood Need
              </button>
            )}
          </div>
        </div>

        {/* Global View Mode Switcher (List View vs Map View) */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6 p-3 sm:p-4 rounded-2xl bg-black/50 border border-white/10 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="text-xs font-extrabold text-white uppercase tracking-wider">
              Display:
            </span>
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-black/60 border border-white/10">
              <button
                type="button"
                id="viewmode-list-btn"
                onClick={() => handleSetViewMode('list')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  activeViewMode === 'list'
                    ? 'bg-[#00e5ff] text-black shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>List View ({currentCategoryCount})</span>
              </button>

              <button
                type="button"
                id="viewmode-map-btn"
                onClick={() => handleSetViewMode('map')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  activeViewMode === 'map'
                    ? 'bg-[#00ff9d] text-black shadow-[0_0_12px_rgba(0,255,157,0.4)]'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Map className="w-3.5 h-3.5" />
                <span>Interactive Map View (मैप में देखें)</span>
              </button>
            </div>
          </div>

          <div className="text-xs text-gray-400 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00ff9d] animate-ping" />
            <span>
              Showing {currentCategoryCount} {category} facilities
              {searchLocation ? ` near "${searchLocation}"` : ' across India'}
            </span>
          </div>
        </div>

        {/* INTERACTIVE MAP VIEW (IF ACTIVE) */}
        {activeViewMode === 'map' && (
          <div className="mb-8">
            <FacilityMapView
              category={category}
              hospitals={hospitals}
              ambulances={ambulances}
              bloodDonors={bloodDonors}
              doctors={doctors}
              pharmacies={pharmacies}
              labs={labs}
              searchLocation={searchLocation}
              onSelectHospital={onSelectHospital}
              onTrackAmbulance={onTrackAmbulance}
              onRequestBlood={onRequestBlood}
              onSelectCategory={onSelectCategory}
              onLocationDetected={onLocationDetected}
            />
          </div>
        )}

        {/* RESULTS GRID BASED ON CATEGORY (IF LIST VIEW) */}
        {activeViewMode === 'list' && (
          <div>
            {/* 1. HOSPITALS */}
            {category === 'hospital' && (
              <div>
                {hospitals.length === 0 ? (
                  <div className="text-center py-16 px-4 rounded-3xl bg-black/40 border border-white/10 max-w-2xl mx-auto">
                    <Hospital className="w-12 h-12 text-gray-500 mx-auto mb-3" />
                    <h3 className="text-lg font-bold text-white mb-2">No Hospitals Matching Your Filter</h3>
                    <p className="text-xs sm:text-sm text-gray-400 mb-6">
                      Try clearing specific filters (like Ayushman or Tier) or search for another village or district like Pipraich, Babhnan, Kachhauna, Gorakhpur, Lucknow, Patna, etc.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {hospitals.map((hosp) => (
                      <div
                        key={hosp.id}
                        onClick={() => onSelectHospital?.(hosp)}
                        className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#00e5ff]/50 hover:shadow-[0_15px_40px_rgba(0,229,255,0.1)] transition-all flex flex-col justify-between group cursor-pointer"
                      >
                        <div>
                          {/* Top Badges: Tier & Rating */}
                          <div className="flex items-start justify-between gap-2 mb-2">
                            <div className="flex flex-wrap items-center gap-1.5">
                              <span className={`inline-block px-2.5 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wide border ${getTierColor(hosp.tier)}`}>
                                {hosp.tier || hosp.type}
                              </span>
                              {hosp.ayushmanBharat && (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-extrabold bg-[#00ff9d]/15 text-[#00ff9d] border border-[#00ff9d]/30" title="Ayushman Bharat (PM-JAY) Empanelled: 100% Free Treatment">
                                  <ShieldCheck className="w-3 h-3" />
                                  <span>PM-JAY Free</span>
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-lg border border-white/10 text-xs font-bold text-[#ffd166] shrink-0">
                              <Star className="w-3.5 h-3.5 fill-[#ffd166]" />
                              <span>{hosp.rating}</span>
                            </div>
                          </div>

                          {/* Hospital Name */}
                          <h3 className="font-extrabold text-lg text-white group-hover:text-[#00e5ff] transition-colors leading-snug mb-1">
                            {hosp.name}
                          </h3>

                          {/* Location & State */}
                          <div className="flex items-center gap-2 text-xs text-[#a0b6c2] mb-3">
                            <MapPin className="w-3.5 h-3.5 text-[#00e5ff] shrink-0" />
                            <span className="line-clamp-1">{hosp.area}, {hosp.city}{hosp.state ? ` (${hosp.state})` : ''}</span>
                            {hosp.pincode && <span className="text-[10px] text-gray-400 font-mono">Pin: {hosp.pincode}</span>}
                          </div>

                          {/* Emergency Proximity & 24x7 Open Status */}
                          <div className="flex items-center gap-2 text-xs font-bold text-[#00ff9d] mb-4">
                            <span>📍 ~{hosp.distanceKm} km away</span>
                            <span>•</span>
                            <span className="text-[#ffd166]">24/7 Level-1 Emergency</span>
                            {hosp.bedsCapacity && (
                              <>
                                <span>•</span>
                                <span className="text-gray-300 font-semibold">{hosp.bedsCapacity} Beds</span>
                              </>
                            )}
                          </div>

                          {/* Bed & Critical Care Stats */}
                          <div className="grid grid-cols-2 gap-2 mb-3 p-3 rounded-xl bg-black/30 border border-white/10 text-xs">
                            <div>
                              <div className="text-[10px] text-gray-400 flex items-center gap-1">
                                <Bed className="w-3 h-3 text-[#00e5ff]" /> ICU Beds Available
                              </div>
                              <div className="text-base font-extrabold text-white">
                                <span className="text-[#00ff9d]">{hosp.icuBedsAvailable}</span> / {hosp.totalIcuBeds} Free
                              </div>
                            </div>
                            <div>
                              <div className="text-[10px] text-gray-400 flex items-center gap-1">
                                <Wind className="w-3 h-3 text-[#38bdf8]" /> Oxygen Reserve
                              </div>
                              <div className="text-sm font-bold text-white">
                                {hosp.oxygenAvailable ? 'Available 100%' : 'Limited'}
                              </div>
                            </div>
                          </div>

                          {/* Specialties tags */}
                          <div className="flex flex-wrap gap-1.5 mb-3">
                            {hosp.specialties.slice(0, 3).map((spec, i) => (
                              <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-gray-300 border border-white/10">
                                {spec}
                              </span>
                            ))}
                            {hosp.bloodBankAttached && (
                              <span className="text-[10px] px-2 py-0.5 rounded bg-[#ff3150]/15 text-[#ff4d67] border border-[#ff3150]/30 font-semibold">
                                Blood Bank
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Card Action Buttons */}
                        <div className="pt-3 border-t border-white/10 space-y-2" onClick={(e) => e.stopPropagation()}>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => onSelectHospital?.(hosp)}
                              className="py-2 px-2.5 rounded-xl bg-[#00e5ff]/15 hover:bg-[#00e5ff]/25 text-[#00e5ff] border border-[#00e5ff]/40 text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(0,229,255,0.15)]"
                            >
                              <Activity className="w-3.5 h-3.5" />
                              <span>Full Details</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                handleSetViewMode('map');
                                window.scrollTo({ top: document.getElementById('services')?.offsetTop || 400, behavior: 'smooth' });
                              }}
                              className="py-2 px-2.5 rounded-xl bg-[#00ff9d]/15 hover:bg-[#00ff9d]/25 text-[#00ff9d] border border-[#00ff9d]/40 text-xs font-extrabold transition-all flex items-center justify-center gap-1.5"
                            >
                              <Map className="w-3.5 h-3.5" />
                              <span>View on Map</span>
                            </button>
                          </div>

                          <div className="grid grid-cols-2 gap-2">
                            <a
                              href={`tel:${hosp.emergencyPhone}`}
                              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-extrabold shadow-[0_4px_15px_rgba(255,49,80,0.3)] transition-all"
                            >
                              <Phone className="w-3.5 h-3.5 animate-pulse" />
                              <span>Emergency Call</span>
                            </a>

                            <a
                              href={getMapsUrl(hosp.name, hosp.address)}
                              target="_blank"
                              rel="noreferrer"
                              className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/15 text-xs font-bold transition-all"
                            >
                              <Navigation className="w-3.5 h-3.5 text-[#00e5ff]" />
                              <span>Get Route</span>
                            </a>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* 2. AMBULANCES */}
            {category === 'ambulance' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ambulances.map((amb) => (
              <div
                key={amb.id}
                className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#ff3150]/50 hover:shadow-[0_15px_40px_rgba(255,49,80,0.15)] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className="inline-block px-2.5 py-0.5 rounded-md text-[10px] font-extrabold uppercase tracking-wide bg-[#ff3150]/15 text-[#ff4d67] border border-[#ff3150]/30 mb-1">
                        {amb.ambulanceType}
                      </span>
                      <h3 className="font-extrabold text-lg text-white group-hover:text-[#00e5ff] transition-colors leading-snug">
                        {amb.providerName}
                      </h3>
                      <div className="text-xs text-gray-400 font-mono">{amb.vehicleNumber}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-extrabold text-[#00ff9d] animate-pulse">
                        ● Available Now
                      </div>
                      <div className="text-[11px] text-gray-400">ETA ~{amb.etaMinutes} mins</div>
                    </div>
                  </div>

                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1.5 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span>Base: {amb.baseLocation}, {amb.city} (~{amb.distanceKm} km)</span>
                  </p>

                  <div className="text-xs text-gray-300 mb-3">
                    Driver / Paramedic: <span className="font-semibold text-white">{amb.driverName}</span>
                  </div>

                  {/* Facilities Onboard */}
                  <div className="p-3 rounded-xl bg-black/30 border border-white/10 mb-4">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      On-Board ICU Equipment:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {amb.facilities.map((fac, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-gray-200 border border-white/10">
                          {fac}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs font-semibold text-gray-300 mb-4 px-1">
                    <span>Estimate Fare:</span>
                    <span className="text-[#00ff9d] font-bold">{amb.priceEstimate}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${amb.phone}`}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-extrabold shadow-[0_4px_15px_rgba(255,49,80,0.3)] transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call ({amb.phone})</span>
                  </a>

                  <button
                    type="button"
                    onClick={() => onTrackAmbulance(amb)}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#00e5ff]/15 hover:bg-[#00e5ff]/25 text-[#00e5ff] border border-[#00e5ff]/40 text-xs font-bold transition-all"
                  >
                    <Activity className="w-3.5 h-3.5" />
                    <span>Track Live GPS</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 3. BLOOD DONORS */}
        {category === 'blood' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {bloodDonors.map((donor) => (
              <div
                key={donor.id}
                className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#ff4d67]/50 hover:shadow-[0_15px_40px_rgba(255,77,103,0.15)] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#ff3150] to-[#b90029] flex items-center justify-center text-white font-black text-2xl shadow-[0_0_20px_rgba(255,49,80,0.5)]">
                      {donor.bloodGroup}
                    </div>
                    <div className="text-right">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#00ff9d]/15 text-[#00ff9d] border border-[#00ff9d]/30 mb-1">
                        {donor.unitsAvailable} Units Stock
                      </span>
                      <div className="text-[11px] text-gray-300 font-semibold">{donor.availability}</div>
                    </div>
                  </div>

                  <h3 className="font-extrabold text-base text-white group-hover:text-[#00e5ff] transition-colors leading-snug mb-1">
                    {donor.name}
                  </h3>

                  <div className="text-xs text-gray-400 mb-2">
                    Type: <span className="text-gray-200 font-medium">{donor.donorType}</span>
                  </div>

                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-[#00e5ff] shrink-0" />
                    <span>{donor.area}, {donor.city} (~{donor.distanceKm} km)</span>
                  </p>

                  <div className="text-[11px] text-[#ffd166] p-2 rounded-lg bg-black/30 border border-white/10 mb-4">
                    Status: {donor.lastDonation}
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10">
                  <a
                    href={`tel:${donor.phone}`}
                    className="w-full flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-extrabold shadow-[0_4px_15px_rgba(255,49,80,0.3)] transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Donor / Bank ({donor.phone})</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 4. DOCTORS */}
        {category === 'doctor' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {doctors.map((doc) => (
              <div
                key={doc.id}
                className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#38bdf8]/50 hover:shadow-[0_15px_40px_rgba(56,189,248,0.15)] transition-all flex flex-col justify-between group"
              >
                <div>
                  {/* Doctor Type & Badges */}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="inline-block px-2.5 py-0.5 rounded text-[10px] font-bold bg-[#38bdf8]/15 text-[#38bdf8] border border-[#38bdf8]/30">
                        {doc.doctorType || 'Specialist Doctor'}
                      </span>
                      {doc.ayushmanEligible && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-[#00ff9d]/15 text-[#00ff9d] border border-[#00ff9d]/30">
                          <ShieldCheck className="w-3 h-3" />
                          <span>PM-JAY</span>
                        </span>
                      )}
                      {doc.teleConsultation && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                          <Video className="w-3 h-3" />
                          <span>Tele-OPD</span>
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-lg border border-white/10 text-xs font-bold text-[#ffd166] shrink-0">
                      <Star className="w-3.5 h-3.5 fill-[#ffd166]" />
                      <span>{doc.rating}</span>
                    </div>
                  </div>

                  {/* Doctor Name & Specialty */}
                  <h3 className="font-extrabold text-lg text-white group-hover:text-[#00e5ff] transition-colors leading-snug">
                    {doc.name}
                  </h3>
                  <div className="text-xs font-bold text-[#00e5ff] mt-0.5">{doc.specialty}</div>
                  <div className="text-xs text-gray-400 mt-1">{doc.degrees} • {doc.experienceYears}+ yrs experience</div>

                  {/* Hospital Affiliation */}
                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1.5 mt-2.5">
                    <Hospital className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className="font-semibold text-gray-200">{doc.hospital}</span>
                  </p>

                  {/* Location & State */}
                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1.5 mt-1.5">
                    <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span>{doc.area}, {doc.city}{doc.state ? ` (${doc.state})` : ''} (~{doc.distanceKm} km)</span>
                  </p>

                  {/* OPD Timings */}
                  {doc.opdTimings && (
                    <div className="text-[11px] text-gray-300 flex items-center gap-1.5 mt-2 bg-black/20 px-2 py-1 rounded border border-white/5">
                      <Clock className="w-3 h-3 text-[#00ff9d] shrink-0" />
                      <span>OPD: {doc.opdTimings}</span>
                    </div>
                  )}

                  {/* Spoken Languages */}
                  {doc.languages && doc.languages.length > 0 && (
                    <div className="flex items-center gap-1 text-[11px] text-gray-400 mt-2">
                      <Languages className="w-3 h-3 text-gray-500 shrink-0" />
                      <span>Languages: {doc.languages.join(', ')}</span>
                    </div>
                  )}

                  {/* Fee & Availability */}
                  <div className="flex items-center justify-between text-xs p-2.5 rounded-xl bg-black/30 border border-white/10 mt-3 mb-4">
                    <span className="text-gray-400">Mode: {doc.consultationType}</span>
                    <span className="font-bold text-[#00ff9d]">{doc.fee}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${doc.phone}`}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#38bdf8]/20 hover:bg-[#38bdf8]/30 text-[#38bdf8] border border-[#38bdf8]/40 text-xs font-extrabold transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call ({doc.phone})</span>
                  </a>

                  <a
                    href={getMapsUrl(doc.name, `${doc.hospital}, ${doc.city}`)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/15 text-xs font-bold transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#00e5ff]" />
                    <span>Hospital Route</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 5. PHARMACIES */}
        {category === 'pharmacy' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pharmacies.map((phm) => (
              <div
                key={phm.id}
                className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#00ff9d]/50 hover:shadow-[0_15px_40px_rgba(0,255,157,0.15)] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#00ff9d]/15 text-[#00ff9d] border border-[#00ff9d]/30 mb-1">
                        {phm.open247 ? '24/7 ALL NIGHT OPEN' : 'Day Store'}
                      </span>
                      <h3 className="font-extrabold text-lg text-white group-hover:text-[#00e5ff] transition-colors leading-snug">
                        {phm.name}
                      </h3>
                    </div>
                    <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-lg border border-white/10 text-xs font-bold text-[#ffd166]">
                      <Star className="w-3.5 h-3.5 fill-[#ffd166]" />
                      <span>{phm.rating}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1.5 mb-3">
                    <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span>{phm.address} (~{phm.distanceKm} km)</span>
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-xs p-2.5 rounded-xl bg-black/30 border border-white/10 mb-4">
                    <div>
                      <span className="text-[10px] text-gray-400 block">Emergency Stock:</span>
                      <span className="font-bold text-white">Full In-Stock</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-400 block">Home Delivery:</span>
                      <span className="font-bold text-[#00ff9d]">
                        {phm.homeDelivery ? `~${phm.deliveryEtaMinutes} mins` : 'Pickup only'}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${phm.phone}`}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#00ff9d]/20 to-[#00ff9d]/30 hover:bg-[#00ff9d]/40 text-[#00ff9d] border border-[#00ff9d]/40 text-xs font-extrabold transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Chemist</span>
                  </a>

                  <a
                    href={getMapsUrl(phm.name, phm.address)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/15 text-xs font-bold transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#00e5ff]" />
                    <span>Route</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* 6. DIAGNOSTIC LABS */}
        {category === 'lab' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {labs.map((lab) => (
              <div
                key={lab.id}
                className="rounded-2xl bg-gradient-to-b from-[#0a1e2d]/80 to-[#061421]/90 border border-white/15 p-5 shadow-xl hover:border-[#ffd166]/50 hover:shadow-[0_15px_40px_rgba(255,209,102,0.15)] transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#ffd166]/15 text-[#ffd166] border border-[#ffd166]/30 mb-1">
                        {lab.open247EmergencyTesting ? '24/7 STAT EMERGENCY TESTING' : 'Standard Diagnostics'}
                      </span>
                      <h3 className="font-extrabold text-lg text-white group-hover:text-[#00e5ff] transition-colors leading-snug">
                        {lab.name}
                      </h3>
                    </div>
                    <div className="flex items-center gap-1 bg-black/40 px-2 py-1 rounded-lg border border-white/10 text-xs font-bold text-[#ffd166]">
                      <Star className="w-3.5 h-3.5 fill-[#ffd166]" />
                      <span>{lab.rating}</span>
                    </div>
                  </div>

                  <p className="text-xs text-[#a0b6c2] flex items-center gap-1.5 mb-2">
                    <MapPin className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span>{lab.address} (~{lab.distanceKm} km)</span>
                  </p>

                  <div className="text-xs text-[#00ff9d] mb-3 font-semibold">
                    ⏱️ Report Delivery: {lab.turnaroundTime}
                  </div>

                  <div className="p-3 rounded-xl bg-black/30 border border-white/10 mb-4">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider block mb-1">
                      Key Tests Available:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {lab.testsAvailable.map((t, idx) => (
                        <span key={idx} className="text-[10px] px-2 py-0.5 rounded bg-white/5 text-gray-200 border border-white/10">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/10 grid grid-cols-2 gap-2">
                  <a
                    href={`tel:${lab.phone}`}
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ffd166]/20 to-[#ffd166]/30 hover:bg-[#ffd166]/40 text-[#ffd166] border border-[#ffd166]/40 text-xs font-extrabold transition-all"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Diagnostic Lab</span>
                  </a>

                  <a
                    href={getMapsUrl(lab.name, lab.address)}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-gray-200 hover:text-white border border-white/15 text-xs font-bold transition-all"
                  >
                    <Navigation className="w-3.5 h-3.5 text-[#00e5ff]" />
                    <span>Get Directions</span>
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Empty state if nothing matches */}
        {((category === 'hospital' && hospitals.length === 0) ||
          (category === 'ambulance' && ambulances.length === 0) ||
          (category === 'blood' && bloodDonors.length === 0) ||
          (category === 'doctor' && doctors.length === 0) ||
          (category === 'pharmacy' && pharmacies.length === 0) ||
          (category === 'lab' && labs.length === 0)) && (
          <div className="p-10 text-center rounded-2xl bg-white/[0.03] border border-white/10 max-w-xl mx-auto">
            <AlertCircle className="w-12 h-12 text-[#ff4d67] mx-auto mb-3" />
            <h3 className="text-lg font-bold text-white mb-1">No services found for this specific filter</h3>
            <p className="text-sm text-gray-400 mb-4">
              Try selecting "All India" or clearing specific tier/Ayushman filters, or immediately dial national emergency services.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href="tel:112"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#ff3150] text-white text-xs font-black shadow-[0_0_15px_rgba(255,49,80,0.4)]"
              >
                <Phone className="w-4 h-4" />
                <span>Call Emergency Dispatch: 112</span>
              </a>
              <a
                href="tel:108"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#00e5ff]/20 border border-[#00e5ff]/40 text-[#00e5ff] text-xs font-bold"
              >
                <Ambulance className="w-4 h-4" />
                <span>Call 108 Ambulance</span>
              </a>
            </div>
          </div>
        )}
      </div>
    )}

      </div>
    </section>
  );
};
