import React from 'react';
import { 
  Sun, 
  Phone, 
  Mail, 
  MapPin, 
  Award, 
  ShieldCheck, 
  Clock, 
  Heart,
  ChevronRight,
  Biohazard
} from 'lucide-react';
import { SURYA_HOSPITAL } from '../data/suryaHospitalData';

interface SuryaFooterProps {
  onNavigateToTab: (tab: 'article' | 'az-directory' | 'packages' | 'doctors' | 'screener') => void;
  onOpenAppointment: () => void;
  isHindi: boolean;
}

export const SuryaFooter: React.FC<SuryaFooterProps> = ({
  onNavigateToTab,
  onOpenAppointment,
  isHindi
}) => {
  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-12 border-t border-slate-800 text-xs sm:text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top 4-Column Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Col 1: Hospital Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-white shadow-md shadow-orange-500/20">
                <Sun className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="font-black text-lg text-white tracking-tight">
                  SURYA <span className="text-amber-500">HOSPITAL</span>
                </span>
                <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider">
                  Medical Research & Critical Care
                </p>
              </div>
            </div>
            
            <p className="text-slate-400 text-xs leading-relaxed">
              {SURYA_HOSPITAL.tagline}. Leading clinical expertise in viral fevers, infectious diseases, cardiopulmonary intensive care, and preventive diagnostics.
            </p>

            <div className="space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>NABH & NABL Accredited Care</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>24x7 Casualty, MICU & Blood Bank</span>
              </div>
            </div>
          </div>

          {/* Col 2: A-Z Diseases Guide */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider flex items-center gap-1.5">
              <Biohazard className="w-4 h-4 text-amber-400" />
              <span>{isHindi ? "A-Z रोग डायरेक्टरी" : "A-Z Disease Knowledge"}</span>
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button 
                  onClick={() => onNavigateToTab('article')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-amber-500" />
                  <span className="text-amber-300 font-semibold">Hantavirus (HPS & HFRS Guide)</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateToTab('az-directory')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Dengue Hemorrhagic Fever</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateToTab('az-directory')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Leptospirosis (Weil's Disease)</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateToTab('az-directory')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Scrub Typhus & Rickettsia</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateToTab('az-directory')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Nipah Henipavirus</span>
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigateToTab('az-directory')}
                  className="hover:text-amber-400 transition flex items-center gap-1.5"
                >
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Rabies & Animal Bite Protocol</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Portals */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">
              {isHindi ? "त्वरित लिंक्स" : "Hospital Portals"}
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button onClick={() => onNavigateToTab('packages')} className="hover:text-amber-400 transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Viral Fever & Infectious Checkups</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateToTab('packages')} className="hover:text-amber-400 transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Advanced Pulmonary & Lung Testing</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateToTab('doctors')} className="hover:text-amber-400 transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Specialist OPD Doctors List</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateToTab('screener')} className="hover:text-amber-400 transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Interactive Symptom Self-Triage</span>
                </button>
              </li>
              <li>
                <button onClick={onOpenAppointment} className="hover:text-amber-400 transition flex items-center gap-1.5">
                  <ChevronRight className="w-3 h-3 text-slate-600" />
                  <span>Book In-Person / Video Consultation</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & 24x7 Help */}
          <div className="space-y-3">
            <h4 className="text-white font-bold text-sm uppercase tracking-wider">
              {isHindi ? "संपर्क एवं आपातकाल" : "Contact & Emergency"}
            </h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                <span>{SURYA_HOSPITAL.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span className="text-white font-bold">24/7 Emergency: {SURYA_HOSPITAL.emergencyPhone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <span>Ambulance: {SURYA_HOSPITAL.ambulancePhone}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-400 flex-shrink-0" />
                <span>{SURYA_HOSPITAL.email}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Medical Education Disclaimer */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-[11px] text-slate-400 leading-relaxed mb-8">
          <strong className="text-slate-300">Medical Content Disclaimer: </strong>
          The health articles and disease encyclopedia content on this portal are authored and reviewed by Surya Hospital medical faculty for educational awareness and public health enlightenment only. This information should not be used as a standalone substitute for professional clinical diagnosis or emergency medical care. If you experience severe symptoms such as difficulty breathing, cyanosis, or high unremitting fever, contact our emergency triage team immediately.
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Surya Hospital & Medical Research Centre. All Rights Reserved.</p>
          <div className="flex items-center space-x-4">
            <span className="hover:text-slate-400 cursor-pointer">Privacy Policy</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Patient Rights & Responsibilities</span>
            <span>•</span>
            <span className="hover:text-slate-400 cursor-pointer">Clinical Governance</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
