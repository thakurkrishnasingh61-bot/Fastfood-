import React, { useState } from 'react';
import { 
  UserCheck, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  ArrowRight, 
  RotateCcw, 
  Stethoscope, 
  Calendar, 
  PhoneCall, 
  HeartPulse, 
  Wind, 
  Bug, 
  Activity 
} from 'lucide-react';
import { SURYA_HOSPITAL } from '../data/suryaHospitalData';

interface SymptomScreenerViewProps {
  onOpenAppointment: (dept?: string, doctor?: string) => void;
  onOpenEmergency: () => void;
  isHindi: boolean;
}

export const SymptomScreenerView: React.FC<SymptomScreenerViewProps> = ({
  onOpenAppointment,
  onOpenEmergency,
  isHindi
}) => {
  // Questions states
  const [exposureScore, setExposureScore] = useState<string[]>([]);
  const [feverStatus, setFeverStatus] = useState<string>('');
  const [respiratorySymptoms, setRespiratorySymptoms] = useState<string[]>([]);
  const [otherSymptoms, setOtherSymptoms] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  const toggleExposure = (item: string) => {
    if (exposureScore.includes(item)) {
      setExposureScore(exposureScore.filter(i => i !== item));
    } else {
      setExposureScore([...exposureScore, item]);
    }
  };

  const toggleRespiratory = (item: string) => {
    if (respiratorySymptoms.includes(item)) {
      setRespiratorySymptoms(respiratorySymptoms.filter(i => i !== item));
    } else {
      setRespiratorySymptoms([...respiratorySymptoms, item]);
    }
  };

  const toggleOther = (item: string) => {
    if (otherSymptoms.includes(item)) {
      setOtherSymptoms(otherSymptoms.filter(i => i !== item));
    } else {
      setOtherSymptoms([...otherSymptoms, item]);
    }
  };

  const handleReset = () => {
    setExposureScore([]);
    setFeverStatus('');
    setRespiratorySymptoms([]);
    setOtherSymptoms([]);
    setSubmitted(false);
  };

  // Calculate triage risk
  const calculateTriage = () => {
    const hasSevereRespiratory = respiratorySymptoms.includes('dyspnea_rest') || respiratorySymptoms.includes('low_spo2');
    const hasExposure = exposureScore.length > 0;
    const hasHighFever = feverStatus === 'high';
    const hasMyalgia = otherSymptoms.includes('severe_myalgia');

    if (hasSevereRespiratory) {
      return {
        level: 'CRITICAL EMERGENCY (RED TRIAGE)',
        hindiLevel: 'अत्यंत गंभीर - तुरंत आपातकालीन चिकित्सा आवश्यक',
        color: 'border-rose-500 bg-rose-50 text-rose-900',
        badge: 'bg-rose-600 text-white',
        icon: ShieldAlert,
        summary: isHindi
          ? 'चेतावनी: आपकी सांस फूल रही है या ऑक्सीजन का स्तर कम है। यदि चूहों या धूल के संपर्क का इतिहास है तो यह तीव्र हंतावायरस पल्मोनरी सिंड्रोम (HPS) या गंभीर निमोनिया हो सकता है।'
          : 'High Alert: Severe respiratory distress, breathlessness at rest, or low SpO2 combined with systemic signs requires immediate hospital emergency triage. Immediate Level-3 ICU assessment is indicated.',
        recommendedTests: [
          'High-Resolution Chest CT / Digital X-Ray (Immediate)',
          'Arterial Blood Gas (ABG) for Hypoxia & Acidosis',
          'Stat Complete Blood Count (Platelet indices & Hematocrit)',
          'Hantavirus IgM & Multiplex Viral PCR Panel'
        ],
        action: 'emergency'
      };
    }

    if (hasExposure && (hasHighFever || hasMyalgia)) {
      return {
        level: 'HIGH SUSPICION / MODERATE-TO-HIGH RISK (YELLOW TRIAGE)',
        hindiLevel: 'मध्यम से उच्च जोखिम - तत्काल विशेषज्ञ जांच आवश्यक',
        color: 'border-amber-500 bg-amber-50 text-amber-900',
        badge: 'bg-amber-600 text-white',
        icon: AlertTriangle,
        summary: isHindi
          ? 'चूहों या धूल के संपर्क के बाद तेज बुखार और मांसपेशियों में तीव्र दर्द हंतावायरस के शुरुआती स्टेज (Prodromal Phase) या अन्य जूनोटिक रोग (लेप्टोस्पायरोसिस/स्क्रब टाइफस) का संकेत हो सकता है।'
          : 'Significant Risk: History of rodent/dust exposure accompanied by high fever and severe myalgia matches the early prodromal phase of Hantavirus or Leptospirosis. Prompt physician consultation is advised before pulmonary complications trigger.',
        recommendedTests: [
          'Surya Comprehensive Viral Fever & Infectious Panel (₹1,499)',
          'Hantavirus IgM/IgG Serological Screen',
          'Complete Blood Count & Platelet Count',
          'Kidney & Liver Function Profile'
        ],
        action: 'consultation'
      };
    }

    return {
      level: 'LOW IMMEDIATE RISK (GREEN TRIAGE)',
      hindiLevel: 'कम जोखिम - सामान्य निगरानी रखें',
      color: 'border-emerald-500 bg-emerald-50 text-emerald-900',
      badge: 'bg-emerald-600 text-white',
      icon: CheckCircle2,
      summary: isHindi
        ? 'आपके वर्तमान लक्षण हंतावायरस के गंभीर संकेत नहीं दिखाते हैं। हालांकि अपने तापमान और पल्स ऑक्सीमीटर पर निगरानी रखें।'
        : 'Your inputs currently do not indicate severe cardiopulmonary distress or high-probability zoonotic exposure. Continue monitoring your temperature and stay hydrated. Consult an OPD doctor if symptoms persist beyond 48 hours.',
      recommendedTests: [
        'Routine Fever & CBC Profile',
        'Resting Pulse Oximetry (SpO2 Check)'
      ],
      action: 'opd'
    };
  };

  const triage = calculateTriage();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Tool Header */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200 mb-3">
          <UserCheck className="w-3.5 h-3.5 text-amber-700" />
          <span>Surya Clinical Self-Triage Engine</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
          {isHindi ? "हंतावायरस एवं जूनोटिक लक्षण स्व-मूल्यांकन" : "Hantavirus & Zoonotic Exposure Screener"}
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm">
          {isHindi
            ? "चूहों के संपर्क, बुखार और सांस की तकलीफ का आकलन कर तुरंत चिकित्सीय सलाह प्राप्त करें।"
            : "Clinically structured self-triage tool to identify early signs of HPS, rodent-borne infections, and respiratory warning indicators."}
        </p>
      </div>

      {/* Main Screener Form */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-8">
        
        {/* Step 1: Exposure */}
        <div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-3">
            <Bug className="w-5 h-5 text-amber-600" />
            <h3>1. {isHindi ? "पर्यावरणीय या चूहों के संपर्क का इतिहास (पिछले 1-8 सप्ताह)" : "Environmental & Rodent Exposure History (Past 1–8 Weeks)"}</h3>
          </div>
          <p className="text-xs text-slate-500 mb-3">Select all that apply to you:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { id: 'cleaned_shed', label: 'Cleaned a closed shed, garage, attic, or dusty cabin' },
              { id: 'saw_droppings', label: 'Observed mouse droppings, nests, or urine in premises' },
              { id: 'swept_dry', label: 'Swept with a dry broom or vacuumed dry dusty storage spaces' },
              { id: 'rural_camping', label: 'Went rural camping or handled farm grains/livestock feeds' }
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => toggleExposure(item.id)}
                className={`text-left p-3 rounded-xl border text-xs sm:text-sm transition flex items-start gap-2.5 ${
                  exposureScore.includes(item.id)
                    ? 'bg-amber-50 border-amber-500 text-amber-900 font-medium'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className={`w-4 h-4 rounded border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                  exposureScore.includes(item.id) ? 'bg-amber-600 border-amber-600 text-white' : 'border-slate-300'
                }`}>
                  {exposureScore.includes(item.id) && <CheckCircle2 className="w-3 h-3" />}
                </div>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Fever */}
        <div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-3">
            <HeartPulse className="w-5 h-5 text-amber-600" />
            <h3>2. {isHindi ? "बुखार और तापमान की स्थिति" : "Body Temperature & Fever Status"}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {[
              { id: 'none', label: 'No Fever (Normal Temp)' },
              { id: 'mild', label: 'Mild to Moderate Fever (99°F – 101°F)' },
              { id: 'high', label: 'High Spike Fever (>101°F / 38.3°C)' }
            ].map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setFeverStatus(opt.id)}
                className={`text-left p-3 rounded-xl border text-xs sm:text-sm transition flex items-center gap-2.5 ${
                  feverStatus === opt.id
                    ? 'bg-amber-50 border-amber-500 text-amber-900 font-bold'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${
                  feverStatus === opt.id ? 'border-amber-600 bg-amber-600 text-white' : 'border-slate-300'
                }`}>
                  {feverStatus === opt.id && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
                <span>{opt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Step 3: Respiratory Signs */}
        <div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-3">
            <Wind className="w-5 h-5 text-amber-600" />
            <h3>3. {isHindi ? "श्वसन संबंधी चेतावनी संकेत" : "Respiratory & Breathing Warning Signs"}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { id: 'dyspnea_rest', label: 'Shortness of breath / gasping for air even while resting' },
              { id: 'low_spo2', label: 'Oxygen level (SpO2) measuring below 94% on pulse oximeter' },
              { id: 'persistent_cough', label: 'Persistent dry cough that started after fever days' },
              { id: 'chest_heaviness', label: 'Tightness, burning or constriction sensation in chest' }
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => toggleRespiratory(item.id)}
                className={`text-left p-3 rounded-xl border text-xs sm:text-sm transition flex items-start gap-2.5 ${
                  respiratorySymptoms.includes(item.id)
                    ? 'bg-rose-50 border-rose-500 text-rose-900 font-medium'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className={`w-4 h-4 rounded border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                  respiratorySymptoms.includes(item.id) ? 'bg-rose-600 border-rose-600 text-white' : 'border-slate-300'
                }`}>
                  {respiratorySymptoms.includes(item.id) && <CheckCircle2 className="w-3 h-3" />}
                </div>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Step 4: Systemic Symptoms */}
        <div>
          <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-3">
            <Activity className="w-5 h-5 text-amber-600" />
            <h3>4. {isHindi ? "अन्य शारीरिक लक्षण" : "Other Systemic Manifestations"}</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { id: 'severe_myalgia', label: 'Intense muscle pain in thighs, hips, lower back or shoulders' },
              { id: 'nausea_vomiting', label: 'Gastrointestinal upset: nausea, vomiting or severe diarrhea' },
              { id: 'oliguria', label: 'Noticeable drop in urination frequency or very dark urine' },
              { id: 'dizziness', label: 'Extreme lightheadedness, vertigo or confusion' }
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => toggleOther(item.id)}
                className={`text-left p-3 rounded-xl border text-xs sm:text-sm transition flex items-start gap-2.5 ${
                  otherSymptoms.includes(item.id)
                    ? 'bg-amber-50 border-amber-500 text-amber-900 font-medium'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className={`w-4 h-4 rounded border mt-0.5 flex items-center justify-center flex-shrink-0 ${
                  otherSymptoms.includes(item.id) ? 'bg-amber-600 border-amber-600 text-white' : 'border-slate-300'
                }`}>
                  {otherSymptoms.includes(item.id) && <CheckCircle2 className="w-3 h-3" />}
                </div>
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-800 font-semibold"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All</span>
          </button>

          <button
            type="button"
            onClick={() => setSubmitted(true)}
            className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs sm:text-sm transition shadow-sm flex items-center gap-2"
          >
            <span>{isHindi ? "क्लीनिकल रिपोर्ट देखें" : "Generate Triage Assessment"}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* RESULTS CARD */}
        {submitted && (
          <div className={`rounded-2xl border-2 p-6 sm:p-7 transition-all ${triage.color}`}>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
              <span className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${triage.badge}`}>
                {isHindi ? triage.hindiLevel : triage.level}
              </span>
              <span className="text-xs text-slate-500 font-bold">Surya Medical Protocol v2.5</span>
            </div>

            <p className="text-sm sm:text-base leading-relaxed mb-6 font-medium">
              {triage.summary}
            </p>

            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-4 border border-slate-200/80 mb-6">
              <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-700 mb-2">
                Recommended Lab & Clinical Tests:
              </h4>
              <ul className="space-y-1.5 text-xs text-slate-700">
                {triage.recommendedTests.map((t, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              {triage.action === 'emergency' ? (
                <button
                  onClick={onOpenEmergency}
                  className="w-full sm:flex-1 bg-rose-600 hover:bg-rose-700 text-white font-extrabold py-3 rounded-xl text-sm shadow-md flex items-center justify-center gap-2 transition"
                >
                  <PhoneCall className="w-4 h-4 animate-bounce" />
                  <span>Call 24/7 Emergency Ambulance: {SURYA_HOSPITAL.emergencyPhone}</span>
                </button>
              ) : (
                <button
                  onClick={() => onOpenAppointment('Infectious Diseases', 'Dr. Rajesh Suryavanshi')}
                  className="w-full sm:flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-xl text-sm shadow-sm flex items-center justify-center gap-2 transition"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book Priority Consultation with Dr. Rajesh Suryavanshi</span>
                </button>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
