import React, { useState } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  ShieldAlert, 
  Phone, 
  Ambulance 
} from 'lucide-react';
import { FAQS_DATA, HOSPITAL_INFO } from '../data/hospitalData';

interface FaqHighwaySafetyProps {
  onOpenAmbulance: () => void;
  isHindi: boolean;
}

export const FaqHighwaySafety: React.FC<FaqHighwaySafetyProps> = ({
  onOpenAmbulance,
  isHindi
}) => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIdx(openIdx === index ? null : index);
  };

  return (
    <section className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: FAQs */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-bold uppercase tracking-wider mb-2">
                <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                <span>Patient Questions & Answers</span>
              </div>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">
                {isHindi ? "अक्सर पूछे जाने वाले प्रश्न" : "Frequently Asked Questions"}
              </h2>
              <p className="text-slate-600 text-sm mt-1">
                Everything you need to know about OPD consultation, ICU admission, Eye Hospital, and Dialysis.
              </p>
            </div>

            {/* Accordion */}
            <div className="space-y-3 pt-2">
              {FAQS_DATA.map((faq, idx) => {
                const isOpen = openIdx === idx;
                return (
                  <div 
                    key={idx}
                    className="border border-slate-200 rounded-2xl overflow-hidden transition-all bg-slate-50/50"
                  >
                    <button
                      onClick={() => toggleFaq(idx)}
                      className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4 font-bold text-slate-900 text-sm sm:text-base hover:bg-slate-100/70 transition"
                    >
                      <span>{isHindi && faq.hindiQuestion ? faq.hindiQuestion : faq.question}</span>
                      <span className="p-1 rounded-lg bg-white border border-slate-200 text-slate-500 shrink-0">
                        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </span>
                    </button>
                    {isOpen && (
                      <div className="px-5 pb-5 pt-1 text-slate-600 text-sm leading-relaxed border-t border-slate-200/60 bg-white">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Kanpur Road Highway Trauma Preparedness */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 to-red-950 text-white shadow-xl space-y-5">
              
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-red-600/30 text-red-400 flex items-center justify-center border border-red-500/30">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                    Kanpur Road (NH-25) Protocol
                  </span>
                  <h3 className="text-xl font-black text-white">
                    Highway Emergency Golden Hour
                  </h3>
                </div>
              </div>

              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                In severe vehicular accidents on Kanpur Road (NH-25), the first 60 minutes determine patient survival. Nova Shekhar Hospital casualty at MGIMT Campus provides zero-wait intake.
              </p>

              {/* 3 Step Action Guide */}
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-white/10 border border-white/10 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">1</div>
                  <div>
                    <span className="font-bold text-white block">Call Nova Casualty Line:</span>
                    <span className="text-slate-300">Dial 095550 14545 immediately and mention nearest kilometer stone / landmark.</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/10 border border-white/10 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">2</div>
                  <div>
                    <span className="font-bold text-white block">Do Not Crowd the Injured:</span>
                    <span className="text-slate-300">Ensure fresh airflow. Check breathing and control severe bleeding with clean pressure cloth.</span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/10 border border-white/10 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-red-600 text-white font-bold flex items-center justify-center shrink-0 text-xs">3</div>
                  <div>
                    <span className="font-bold text-white block">Head & Neck Immobilization:</span>
                    <span className="text-slate-300">Avoid twisting patient spine during extrication to prevent cervical cord injury.</span>
                  </div>
                </div>
              </div>

              {/* Emergency CTA Buttons */}
              <div className="pt-2 flex flex-wrap gap-3">
                <a
                  href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                  className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg transition"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call {HOSPITAL_INFO.phone}</span>
                </a>

                <button
                  onClick={onOpenAmbulance}
                  className="py-3 px-4 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold text-xs sm:text-sm transition"
                >
                  Dispatch Ambulance
                </button>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
