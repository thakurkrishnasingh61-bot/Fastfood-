import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [feedbackSent, setFeedbackSent] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackSent(true);
    setName('');
    setEmail('');
    setMessage('');
    setTimeout(() => setFeedbackSent(false), 5000);
  };

  return (
    <section id="contact" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#07131d] border-t border-white/10">
      <div className="max-w-5xl mx-auto">
        
        {/* Heading */}
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-[#00e5ff] inline-block mb-2">
            GET IN TOUCH
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Contact FAST MEDCAB
          </h2>
          <p className="text-sm sm:text-base text-[#9db3be] mt-2">
            Have a question, emergency hospital partner inquiry, or blood bank registration? We are here 24/7.
          </p>
        </div>

        {/* Quick Contact Links */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
          <a
            href="mailto:info@fastmedcab.com"
            className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-[#00e5ff]/40 text-center transition-all group"
          >
            <Mail className="w-6 h-6 text-[#00e5ff] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <div className="text-xs text-gray-400 font-semibold uppercase">Email Support</div>
            <div className="text-sm font-bold text-white mt-0.5">info@fastmedcab.com</div>
          </a>

          <a
            href="tel:112"
            className="p-5 rounded-2xl bg-gradient-to-b from-[#ff3150]/20 to-[#ff3150]/5 border border-[#ff3150]/40 text-center transition-all group"
          >
            <Phone className="w-6 h-6 text-[#ff3150] mx-auto mb-2 group-hover:scale-110 transition-transform" />
            <div className="text-xs text-[#ff99a8] font-semibold uppercase">Emergency Dispatch</div>
            <div className="text-sm font-black text-white mt-0.5">Dial 112 / 108</div>
          </a>

          <div className="p-5 rounded-2xl bg-white/[0.03] border border-white/10 text-center">
            <MapPin className="w-6 h-6 text-[#00ff9d] mx-auto mb-2" />
            <div className="text-xs text-gray-400 font-semibold uppercase">Headquarters</div>
            <div className="text-sm font-bold text-white mt-0.5">National Healthcare Corridor</div>
          </div>
        </div>

        {/* Feedback / Partnership Form */}
        <div className="p-6 sm:p-8 rounded-3xl bg-black/40 border border-white/10 max-w-2xl mx-auto">
          <h3 className="text-lg font-bold text-white mb-4 text-center">
            Send Us A Message or Hospital Partnership Request
          </h3>

          {feedbackSent ? (
            <div className="p-4 rounded-xl bg-[#00ff9d]/15 border border-[#00ff9d]/30 text-center text-[#00ff9d] text-xs font-bold flex items-center justify-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              <span>Thank you! Your message has been routed to our emergency liaison desk.</span>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-400 font-semibold mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Dr. / Mr. / Ms."
                    className="w-full p-3 rounded-xl bg-black/50 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                  />
                </div>
                <div>
                  <label className="block text-gray-400 font-semibold mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="contact@example.com"
                    className="w-full p-3 rounded-xl bg-black/50 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-400 font-semibold mb-1">Message</label>
                <textarea
                  rows={3}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="How can we help or collaborate?"
                  className="w-full p-3 rounded-xl bg-black/50 border border-white/15 text-white focus:border-[#00e5ff] outline-none resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#00e5ff] hover:bg-[#38bdf8] text-[#031017] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-[0_4px_15px_rgba(0,229,255,0.3)]"
              >
                <Send className="w-4 h-4" />
                <span>Send Message</span>
              </button>
            </form>
          )}
        </div>

      </div>
    </section>
  );
};
