import React from 'react';
import { 
  Phone, 
  ShieldAlert, 
  Ambulance, 
  Droplet, 
  HeartHandshake, 
  ArrowUp,
  MapPin,
  Radio,
  Clock,
  Award
} from 'lucide-react';
import { EMERGENCY_NUMBERS } from '../data/mockData';

interface FastMedCabFooterProps {
  onOpenSos: () => void;
  onOpenAmbulanceDispatch: () => void;
  onOpenBloodRequest: () => void;
  onOpenAyushman: () => void;
  isHindi: boolean;
}

export const FastMedCabFooter: React.FC<FastMedCabFooterProps> = ({
  onOpenSos,
  onOpenAmbulanceDispatch,
  onOpenBloodRequest,
  onOpenAyushman,
  isHindi,
}) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#02070c] text-slate-400 pt-16 pb-12 border-t border-cyan-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Emergency Action Banner */}
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-red-950/60 via-[#13070b] to-[#04111c] border border-rose-500/30 mb-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span>National Emergency Lifeline</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-white">
              {isHindi ? 'क्या आप किसी आपात स्थिति का सामना कर रहे हैं?' : 'Need Immediate Emergency Assistance?'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              {isHindi 
                ? 'तुरंत 112 (राष्ट्रीय आपातकाल) या 108 (सरकारी एम्बुलेंस) पर कॉल करें या फास्ट मेडकैब एसओएस सक्रिय करें।'
                : 'Dial 112 or 108 immediately for government fast dispatch rescue, or trigger the FAST MEDCAB SOS protocol.'
              }
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={onOpenSos}
              className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs sm:text-sm shadow-[0_0_25px_rgba(255,49,80,0.5)] transition flex items-center gap-2"
            >
              <ShieldAlert className="w-4 h-4 animate-bounce" />
              <span>TRIGGER SOS NOW</span>
            </button>

            <a
              href="tel:108"
              className="px-6 py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm border border-white/20 transition flex items-center gap-2"
            >
              <Ambulance className="w-4 h-4 text-amber-400" />
              <span>Dial 108 Ambulance</span>
            </a>
          </div>
        </div>

        {/* 4 Columns Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 pb-12 border-b border-slate-800 text-xs">
          
          {/* Col 1 & 2: Branding & Description */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-cyan-600 flex items-center justify-center text-white font-black text-xl shadow-lg">
                <Ambulance className="w-5 h-5" />
              </div>
              <div>
                <span className="font-black text-lg text-white tracking-tight">
                  FAST MEDCAB
                </span>
                <p className="text-[11px] text-cyan-400 font-medium">
                  India's 24/7 Emergency Healthcare Grid
                </p>
              </div>
            </div>

            <p className="text-slate-400 leading-relaxed max-w-sm">
              FAST MEDCAB is an open emergency infrastructure tool unifying real-time hospital bed statuses, oxygen reserves, 108 & private ambulance dispatch, verified blood donors, and 24/7 on-call trauma teams across urban and rural India.
            </p>

            <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-xs">
                <Award className="w-4 h-4" />
                <span>Good Samaritan Law Protection</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal">
                Under Supreme Court guidelines, citizens aiding accident victims are protected from police detention, financial deposits, or witness harassment.
              </p>
            </div>
          </div>

          {/* Col 3: National Helplines */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-white uppercase tracking-wider">
              Emergency Numbers
            </h4>
            <ul className="space-y-2.5">
              {EMERGENCY_NUMBERS.map((num) => (
                <li key={num.number} className="flex flex-col">
                  <a
                    href={`tel:${num.number.replace(/[^0-9]/g, '')}`}
                    className="font-bold text-slate-200 hover:text-cyan-400 transition flex items-center justify-between"
                  >
                    <span>{num.name}</span>
                    <span className="px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800 text-rose-300 font-mono text-[11px]">
                      {num.number}
                    </span>
                  </a>
                  <span className="text-[10px] text-slate-500">{num.desc}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Rapid Services */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-white uppercase tracking-wider">
              Emergency Services
            </h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={onOpenAmbulanceDispatch}
                  className="hover:text-cyan-400 transition text-left"
                >
                  🚑 108 & Private Ambulance Dispatch
                </button>
              </li>
              <li>
                <button 
                  onClick={onOpenBloodRequest}
                  className="hover:text-rose-400 transition text-left"
                >
                  🩸 Emergency Blood & Donor Locator
                </button>
              </li>
              <li>
                <button 
                  onClick={onOpenAyushman}
                  className="hover:text-amber-400 transition text-left"
                >
                  🏥 Ayushman Bharat (PM-JAY) Cashless
                </button>
              </li>
              <li>
                <a href="#first-aid" className="hover:text-cyan-400 transition block">
                  📖 CPR & First Aid Protocol Guide
                </a>
              </li>
              <li>
                <a href="#how-it-works" className="hover:text-cyan-400 transition block">
                  ⚡ How FastMedCab Works
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-cyan-400 transition block">
                  🛡️ Verification & Safety Protocol
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Major Covered Hubs */}
          <div className="space-y-3">
            <h4 className="font-bold text-sm text-white uppercase tracking-wider">
              Network Hubs
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Serving active emergency corridors across:
            </p>
            <div className="flex flex-wrap gap-1.5">
              {[
                'Lucknow', 'Hardoi', 'Pali', 'Gorakhpur', 'Pipraich', 'Babhnan', 
                'Varanasi', 'Delhi NCR', 'Mumbai', 'Patna', 'Bengaluru', 'Jaipur', 'Ayodhya'
              ].map((c) => (
                <span key={c} className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-800 text-[10px] text-slate-300">
                  {c}
                </span>
              ))}
            </div>
            <p className="text-[10px] text-slate-500 pt-2">
              Integrated with OpenStreetMap and Live Overpass GPS engine.
            </p>
          </div>

        </div>

        {/* Bottom copyright and disclaimer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="space-y-1 text-center sm:text-left">
            <p>© {new Date().getFullYear()} FAST MEDCAB. All Rights Reserved.</p>
            <p className="text-[10px] text-slate-400">
              Disclaimer: FAST MEDCAB is an emergency healthcare aggregator. In severe life-threatening crises, please contact 112 or 108 immediately.
            </p>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
          >
            <span>Back to top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
