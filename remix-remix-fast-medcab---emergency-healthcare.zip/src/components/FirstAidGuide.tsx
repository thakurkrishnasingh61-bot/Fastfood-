import React, { useState } from 'react';
import { 
  HeartPulse, 
  Droplets, 
  ShieldAlert, 
  Activity, 
  Flame, 
  AlertOctagon, 
  ChevronRight,
  BookOpen
} from 'lucide-react';
import { FIRST_AID_GUIDES } from '../data/mockData';

export const FirstAidGuide: React.FC = () => {
  const [selectedGuideId, setSelectedGuideId] = useState(FIRST_AID_GUIDES[0].id);

  const activeGuide = FIRST_AID_GUIDES.find((g) => g.id === selectedGuideId) || FIRST_AID_GUIDES[0];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'HeartPulse':
        return <HeartPulse className="w-5 h-5 text-[#ff3150]" />;
      case 'Droplets':
        return <Droplets className="w-5 h-5 text-[#ff4d67]" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-5 h-5 text-[#ffd166]" />;
      case 'Activity':
        return <Activity className="w-5 h-5 text-[#00e5ff]" />;
      case 'Flame':
        return <Flame className="w-5 h-5 text-[#ff7b00]" />;
      default:
        return <AlertOctagon className="w-5 h-5 text-[#00ff9d]" />;
    }
  };

  return (
    <section id="first-aid" className="py-16 px-4 sm:px-6 lg:px-8 bg-[#061421] border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-[#ff4d67] inline-block mb-2 flex items-center justify-center gap-1.5">
            <BookOpen className="w-4 h-4" /> EMERGENCY FIRST AID PROTOCOLS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Life-Saving First-Aid Steps
          </h2>
          <p className="text-sm sm:text-base text-[#9db3be] mt-2">
            Clear, actionable instructions while waiting for the ambulance or paramedic team to arrive.
          </p>
        </div>

        {/* Layout: Guide Selector on Left, Action Steps on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left: Tab Selectors */}
          <div className="lg:col-span-4 space-y-2.5">
            {FIRST_AID_GUIDES.map((guide) => {
              const isSelected = guide.id === selectedGuideId;
              return (
                <button
                  key={guide.id}
                  type="button"
                  id={`guide-tab-${guide.id}`}
                  onClick={() => setSelectedGuideId(guide.id)}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl border text-left transition-all group ${
                    isSelected
                      ? 'bg-gradient-to-r from-white/15 to-white/5 border-[#00e5ff] shadow-[0_0_20px_rgba(0,229,255,0.2)] text-white'
                      : 'bg-white/[0.02] border-white/10 hover:border-white/20 text-[#a0b5c1] hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center shrink-0">
                      {getIcon(guide.icon)}
                    </div>
                    <div>
                      <div className="font-extrabold text-sm text-white group-hover:text-[#00e5ff] transition-colors leading-tight">
                        {guide.title}
                      </div>
                      <div className="text-[11px] text-[#ff4d67] font-semibold mt-0.5">
                        ● {guide.urgency}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className={`w-4 h-4 transition-transform ${isSelected ? 'text-[#00e5ff] translate-x-1' : 'text-gray-500'}`} />
                </button>
              );
            })}
          </div>

          {/* Right: Detailed Steps Card */}
          <div className="lg:col-span-8 p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-[#091f2e] to-[#041019] border border-white/15 shadow-2xl">
            <div className="flex items-center justify-between pb-4 mb-6 border-b border-white/10">
              <div>
                <span className="text-[11px] font-extrabold uppercase px-2.5 py-1 rounded-md bg-[#ff3150]/20 text-[#ff4d67] border border-[#ff3150]/30 inline-block mb-2">
                  {activeGuide.urgency}
                </span>
                <h3 className="text-2xl font-black text-white">
                  {activeGuide.title}
                </h3>
              </div>
              <div className="hidden sm:block">
                {getIcon(activeGuide.icon)}
              </div>
            </div>

            {/* Steps sequence */}
            <div className="space-y-4 mb-6">
              {activeGuide.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-4 p-3.5 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="w-7 h-7 rounded-full bg-[#00e5ff]/20 border border-[#00e5ff]/40 text-[#00e5ff] font-mono font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    0{idx + 1}
                  </div>
                  <p className="text-xs sm:text-sm text-[#d4e4ec] leading-relaxed">
                    {step}
                  </p>
                </div>
              ))}
            </div>

            {/* Critical Don'ts warning box */}
            <div className="p-4 rounded-xl bg-[#ff3150]/10 border border-[#ff3150]/30 text-xs text-[#ff99a8] flex items-start gap-3">
              <AlertOctagon className="w-4 h-4 text-[#ff3150] shrink-0 mt-0.5" />
              <div>
                <strong className="text-white block font-bold mb-0.5">WHAT NOT TO DO:</strong>
                <span>{activeGuide.donts}</span>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
