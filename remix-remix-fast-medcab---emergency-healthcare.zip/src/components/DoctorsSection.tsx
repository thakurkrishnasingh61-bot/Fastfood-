import React, { useState } from 'react';
import { 
  Calendar, 
  Clock, 
  Award, 
  Phone, 
  UserCheck, 
  Stethoscope
} from 'lucide-react';
import { DOCTORS_DATA, Doctor, HOSPITAL_INFO } from '../data/hospitalData';

interface DoctorsSectionProps {
  onBookDoctor: (doctor: Doctor) => void;
  isHindi: boolean;
}

export const DoctorsSection: React.FC<DoctorsSectionProps> = ({
  onBookDoctor,
  isHindi
}) => {
  const [selectedDept, setSelectedDept] = useState<string>('all');

  const departments = [
    { id: 'all', label: isHindi ? 'सभी चिकित्सक' : 'All Specialists' },
    { id: 'Emergency, ICU & Critical Care', label: isHindi ? 'आईसीयू व इमरजेंसी' : 'ICU & Emergency' },
    { id: 'Gynecology, Obstetrics & Maternity', label: isHindi ? 'स्त्री एवं प्रसूति' : 'Gynecology' },
    { id: 'Nova Eye Hospital (Netra Chikitsalaya)', label: isHindi ? 'नेत्र रोग' : 'Eye Specialist' },
    { id: 'Modular Operation Theatre & Surgery', label: isHindi ? 'सर्जरी व ओटी' : 'Surgery / OT' },
    { id: 'Dialysis & Renal Care', label: isHindi ? 'डायलिसिस' : 'Dialysis' },
    { id: 'General Medicine & Lifestyle Diseases', label: isHindi ? 'जनरल फिजिशियन' : 'General Medicine' }
  ];

  const filteredDoctors = selectedDept === 'all' 
    ? DOCTORS_DATA 
    : DOCTORS_DATA.filter(doc => doc.department === selectedDept);

  return (
    <section id="doctors" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>OPD Timings: 9:00 AM – 5:00 PM (Closes 5 PM)</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              {isHindi ? "हमारे वरिष्ठ विशेषज्ञ एवं चिकित्सक" : "Senior Consultants & Medical Faculty"}
            </h2>
            <p className="text-slate-600 mt-2 text-base max-w-2xl">
              {isHindi 
                ? "अनुभवी एवं समर्पित डॉक्टरों की टीम जो हर मरीज को व्यक्तिगत एवं मानवीय दृष्टिकोण से परामर्श प्रदान करती है।"
                : "Experienced senior consultants across emergency medicine, phaco eye surgery, nephrology, laparoscopy, and obstetrics."
              }
            </p>
          </div>

          <div className="shrink-0 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700">
            <span className="font-bold text-slate-900 block">Emergency & Critical Trauma:</span>
            <span className="text-red-600 font-semibold flex items-center gap-1 mt-0.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              24 Hours On-Call Medical Officer Available
            </span>
          </div>
        </div>

        {/* Department Filter Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-thin scrollbar-thumb-slate-300">
          {departments.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDept(dept.id)}
              className={`shrink-0 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition ${
                selectedDept === dept.id
                  ? 'bg-slate-900 text-white shadow'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {dept.label}
            </button>
          ))}
        </div>

        {/* Doctors Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDoctors.map((doctor) => (
            <div 
              key={doctor.id}
              className="rounded-2xl border border-slate-200 bg-white hover:border-blue-300 hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group"
            >
              <div className="p-6 space-y-4">
                
                {/* Doctor Avatar & Experience */}
                <div className="flex items-start gap-4">
                  <div className="relative w-16 h-16 rounded-2xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200">
                    <img 
                      src={doctor.image} 
                      alt={doctor.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute bottom-0 inset-x-0 bg-blue-900/80 text-[9px] text-center font-bold text-white py-0.5">
                      Doctor
                    </div>
                  </div>

                  <div className="min-w-0 flex-1">
                    <h3 className="font-extrabold text-slate-900 text-lg group-hover:text-blue-700 transition-colors leading-snug">
                      {doctor.name}
                    </h3>
                    <p className="text-xs font-semibold text-blue-700 mt-0.5">
                      {doctor.department}
                    </p>
                    <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {doctor.qualification}
                    </p>
                  </div>
                </div>

                {/* Experience & Timings */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs">
                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <Award className="w-3.5 h-3.5 text-amber-500" />
                      <span>Experience:</span>
                    </span>
                    <span className="font-bold text-slate-800">{doctor.experience}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <Clock className="w-3.5 h-3.5 text-blue-500" />
                      <span>OPD Timings:</span>
                    </span>
                    <span className="font-bold text-slate-800">{doctor.timings}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-700">
                    <span className="flex items-center gap-1.5 text-slate-500">
                      <Calendar className="w-3.5 h-3.5 text-emerald-500" />
                      <span>Days:</span>
                    </span>
                    <span className="font-semibold text-slate-800 truncate max-w-[140px] text-right">
                      {doctor.availability}
                    </span>
                  </div>
                </div>

                {/* Key clinical focus tags */}
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Specialized Focus:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {doctor.focus.map((item, idx) => (
                      <span 
                        key={idx}
                        className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[11px] font-medium"
                      >
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Booking CTA Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-3">
                <a
                  href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                  className="p-2.5 rounded-xl border border-slate-200 text-slate-700 hover:bg-white transition"
                  title="Call Hospital Helpline"
                >
                  <Phone className="w-4 h-4" />
                </a>

                <button
                  onClick={() => onBookDoctor(doctor)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Book OPD Consultation</span>
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* OPD Disclaimer Banner */}
        <div className="mt-10 p-4 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs sm:text-sm text-amber-900">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <span className="font-bold">Regular OPD Consultation Notice: </span>
              <span>General OPD consultation counters open at 9:00 AM and close promptly at 5:00 PM. Emergency and ICU admissions remain open 24 hours.</span>
            </div>
          </div>
          <a
            href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
            className="shrink-0 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold transition"
          >
            Inquire: {HOSPITAL_INFO.phone}
          </a>
        </div>

      </div>
    </section>
  );
};
