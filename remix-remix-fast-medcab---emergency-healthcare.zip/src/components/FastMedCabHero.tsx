import React from 'react';
import { 
  ShieldAlert, 
  Ambulance, 
  Droplet, 
  Clock,
  Radio,
  CheckCircle2
} from 'lucide-react';

interface FastMedCabHeroProps {
  onOpenSos: () => void;
  onOpenAmbulanceDispatch: () => void;
  onOpenBloodRequest: () => void;
  isHindi: boolean;
}

export const FastMedCabHero: React.FC<FastMedCabHeroProps> = ({
  onOpenSos,
  onOpenAmbulanceDispatch,
  onOpenBloodRequest,
  isHindi,
}) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-[#030a10] via-[#061421] to-[#040c14] text-white pt-8 pb-14 sm:pb-20 border-b border-cyan-500/20">
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-10 w-[450px] h-[450px] bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-full max-w-5xl h-32 bg-blue-500/10 blur-2xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Live Emergency Ticker */}
        <div className="flex flex-wrap items-center justify-between gap-3 mb-6 sm:mb-8 pb-4 border-b border-white/10">
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 border border-rose-400/40 text-rose-300 text-xs font-black tracking-wide">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span>LIVE EMERGENCY GRID</span>
            </div>

            <div className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-xs font-semibold">
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>GPS Tracking Active · 500+ Indian Towns & Villages</span>
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-400/30 text-amber-300 text-xs font-semibold">
              <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
              <span>Ayushman Bharat (PM-JAY) 100% Free / Cashless</span>
            </div>
          </div>

          <div className="text-xs text-slate-400 flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Avg Response: <strong className="text-emerald-300">6–12 Mins</strong></span>
          </div>
        </div>

        {/* Hero Title & Subtitle */}
        <div className="text-center max-w-4xl mx-auto mb-10 space-y-4">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
            FAST MEDCAB <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-500 via-amber-400 to-cyan-400">
              {isHindi ? 'त्वरित आपातकालीन स्वास्थ्य सेवा' : 'Emergency Healthcare & Rapid Dispatch'}
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed">
            {isHindi 
              ? "भारत के हर शहर, तहसील एवं गांव में वास्तविक समय के आईसीयू बेड, वेंटिलेटर, एम्बुलेंस, रक्तदान केंद्र एवं आपातकालीन डॉक्टरों की पुष्टि की गई जानकारी।"
              : "Locate verified ICU beds, dispatch nearest ALS/BLS ambulances, find blood donors, on-call trauma surgeons, 24/7 pharmacies, and emergency hospitals across India."
            }
          </p>
        </div>

        {/* 3 Instant Action Big Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-10 max-w-5xl mx-auto">
          
          {/* Card 1: SOS Alarm & 112 */}
          <button
            type="button"
            onClick={onOpenSos}
            className="group relative p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-rose-950/80 via-[#19070c] to-[#0d0407] border-2 border-rose-500/50 hover:border-rose-400 text-left transition-all duration-300 shadow-[0_0_30px_rgba(255,49,80,0.25)] hover:shadow-[0_0_50px_rgba(255,49,80,0.45)] hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-600/30 border border-rose-500/50 text-rose-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-rose-600 text-white text-[10px] font-black uppercase tracking-wider">
                DIAL 112 / 108
              </span>
            </div>
            <h3 className="text-lg font-black text-white group-hover:text-rose-300 transition">
              {isHindi ? 'आपातकालीन SOS अलार्म' : 'Trigger Emergency SOS'}
            </h3>
            <p className="text-xs text-rose-200/80 mt-1 leading-relaxed">
              {isHindi ? 'तुरंत सायरन बजाएं, जीपीएस लोकेशन साझा करें और 112 से संपर्क करें।' : 'High-pitch siren tone, live GPS coordinates, and direct 1-tap 112/108 dispatch.'}
            </p>
          </button>

          {/* Card 2: Book Ambulance */}
          <button
            type="button"
            onClick={onOpenAmbulanceDispatch}
            className="group relative p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-amber-950/60 via-[#181106] to-[#0c0903] border-2 border-amber-500/50 hover:border-amber-400 text-left transition-all duration-300 shadow-[0_0_30px_rgba(245,158,11,0.2)] hover:shadow-[0_0_50px_rgba(245,158,11,0.35)] hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Ambulance className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-amber-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                ON CALL 24x7
              </span>
            </div>
            <h3 className="text-lg font-black text-white group-hover:text-amber-300 transition">
              {isHindi ? 'एम्बुलेंस तत्काल बुलाएं' : 'Book Rapid Ambulance'}
            </h3>
            <p className="text-xs text-amber-200/80 mt-1 leading-relaxed">
              {isHindi ? 'आईसीयू ऑन व्हील्स (वेंटिलेटर), एएलएस व बीएलएस एम्बुलेंस लाइव ट्रैकिंग।' : 'ICU on wheels with ventilator, ALS & BLS units with real-time ETA tracking.'}
            </p>
          </button>

          {/* Card 3: Blood Request */}
          <button
            type="button"
            onClick={onOpenBloodRequest}
            className="group relative p-5 sm:p-6 rounded-3xl bg-gradient-to-br from-cyan-950/60 via-[#06151f] to-[#030d14] border-2 border-cyan-500/50 hover:border-cyan-400 text-left transition-all duration-300 shadow-[0_0_30px_rgba(0,229,255,0.2)] hover:shadow-[0_0_50px_rgba(0,229,255,0.35)] hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Droplet className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-cyan-500 text-slate-950 text-[10px] font-black uppercase tracking-wider">
                ZERO DELAY
              </span>
            </div>
            <h3 className="text-lg font-black text-white group-hover:text-cyan-300 transition">
              {isHindi ? 'रक्त व डोनर खोजें' : 'Request Blood / Stock'}
            </h3>
            <p className="text-xs text-cyan-200/80 mt-1 leading-relaxed">
              {isHindi ? 'सभी ब्लड ग्रुप (O-, A+, B+, AB+), प्लेटलेट्स एवं रेड क्रॉस बैंक से सीधा संपर्क।' : 'Direct connection with registered donors, component banks & Red Cross.'}
            </p>
          </button>

        </div>

        {/* Live Grid Metrics Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-4xl mx-auto mt-8 pt-6 border-t border-white/10 text-center">
          <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5">
            <div className="text-xl sm:text-2xl font-black text-cyan-400">500+</div>
            <div className="text-[11px] text-slate-400 font-medium">{isHindi ? 'सत्यापित अस्पताल व सीएचसी' : 'Verified Hospitals Mapped'}</div>
          </div>

          <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5">
            <div className="text-xl sm:text-2xl font-black text-rose-400">1,200+</div>
            <div className="text-[11px] text-slate-400 font-medium">{isHindi ? '108 व प्राइवेट एम्बुलेंस' : 'Active Emergency Ambulances'}</div>
          </div>

          <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5">
            <div className="text-xl sm:text-2xl font-black text-emerald-400">100%</div>
            <div className="text-[11px] text-slate-400 font-medium">{isHindi ? 'आयुष्मान भारत कैशलेस' : 'Ayushman PM-JAY Cashless'}</div>
          </div>

          <div className="p-3 rounded-2xl bg-white/[0.02] border border-white/5">
            <div className="text-xl sm:text-2xl font-black text-amber-400">24x7</div>
            <div className="text-[11px] text-slate-400 font-medium">{isHindi ? 'आपातकालीन कैजुअल्टी' : 'Round-The-Clock Casualty'}</div>
          </div>
        </div>

      </div>
    </section>
  );
};
