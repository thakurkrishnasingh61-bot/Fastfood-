import React, { useState } from 'react';
import { 
  X, 
  Droplet, 
  CheckCircle, 
  Send, 
  User, 
  Building2, 
  Phone, 
  Heart, 
  AlertCircle 
} from 'lucide-react';
import { BloodGroup, BloodDonorItem } from '../types';

interface BloodRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDonor: (newDonor: BloodDonorItem) => void;
}

const BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const BloodRequestModal: React.FC<BloodRequestModalProps> = ({
  isOpen,
  onClose,
  onAddDonor,
}) => {
  const [activeTab, setActiveTab] = useState<'request' | 'register'>('request');
  const [submitted, setSubmitted] = useState(false);

  // Request Form State
  const [patientName, setPatientName] = useState('');
  const [hospitalName, setHospitalName] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<BloodGroup>('O+');
  const [units, setUnits] = useState('2');
  const [contactNumber, setContactNumber] = useState('');
  const [city, setCity] = useState('');
  const [urgency, setUrgency] = useState('Critical (Under 1 hour)');

  // Register Form State
  const [donorName, setDonorName] = useState('');
  const [donorGroup, setDonorGroup] = useState<BloodGroup>('O+');
  const [donorCity, setDonorCity] = useState('');
  const [donorArea, setDonorArea] = useState('');
  const [donorPhone, setDonorPhone] = useState('');

  if (!isOpen) return null;

  const handleRequestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newDonor: BloodDonorItem = {
      id: `donor-${Date.now()}`,
      name: donorName,
      bloodGroup: donorGroup,
      donorType: 'Individual Donor',
      unitsAvailable: 1,
      city: donorCity || 'Local Area',
      area: donorArea || 'Central Zone',
      distanceKm: 1.5,
      phone: donorPhone,
      verified: true,
      lastDonation: 'Just Registered',
      availability: 'Available Immediately',
    };
    onAddDonor(newDonor);
    setSubmitted(true);
  };

  const resetForm = () => {
    setSubmitted(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#081520] border border-[#ff3150]/40 p-6 sm:p-8 shadow-[0_0_80px_rgba(255,49,80,0.25)] text-white">
        
        {/* Close */}
        <button
          type="button"
          id="close-blood-modal"
          onClick={resetForm}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#00ff9d]/20 border border-[#00ff9d]/40 flex items-center justify-center text-[#00ff9d] mx-auto">
              <CheckCircle className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-white">
              {activeTab === 'request' ? 'Emergency Blood Request Broadcasted!' : 'Registered as Lifesaver Donor!'}
            </h3>
            <p className="text-sm text-[#a0b5c1] max-w-sm mx-auto">
              {activeTab === 'request'
                ? `Alert for blood group ${selectedGroup} sent to all matching verified donors and blood component banks in ${city || 'your area'}.`
                : `Thank you, ${donorName}! Your blood group (${donorGroup}) is now listed for urgent patient requests.`}
            </p>
            <div className="pt-4">
              <button
                type="button"
                id="blood-modal-done"
                onClick={resetForm}
                className="px-6 py-2.5 rounded-xl bg-[#00e5ff] text-[#031017] font-black text-xs uppercase tracking-wider hover:bg-[#38bdf8] transition-all"
              >
                Back to Directory
              </button>
            </div>
          </div>
        ) : (
          <div>
            {/* Header Tabs */}
            <div className="flex items-center gap-2 p-1 rounded-xl bg-white/5 border border-white/10 mb-6">
              <button
                type="button"
                onClick={() => setActiveTab('request')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'request'
                    ? 'bg-[#ff3150] text-white shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                🚨 Request Urgent Blood
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('register')}
                className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeTab === 'register'
                    ? 'bg-[#00e5ff] text-[#031017] shadow-md'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                🩸 Register as Donor
              </button>
            </div>

            {/* REQUEST FORM */}
            {activeTab === 'request' ? (
              <form onSubmit={handleRequestSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-gray-300 font-bold mb-1">Select Blood Group Required</label>
                  <div className="grid grid-cols-4 gap-2">
                    {BLOOD_GROUPS.map((bg) => (
                      <button
                        key={bg}
                        type="button"
                        onClick={() => setSelectedGroup(bg)}
                        className={`py-2 rounded-lg font-black text-sm transition-all ${
                          selectedGroup === bg
                            ? 'bg-[#ff3150] text-white shadow-[0_0_12px_rgba(255,49,80,0.5)] scale-105'
                            : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                        }`}
                      >
                        {bg}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">Patient Name</label>
                    <input
                      type="text"
                      required
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      placeholder="e.g. Rahul Sharma"
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">Units Needed</label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      required
                      value={units}
                      onChange={(e) => setUnits(e.target.value)}
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">Hospital / Clinic Name</label>
                    <input
                      type="text"
                      required
                      value={hospitalName}
                      onChange={(e) => setHospitalName(e.target.value)}
                      placeholder="e.g. Metro ICU Ward 4"
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">City / Location</label>
                    <input
                      type="text"
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="e.g. New Delhi"
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1">Contact Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={contactNumber}
                    onChange={(e) => setContactNumber(e.target.value)}
                    placeholder="+91 98XXX XXXXX"
                    className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1">Urgency Level</label>
                  <select
                    value={urgency}
                    onChange={(e) => setUrgency(e.target.value)}
                    className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#ff3150] outline-none"
                  >
                    <option value="Critical (Under 1 hour)">Critical (Under 1 hour)</option>
                    <option value="High (Within 6 hours)">High (Within 6 hours)</option>
                    <option value="Standard (Within 24 hours)">Standard (Within 24 hours)</option>
                  </select>
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white font-extrabold text-sm shadow-[0_5px_20px_rgba(255,49,80,0.4)] flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    <span>Broadcast Urgent Blood Need</span>
                  </button>
                </div>
              </form>
            ) : (
              /* REGISTER DONOR FORM */
              <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block text-gray-300 font-bold mb-1">Your Blood Group</label>
                  <div className="grid grid-cols-4 gap-2">
                    {BLOOD_GROUPS.map((bg) => (
                      <button
                        key={bg}
                        type="button"
                        onClick={() => setDonorGroup(bg)}
                        className={`py-2 rounded-lg font-black text-sm transition-all ${
                          donorGroup === bg
                            ? 'bg-[#00e5ff] text-[#031017] shadow-[0_0_12px_rgba(0,229,255,0.5)] scale-105'
                            : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                        }`}
                      >
                        {bg}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={donorName}
                    onChange={(e) => setDonorName(e.target.value)}
                    placeholder="e.g. Vikram Malhotra"
                    className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">City</label>
                    <input
                      type="text"
                      required
                      value={donorCity}
                      onChange={(e) => setDonorCity(e.target.value)}
                      placeholder="e.g. Mumbai"
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-300 font-bold mb-1">Area / Locality</label>
                    <input
                      type="text"
                      required
                      value={donorArea}
                      onChange={(e) => setDonorArea(e.target.value)}
                      placeholder="e.g. Bandra West"
                      className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-gray-300 font-bold mb-1">WhatsApp / Phone Number</label>
                  <input
                    type="tel"
                    required
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    placeholder="+91 98XXX XXXXX"
                    className="w-full p-2.5 rounded-lg bg-black/40 border border-white/15 text-white focus:border-[#00e5ff] outline-none"
                  />
                </div>

                <div className="pt-3">
                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#00e5ff] to-[#00a8ff] text-[#031017] font-black text-sm shadow-[0_5px_20px_rgba(0,229,255,0.3)] flex items-center justify-center gap-2"
                  >
                    <Heart className="w-4 h-4 fill-current" />
                    <span>Join Voluntary Donor Registry</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
