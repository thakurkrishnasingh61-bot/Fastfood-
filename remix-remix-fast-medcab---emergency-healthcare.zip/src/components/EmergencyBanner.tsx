import React from 'react';
import { PhoneCall, ShieldAlert, AlertTriangle, Radio } from 'lucide-react';

interface EmergencyBannerProps {
  onSosClick: () => void;
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({ onSosClick }) => {
  return (
    <section id="emergency" className="relative py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#140609] via-[#10070a] to-[#06121c] border-y border-[#ff3150]/30 overflow-hidden">
      
      {/* Decorative pulse background rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
        <div className="w-[500px] h-[500px] rounded-full border border-[#ff3150] animate-ping duration-1000" />
      </div>

      <div className="relative z-10 max-w-4xl mx-auto text-center">
        
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ff3150]/20 border border-[#ff3150]/40 text-[#ff4d67] text-xs font-black tracking-wider uppercase mb-4">
          <span className="w-2 h-2 rounded-full bg-[#ff3150] animate-ping" />
          <span>EMERGENCY PROTOCOL ACTIVE</span>
        </div>

        <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mb-4 leading-tight">
          Facing A Critical Medical Emergency?
        </h2>

        <p className="text-sm sm:text-base text-[#e5cbd0] max-w-xl mx-auto mb-8 leading-relaxed">
          If you or someone around you is facing a life-threatening accident, chest pain, stroke, or severe bleeding, connect immediately to the national emergency response network.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-4">
          <button
            type="button"
            id="emergency-banner-sos-btn"
            onClick={onSosClick}
            className="flex items-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-[#ff3150] via-[#ff003d] to-[#b90029] hover:from-[#ff1744] hover:to-[#90001f] text-white font-black text-sm sm:text-base shadow-[0_0_40px_rgba(255,49,80,0.5)] transform hover:scale-105 transition-all"
          >
            <PhoneCall className="w-5 h-5 animate-bounce" />
            <span>TRIGGER SOS / DIAL 112 NOW</span>
          </button>

          <a
            href="tel:108"
            className="flex items-center gap-2 px-6 py-4 rounded-2xl bg-white/10 hover:bg-white/15 border border-white/20 text-white font-bold text-sm sm:text-base backdrop-blur-sm transition-all"
          >
            <Radio className="w-5 h-5 text-[#00e5ff]" />
            <span>Dial Ambulance (108)</span>
          </a>
        </div>

        <p className="text-xs text-gray-400 mt-5">
          Free 24/7 toll-free emergency call lines nationwide
        </p>

      </div>
    </section>
  );
};
