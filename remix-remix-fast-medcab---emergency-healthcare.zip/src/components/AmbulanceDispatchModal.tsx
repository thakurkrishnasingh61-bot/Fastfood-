import React, { useState, useEffect } from 'react';
import { 
  X, 
  Phone, 
  Ambulance, 
  Navigation
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface AmbulanceDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
}

const COMMON_HIGHWAY_LANDMARKS = [
  'Banthara Market / NH-25',
  'MGIMT Campus Gate (NH-25)',
  'Khandedev Turn / Road',
  'Amausi Airport Bypass',
  'Junabganj / Unnao Border'
];

export const AmbulanceDispatchModal: React.FC<AmbulanceDispatchModalProps> = ({
  isOpen,
  onClose,
  isHindi
}) => {
  const [pickupLocation, setPickupLocation] = useState('');
  const [patientContact, setPatientContact] = useState('');
  const [emergencyType, setEmergencyType] = useState('Highway Road Accident (NH-25)');
  const [gpsDetected, setGpsDetected] = useState(false);
  const [detectingGps, setDetectingGps] = useState(false);
  const [requestedSuccess, setRequestedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setRequestedSuccess(false);
      setGpsDetected(false);
      setDetectingGps(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDetectGPS = () => {
    if (navigator.geolocation) {
      setDetectingGps(true);
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPickupLocation(`GPS: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)} (NH-25 Banthara Corridor)`);
          setGpsDetected(true);
          setDetectingGps(false);
        },
        () => {
          setPickupLocation('MGIMT Campus / Kanpur Road NH-25 Banthara, UP');
          setGpsDetected(true);
          setDetectingGps(false);
        },
        { timeout: 6000, enableHighAccuracy: true, maximumAge: 60000 }
      );
    } else {
      setPickupLocation('Kanpur Road (NH-25), Banthara, UP');
      setGpsDetected(true);
    }
  };

  const handleDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pickupLocation.trim() || !patientContact.trim()) return;
    setRequestedSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
        
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {requestedSuccess ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-red-100 text-red-600 flex items-center justify-center mx-auto animate-pulse">
              <Ambulance className="w-9 h-9" />
            </div>
            
            <h3 className="text-2xl font-black text-slate-900">
              Ambulance Request Dispatched
            </h3>
            
            <p className="text-xs sm:text-sm text-slate-600">
              Nova Shekhar Hospital Emergency Ambulance is alerting the on-duty driver on Kanpur Road. Our casualty control room is dialing your contact number right now.
            </p>

            <div className="p-4 rounded-2xl bg-red-50 border border-red-200 text-left space-y-1 text-xs">
              <div className="font-bold text-red-900 flex items-center justify-between">
                <span>Direct Driver / Casualty Line:</span>
                <span className="text-emerald-600">Active</span>
              </div>
              <a 
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`} 
                className="text-lg font-black text-red-700 hover:underline block"
              >
                {HOSPITAL_INFO.phone}
              </a>
              <p className="text-[11px] text-red-600">Keep your phone line free. Emergency crew is en route.</p>
            </div>

            <div className="pt-2">
              <button
                onClick={onClose}
                className="w-full py-3 rounded-xl bg-slate-900 text-white font-bold text-xs"
              >
                Close & Return
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleDispatch} className="space-y-4">
            
            {/* Header */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                <Ambulance className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-bold text-red-600 uppercase tracking-wider">
                  24/7 Rapid Trauma Unit
                </span>
                <h3 className="text-xl font-black text-slate-900">
                  NH-25 Highway Ambulance Dispatch
                </h3>
              </div>
            </div>

            {/* Direct Call Banner */}
            <div className="p-3.5 rounded-2xl bg-gradient-to-r from-red-600 to-rose-600 text-white flex items-center justify-between shadow-md">
              <div className="space-y-0.5">
                <span className="text-[11px] text-red-100 block">Instant Toll-Free Direct Line:</span>
                <span className="font-black text-base tracking-wide">{HOSPITAL_INFO.phone}</span>
              </div>
              <a
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="px-4 py-2 rounded-xl bg-white text-red-700 font-black text-xs hover:bg-red-50 transition shadow"
              >
                CALL 24/7
              </a>
            </div>

            {/* Location input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-bold text-slate-700">Pickup Location / Milestone *</label>
                <button
                  type="button"
                  onClick={handleDetectGPS}
                  disabled={detectingGps}
                  className="text-[11px] font-bold text-blue-700 hover:underline flex items-center gap-1 disabled:opacity-50"
                >
                  <Navigation className={`w-3 h-3 ${detectingGps ? 'animate-spin' : ''}`} />
                  <span>{detectingGps ? 'Detecting GPS...' : 'Use Device GPS'}</span>
                </button>
              </div>
              <input
                type="text"
                required
                placeholder="e.g. Near Banthara Police Station / Kanpur Road NH-25"
                value={pickupLocation}
                onChange={(e) => setPickupLocation(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
              />

              {/* Quick highway chips */}
              <div className="mt-2 flex flex-wrap gap-1.5 items-center">
                <span className="text-[10px] text-slate-400 font-semibold">Quick select:</span>
                {COMMON_HIGHWAY_LANDMARKS.map((landmark) => (
                  <button
                    key={landmark}
                    type="button"
                    onClick={() => {
                      setPickupLocation(landmark);
                      setGpsDetected(true);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 hover:bg-red-50 hover:text-red-700 text-slate-600 border border-slate-200 transition font-medium"
                  >
                    {landmark}
                  </button>
                ))}
              </div>
            </div>

            {/* Contact number */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Contact Phone Number *</label>
              <input
                type="tel"
                required
                placeholder="e.g. 95550 14545"
                value={patientContact}
                onChange={(e) => setPatientContact(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>

            {/* Emergency nature */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Emergency Nature</label>
              <select
                value={emergencyType}
                onChange={(e) => setEmergencyType(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 bg-white"
              >
                <option value="Highway Road Accident (NH-25)">Highway Road Accident / Trauma (NH-25)</option>
                <option value="Acute Chest Pain / Heart Attack">Acute Chest Pain / Heart Attack</option>
                <option value="Immediate Delivery / Maternity Labour">Immediate Delivery / Maternity Labour</option>
                <option value="Critical Breathing / Oxygen Drop">Critical Breathing / Severe Asthma</option>
                <option value="Unconscious / Stroke Emergency">Unconscious Patient / Stroke</option>
                <option value="Emergency Kidney Dialysis Transfer">Emergency Dialysis Transfer</option>
              </select>
            </div>

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold shadow-md transition flex items-center gap-2"
              >
                <Ambulance className="w-4 h-4" />
                <span>Confirm Ambulance</span>
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
