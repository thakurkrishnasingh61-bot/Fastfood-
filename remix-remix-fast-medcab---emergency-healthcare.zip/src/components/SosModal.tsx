import React, { useState } from 'react';
import { 
  X, 
  PhoneCall, 
  AlertTriangle, 
  MapPin, 
  Volume2, 
  VolumeX, 
  Share2, 
  Check, 
  ShieldAlert,
  HeartCrack
} from 'lucide-react';
import { EMERGENCY_NUMBERS } from '../data/mockData';

interface SosModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SosModal: React.FC<SosModalProps> = ({ isOpen, onClose }) => {
  const [sirenPlaying, setSirenPlaying] = useState(false);
  const [copiedLocation, setCopiedLocation] = useState(false);
  const [audioCtx, setAudioCtx] = useState<AudioContext | null>(null);

  if (!isOpen) return null;

  // Toggle synthesized high-pitch emergency siren tone safely via browser Web Audio API
  const toggleSiren = () => {
    if (sirenPlaying) {
      if (audioCtx) {
        audioCtx.close();
        setAudioCtx(null);
      }
      setSirenPlaying(false);
    } else {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        
        // Siren frequency modulation
        const now = ctx.currentTime;
        for (let i = 0; i < 30; i++) {
          osc.frequency.setValueAtTime(800, now + i * 0.8);
          osc.frequency.exponentialRampToValueAtTime(1400, now + i * 0.8 + 0.4);
          osc.frequency.exponentialRampToValueAtTime(800, now + i * 0.8 + 0.8);
        }

        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        setAudioCtx(ctx);
        setSirenPlaying(true);
      } catch (e) {
        console.error('Audio context not allowed yet', e);
      }
    }
  };

  const handleCopyLocation = () => {
    const text = `EMERGENCY ALERT: I need urgent medical assistance! Sent via FAST MEDCAB platform. Please dispatch ambulance/help immediately.`;
    navigator.clipboard.writeText(text);
    setCopiedLocation(true);
    setTimeout(() => setCopiedLocation(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#0e0407] border-2 border-[#ff3150] p-6 sm:p-8 shadow-[0_0_80px_rgba(255,49,80,0.4)] text-white animate-in fade-in zoom-in-95 duration-200">
        
        {/* Close Button */}
        <button
          type="button"
          id="close-sos-modal"
          onClick={() => {
            if (audioCtx) audioCtx.close();
            setSirenPlaying(false);
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* SOS Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-[#ff3150] to-[#b90029] shadow-[0_0_35px_rgba(255,49,80,0.6)] mb-3 animate-pulse">
            <ShieldAlert className="w-9 h-9 text-white" />
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            EMERGENCY SOS DISPATCH
          </h2>
          <p className="text-xs sm:text-sm text-[#f5b8c0] mt-1">
            Tap to immediately dial emergency response helplines
          </p>
        </div>

        {/* Primary SOS Helpline Dials */}
        <div className="space-y-3 mb-6">
          <a
            href="tel:112"
            id="sos-call-112"
            className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-[#ff3150] to-[#ff003d] hover:from-[#ff1744] hover:to-[#b90029] shadow-[0_10px_30px_rgba(255,49,80,0.5)] transform hover:scale-[1.02] transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center text-white">
                <PhoneCall className="w-6 h-6 animate-bounce" />
              </div>
              <div className="text-left">
                <div className="text-xl font-black tracking-wide font-mono">CALL 112</div>
                <div className="text-xs text-white/80 font-medium">National All-in-One Emergency Services</div>
              </div>
            </div>
            <span className="text-xs font-black uppercase px-3 py-1 rounded-full bg-white text-[#ff003d]">
              INSTANT
            </span>
          </a>

          <a
            href="tel:108"
            id="sos-call-108"
            className="w-full flex items-center justify-between p-4 rounded-2xl bg-gradient-to-r from-[#00a8ff] to-[#0077b6] hover:from-[#38bdf8] hover:to-[#005f99] shadow-[0_8px_25px_rgba(0,168,255,0.3)] transform hover:scale-[1.02] transition-all"
          >
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center text-white">
                <PhoneCall className="w-6 h-6" />
              </div>
              <div className="text-left">
                <div className="text-xl font-black tracking-wide font-mono">CALL 108</div>
                <div className="text-xs text-white/80 font-medium">Free Medical Emergency Ambulance Dispatch</div>
              </div>
            </div>
            <span className="text-xs font-black uppercase px-3 py-1 rounded-full bg-white text-[#0077b6]">
              AMBULANCE
            </span>
          </a>

          <a
            href="tel:102"
            id="sos-call-102"
            className="w-full flex items-center justify-between p-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 transition-all text-xs"
          >
            <div className="flex items-center gap-2.5">
              <span className="font-mono font-bold text-[#ffd166] text-base">102</span>
              <span className="text-gray-200 font-medium">Free Pregnant Mother & Child Medical Care Helpline</span>
            </div>
            <span className="text-[#ffd166] font-bold">Call →</span>
          </a>
        </div>

        {/* Quick Tools: Siren & Share Emergency Message */}
        <div className="grid grid-cols-2 gap-3 pt-4 border-t border-white/10">
          <button
            type="button"
            id="sos-toggle-siren"
            onClick={toggleSiren}
            className={`flex items-center justify-center gap-2 py-3 px-3 rounded-xl text-xs font-extrabold border transition-all ${
              sirenPlaying
                ? 'bg-[#ff3150] border-[#ff3150] text-white animate-pulse shadow-[0_0_20px_rgba(255,49,80,0.6)]'
                : 'bg-white/5 border-white/15 text-gray-300 hover:bg-white/10'
            }`}
          >
            {sirenPlaying ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span>{sirenPlaying ? 'Stop Siren' : 'Loud SOS Alarm'}</span>
          </button>

          <button
            type="button"
            id="sos-copy-alert"
            onClick={handleCopyLocation}
            className="flex items-center justify-center gap-2 py-3 px-3 rounded-xl text-xs font-extrabold bg-white/5 border border-white/15 hover:bg-white/10 text-gray-300 transition-all"
          >
            {copiedLocation ? <Check className="w-4 h-4 text-[#00ff9d]" /> : <Share2 className="w-4 h-4" />}
            <span>{copiedLocation ? 'Alert Copied!' : 'Copy Alert SMS'}</span>
          </button>
        </div>

        <p className="text-[11px] text-center text-[#ff99a8] mt-4">
          ⚠️ If you are in immediate danger or severe cardiac distress, keep your line open and give your exact landmark to the 112 operator.
        </p>

      </div>
    </div>
  );
};
