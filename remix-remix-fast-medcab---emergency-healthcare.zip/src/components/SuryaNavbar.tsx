import React, { useState } from 'react';
import { 
  Phone, 
  Clock, 
  Award, 
  Search, 
  Calendar, 
  Menu, 
  X, 
  ShieldAlert, 
  BookOpen, 
  Package, 
  UserCheck, 
  Activity,
  Sun,
  Stethoscope,
  ChevronDown
} from 'lucide-react';
import { SURYA_HOSPITAL } from '../data/suryaHospitalData';

interface SuryaNavbarProps {
  activeTab: 'article' | 'az-directory' | 'packages' | 'doctors' | 'screener';
  setActiveTab: (tab: 'article' | 'az-directory' | 'packages' | 'doctors' | 'screener') => void;
  onOpenAppointment: (initialDept?: string, initialDoctor?: string) => void;
  onOpenEmergency: () => void;
  isHindi: boolean;
  setIsHindi: (val: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
}

export const SuryaNavbar: React.FC<SuryaNavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenAppointment,
  onOpenEmergency,
  isHindi,
  setIsHindi,
  searchQuery,
  setSearchQuery
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);

  const handleNavClick = (tab: 'article' | 'az-directory' | 'packages' | 'doctors' | 'screener') => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm border-b border-slate-200">
      {/* Top Utility Strip */}
      <div className="bg-slate-900 text-slate-100 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-4 flex-wrap">
            <span className="flex items-center gap-1.5 text-amber-400 font-medium">
              <Award className="w-3.5 h-3.5" />
              <span>NABH & NABL Accredited Multi-Speciality Care</span>
            </span>
            <span className="hidden sm:inline-block text-slate-600">|</span>
            <span className="hidden sm:flex items-center gap-1.5 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isHindi ? "24 घंटे आपातकालीन एवं आईसीयू सेवाएं" : "24/7 Emergency, ICU & Trauma Open"}</span>
            </span>
          </div>

          <div className="flex items-center space-x-3 ml-auto">
            {/* 24/7 Emergency Dial */}
            <button 
              onClick={onOpenEmergency}
              className="flex items-center gap-1.5 text-rose-300 hover:text-white font-semibold bg-rose-950/80 border border-rose-800/80 px-2.5 py-0.5 rounded transition-colors"
            >
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
              <span>Emergency: {SURYA_HOSPITAL.emergencyPhone}</span>
            </button>

            {/* Language Switch */}
            <button
              onClick={() => setIsHindi(!isHindi)}
              className="flex items-center gap-1 px-2.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs transition"
              title="Toggle Hindi / English"
            >
              <span className={isHindi ? "font-bold text-amber-400" : "text-slate-400"}>हिं</span>
              <span className="text-slate-500">/</span>
              <span className={!isHindi ? "font-bold text-amber-400" : "text-slate-400"}>EN</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Surya Hospital Logo & Identity */}
          <div 
            onClick={() => handleNavClick('article')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-400 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
              <Sun className="w-7 h-7 text-white animate-spin-slow" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl sm:text-2xl text-slate-900 tracking-tight">
                  SURYA <span className="text-amber-600">HOSPITAL</span>
                </span>
                <span className="hidden md:inline-block px-2 py-0.5 text-[10px] uppercase font-bold tracking-wider rounded bg-amber-50 text-amber-800 border border-amber-200">
                  Medical Portal
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {isHindi ? "स्वास्थ्य पोर्टल एवं ए-टू-जेड रोग गाइड" : "Health Guide & A-Z Disease Encyclopedia"}
              </p>
            </div>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2">
            <button
              onClick={() => handleNavClick('article')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'article'
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>{isHindi ? "हंतावायरस गाइड" : "Hantavirus Guide"}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping ml-0.5"></span>
            </button>

            <button
              onClick={() => handleNavClick('az-directory')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'az-directory'
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>{isHindi ? "A-Z रोग डायरेक्टरी" : "A-Z Diseases"}</span>
            </button>

            <button
              onClick={() => handleNavClick('packages')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'packages'
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>{isHindi ? "हेल्थ चेकअप पैकेज" : "Health Packages"}</span>
            </button>

            <button
              onClick={() => handleNavClick('doctors')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'doctors'
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Stethoscope className="w-4 h-4" />
              <span>{isHindi ? "विशेषज्ञ डॉक्टर" : "Specialist Doctors"}</span>
            </button>

            <button
              onClick={() => handleNavClick('screener')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-sm font-semibold transition-all ${
                activeTab === 'screener'
                  ? 'bg-amber-500 text-white shadow-sm shadow-amber-500/30'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>{isHindi ? "लक्षण जांच" : "Symptom Tool"}</span>
            </button>
          </nav>

          {/* Search & Action Button */}
          <div className="hidden md:flex items-center space-x-3">
            {/* Quick Search */}
            <div className="relative">
              <input
                type="text"
                placeholder={isHindi ? "रोग या लक्षण खोजें..." : "Search diseases or symptoms..."}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (activeTab !== 'az-directory' && e.target.value.length > 0) {
                    setActiveTab('az-directory');
                  }
                }}
                className="w-44 xl:w-56 pl-9 pr-3 py-1.5 text-xs rounded-full border border-slate-300 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 bg-slate-50 transition"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
            </div>

            {/* Book Appointment CTA */}
            <button
              onClick={() => onOpenAppointment()}
              className="flex items-center gap-2 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-lg shadow-sm shadow-orange-600/20 hover:shadow-md transition active:scale-95"
            >
              <Calendar className="w-4 h-4" />
              <span>{isHindi ? "अपॉइंटमेंट बुक करें" : "Book Doctor"}</span>
            </button>
          </div>

          {/* Mobile Menu & Search Button */}
          <div className="flex items-center gap-2 lg:hidden">
            <button
              onClick={() => setShowSearchInput(!showSearchInput)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              title="Search"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input Drawer */}
        {showSearchInput && (
          <div className="lg:hidden pb-3 pt-1 border-t border-slate-100">
            <div className="relative">
              <input
                type="text"
                placeholder={isHindi ? "रोग या लक्षण खोजें (जैसे: हंतावायरस, डेंगू)..." : "Search disease or symptom (e.g. Hantavirus, Dengue)..."}
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (activeTab !== 'az-directory' && e.target.value.length > 0) {
                    setActiveTab('az-directory');
                  }
                }}
                className="w-full pl-9 pr-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:border-amber-500 bg-slate-50"
                autoFocus
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            </div>
          </div>
        )}
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-6 space-y-2">
          <button
            onClick={() => handleNavClick('article')}
            className={`w-full flex items-center justify-between px-4 py-2.5 rounded-lg text-sm font-semibold ${
              activeTab === 'article' ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <span className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              <span>{isHindi ? "हंतावायरस संपूर्ण गाइड" : "Hantavirus Medical Guide"}</span>
            </span>
            <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded font-bold">Featured</span>
          </button>

          <button
            onClick={() => handleNavClick('az-directory')}
            className={`w-full flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold ${
              activeTab === 'az-directory' ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{isHindi ? "A-Z रोग डायरेक्टरी (A to Z Diseases)" : "A-Z Diseases Library"}</span>
          </button>

          <button
            onClick={() => handleNavClick('packages')}
            className={`w-full flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold ${
              activeTab === 'packages' ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>{isHindi ? "हेल्थ चेकअप पैकेज" : "Preventive Health Packages"}</span>
          </button>

          <button
            onClick={() => handleNavClick('doctors')}
            className={`w-full flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold ${
              activeTab === 'doctors' ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <Stethoscope className="w-4 h-4" />
            <span>{isHindi ? "विशेषज्ञ डॉक्टर एवं ओपीडी" : "Doctors & Specialists"}</span>
          </button>

          <button
            onClick={() => handleNavClick('screener')}
            className={`w-full flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold ${
              activeTab === 'screener' ? 'bg-amber-500 text-white' : 'text-slate-700 hover:bg-slate-100'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>{isHindi ? "इंटरैक्टिव लक्षण जांच (Symptom Checker)" : "Symptom & Exposure Checker"}</span>
          </button>

          <div className="pt-3 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAppointment();
              }}
              className="w-full flex items-center justify-center gap-2 bg-amber-600 hover:bg-amber-700 text-white font-bold py-2.5 rounded-lg shadow-sm"
            >
              <Calendar className="w-4 h-4" />
              <span>{isHindi ? "डॉक्टर परामर्श बुक करें" : "Book Doctor Consultation"}</span>
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenEmergency();
              }}
              className="w-full flex items-center justify-center gap-2 bg-rose-600 hover:bg-rose-700 text-white font-bold py-2.5 rounded-lg"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>{isHindi ? "24/7 आपातकालीन एम्बुलेंस" : "24/7 Emergency Ambulance"}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
