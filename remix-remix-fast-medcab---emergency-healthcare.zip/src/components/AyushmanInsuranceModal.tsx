import React from 'react';
import { 
  X, 
  Award, 
  CheckCircle2, 
  ShieldCheck, 
  Phone, 
  FileText
} from 'lucide-react';
import { INSURANCE_PARTNERS, HOSPITAL_INFO } from '../data/hospitalData';

interface AyushmanInsuranceModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
}

export const AyushmanInsuranceModal: React.FC<AyushmanInsuranceModalProps> = ({
  isOpen,
  onClose,
  isHindi
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">
                Government & Private TPA Helpdesk
              </span>
              <h3 className="text-xl font-black text-slate-900">
                Ayushman Bharat & Cashless TPA
              </h3>
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            Nova Shekhar Hospital supports cashless hospitalizations, government schemes, and corporate insurance claims. Our dedicated TPA desk assists with pre-authorization and claim processing.
          </p>

          {/* Scheme Box */}
          <div className="p-4 rounded-2xl bg-amber-50/80 border border-amber-200 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-900">
              <ShieldCheck className="w-4 h-4 text-amber-600" />
              <span>Ayushman Bharat PM-JAY Assistance</span>
            </div>
            <p className="text-xs text-amber-800 leading-relaxed">
              Patients holding a Golden Ayushman Card or UP Government Health Card can receive treatment guidance for surgery, ICU, and inpatient care under government guidelines.
            </p>
          </div>

          {/* Insurance Partners list */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Empaneled TPA & Insurance Networks:
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {INSURANCE_PARTNERS.map((partner, i) => (
                <div key={i} className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2 text-xs text-slate-800">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="truncate font-medium">{partner.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Required Documents checklist */}
          <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 text-xs text-slate-600">
            <div className="font-bold text-slate-800 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-blue-600" />
              <span>Documents Required for Cashless Admission:</span>
            </div>
            <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-500">
              <li>Patient Aadhaar Card & 2 Passport Photos</li>
              <li>Ayushman Bharat Golden Card / Insurance Health Card & Policy Copy</li>
              <li>Doctor's Admission Advice & Recent Lab Investigation Reports</li>
            </ul>
          </div>

          {/* Contact Helpline */}
          <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-100">
            <div className="text-xs">
              <span className="text-slate-400 block">TPA Desk Helpline:</span>
              <span className="font-black text-slate-900">{HOSPITAL_INFO.phone}</span>
            </div>
            <a
              href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
              className="px-5 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-2 shadow"
            >
              <Phone className="w-4 h-4" />
              <span>Call TPA Desk</span>
            </a>
          </div>

        </div>

      </div>
    </div>
  );
};
