import React, { useState, useEffect } from 'react';
import { 
  X, 
  Ambulance, 
  PhoneCall, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  Navigation, 
  ShieldCheck, 
  Flame,
  AlertCircle
} from 'lucide-react';
import { AmbulanceItem } from '../types';

interface AmbulanceTrackerModalProps {
  ambulance: AmbulanceItem | null;
  onClose: () => void;
}

export const AmbulanceTrackerModal: React.FC<AmbulanceTrackerModalProps> = ({ ambulance, onClose }) => {
  const [secondsRemaining, setSecondsRemaining] = useState(360); // 6 mins default
  const [statusStep, setStatusStep] = useState<1 | 2 | 3 | 4>(2); // 2 = En Route
  const [confirmedBooking, setConfirmedBooking] = useState(true);

  useEffect(() => {
    if (!ambulance) return;
    setSecondsRemaining(ambulance.etaMinutes * 60);

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          setStatusStep(4); // Arrived
          clearInterval(timer);
          return 0;
        }
        if (prev <= 120) {
          setStatusStep(3); // Turning into street
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [ambulance]);

  if (!ambulance) return null;

  const minutes = Math.floor(secondsRemaining / 60);
  const seconds = secondsRemaining % 60;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg rounded-3xl bg-[#061421] border border-[#00e5ff]/40 p-6 sm:p-8 shadow-[0_0_80px_rgba(0,229,255,0.25)] text-white">
        
        {/* Close Button */}
        <button
          type="button"
          id="close-ambulance-tracker"
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-gray-300 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Live Header with flashing beacon */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-[#ff3150]/20 border border-[#ff3150]/50 flex items-center justify-center text-[#ff4d67]">
            <Ambulance className="w-7 h-7 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black px-2 py-0.5 rounded-full bg-[#ff3150] text-white uppercase tracking-wider">
                LIVE DISPATCH
              </span>
              <span className="text-xs text-[#00ff9d] font-bold">● GPS Beacon Active</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5">
              {ambulance.providerName}
            </h2>
          </div>
        </div>

        {/* Live ETA Counter Banner */}
        <div className="p-5 rounded-2xl bg-gradient-to-r from-[#0a2335] to-[#04101a] border border-[#00e5ff]/30 mb-6 text-center shadow-inner">
          <span className="text-xs font-bold uppercase tracking-widest text-[#00e5ff] block mb-1">
            ESTIMATED TIME OF ARRIVAL
          </span>
          <div className="text-4xl sm:text-5xl font-extrabold text-white font-mono tracking-tight">
            {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </div>
          <p className="text-xs text-[#9bb3be] mt-1">
            Approaching from: <strong className="text-white">{ambulance.baseLocation}</strong> (~{ambulance.distanceKm} km away)
          </p>
        </div>

        {/* Progress Tracker Steps */}
        <div className="space-y-3 mb-6 p-4 rounded-2xl bg-black/40 border border-white/10 text-xs">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-4 h-4 text-[#00ff9d] shrink-0" />
            <span className="text-gray-300">Request Accepted & Paramedics Alerted</span>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-[#00e5ff] flex items-center justify-center shrink-0">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
            </div>
            <span className="text-white font-bold">
              Ambulance En Route with Active Sirens & Strobe
            </span>
          </div>

          <div className="flex items-center gap-3 opacity-60">
            <Clock className="w-4 h-4 text-gray-400 shrink-0" />
            <span className="text-gray-400">Arrival at Patient Pickup Location</span>
          </div>
        </div>

        {/* Driver & Unit Details Card */}
        <div className="grid grid-cols-2 gap-3 mb-6 text-xs p-3.5 rounded-xl bg-white/5 border border-white/10">
          <div>
            <span className="text-gray-400 block text-[10px] uppercase font-semibold">Driver / EMT</span>
            <span className="font-bold text-white text-sm">{ambulance.driverName}</span>
            <span className="text-[10px] text-[#00ff9d] block">BLS / ACLS Certified</span>
          </div>
          <div>
            <span className="text-gray-400 block text-[10px] uppercase font-semibold">Vehicle Plate</span>
            <span className="font-mono font-bold text-[#00e5ff] text-sm">{ambulance.vehicleNumber}</span>
            <span className="text-[10px] text-gray-300 block">{ambulance.ambulanceType}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <a
            href={`tel:${ambulance.phone}`}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-black shadow-[0_5px_20px_rgba(255,49,80,0.4)] transition-all"
          >
            <PhoneCall className="w-4 h-4" />
            <span>Call Driver Directly</span>
          </a>

          <button
            type="button"
            id="dismiss-tracker-btn"
            onClick={onClose}
            className="py-3 px-4 rounded-xl bg-white/10 hover:bg-white/15 text-gray-200 text-xs font-bold transition-all"
          >
            Keep Tracking in Background
          </button>
        </div>

      </div>
    </div>
  );
};
