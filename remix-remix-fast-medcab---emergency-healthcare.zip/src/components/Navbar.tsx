import React, { useState } from 'react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  Star, 
  Menu, 
  X, 
  Calendar, 
  Ambulance, 
  Award,
  Globe
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface NavbarProps {
  onOpenAppointment: (deptId?: string) => void;
  onOpenAmbulance: () => void;
  onOpenAyushman: () => void;
  isHindi: boolean;
  setIsHindi: React.Dispatch<React.SetStateAction<boolean>>;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenAppointment,
  onOpenAmbulance,
  onOpenAyushman,
  isHindi,
  setIsHindi
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: isHindi ? 'विशेषताएं' : 'Departments', href: '#specialties' },
    { label: isHindi ? 'आईसीयू व इमरजेंसी' : 'ICU & Emergency', href: '#emergency-icu' },
    { label: isHindi ? 'नेत्र अस्पताल' : 'Eye Hospital', href: '#eye-hospital' },
    { label: isHindi ? 'डायलिसिस व ओटी' : 'Dialysis & OT', href: '#dialysis-ot' },
    { label: isHindi ? 'चिकित्सक सूची' : 'Doctors & OPD', href: '#doctors' },
    { label: isHindi ? '5.0★ समीक्षाएं' : '5.0★ Reviews', href: '#reviews' },
    { label: isHindi ? 'रास्ता व पता' : 'Location (NH-25)', href: '#location' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full shadow-sm">
      {/* Top Emergency & Info Banner */}
      <div className="bg-slate-900 text-slate-100 text-xs py-2 px-4 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <a 
              href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`} 
              className="flex items-center gap-1.5 font-bold text-emerald-400 hover:text-emerald-300 transition-colors"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
              </span>
              <Phone className="w-3.5 h-3.5" />
              <span>24/7 Emergency: {HOSPITAL_INFO.phone}</span>
            </a>

            <div className="hidden md:flex items-center gap-1 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-blue-400 shrink-0" />
              <span className="truncate max-w-xs lg:max-w-md">MGIMT Campus, Kanpur Road (NH-25), Banthara</span>
            </div>

            <div className="hidden lg:flex items-center gap-1.5 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>OPD: 9am - 5pm (Closes 5pm) · Emergency Open 24x7</span>
            </div>
          </div>

          <div className="flex items-center gap-3 ml-auto">
            {/* Google Rating badge */}
            <a 
              href="#reviews"
              className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-semibold"
            >
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span>5.0 Google Reviews (Top in Banthara)</span>
            </a>

            {/* Language toggle */}
            <button
              onClick={() => setIsHindi(prev => !prev)}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Toggle Hindi / English"
            >
              <Globe className="w-3 h-3 text-blue-400" />
              <span>{isHindi ? 'English' : 'हिंदी'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <nav className="bg-white/95 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          {/* Logo Branding */}
          <a href="#" className="flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-700 to-indigo-800 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              <div className="relative flex items-center justify-center">
                <span className="font-extrabold text-2xl tracking-tighter">N</span>
                <span className="text-red-400 font-black text-xl absolute -right-1 -top-1">+</span>
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-lg sm:text-xl tracking-tight text-slate-900 leading-none">
                  NOVA SHEKHAR
                </span>
                <span className="font-bold text-lg sm:text-xl text-blue-700 leading-none">
                  HOSPITAL
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 mt-1 flex items-center gap-1">
                <span>{isHindi ? 'मल्टी-स्पेशलिटी एवं ट्रामा सेंटर' : 'Multi-Speciality & Trauma Centre'}</span>
                <span className="inline-block w-1 h-1 rounded-full bg-slate-400"></span>
                <span className="text-blue-700 font-semibold">Banthara, NH-25</span>
              </p>
            </div>
          </a>

          {/* Desktop Nav Links */}
          <div className="hidden xl:flex items-center gap-6 text-sm font-semibold text-slate-600">
            {navLinks.map((link) => (
              <a 
                key={link.label} 
                href={link.href}
                className="hover:text-blue-700 transition-colors py-1 relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-blue-700 hover:after:w-full after:transition-all"
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-3">
            <button
              onClick={() => onOpenAyushman()}
              className="px-3 py-2 rounded-lg text-xs font-semibold bg-amber-50 text-amber-900 border border-amber-300 hover:bg-amber-100 transition flex items-center gap-1.5"
            >
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>{isHindi ? 'आयुष्मान / कैशलेस' : 'Ayushman / TPA'}</span>
            </button>

            <button
              onClick={() => onOpenAmbulance()}
              className="px-3 py-2 rounded-lg text-xs font-semibold bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100 transition flex items-center gap-1.5"
            >
              <Ambulance className="w-3.5 h-3.5 text-rose-600" />
              <span>{isHindi ? 'एम्बुलेंस' : 'Ambulance'}</span>
            </button>

            <button
              onClick={() => onOpenAppointment()}
              className="px-4 py-2.5 rounded-lg text-xs font-bold bg-blue-700 hover:bg-blue-800 text-white shadow-sm shadow-blue-500/20 transition flex items-center gap-1.5"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{isHindi ? 'अपॉइंटमेंट बुक करें' : 'Book OPD Appointment'}</span>
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="flex items-center gap-2 xl:hidden">
            <a
              href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
              className="p-2 rounded-lg bg-red-600 text-white flex items-center justify-center sm:hidden"
              aria-label="Call Emergency"
            >
              <Phone className="w-4 h-4" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(prev => !prev)}
              className="p-2.5 rounded-lg text-slate-700 hover:bg-slate-100 transition"
              aria-label="Open navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>

        {/* Mobile menu drop-down */}
        {mobileMenuOpen && (
          <div className="xl:hidden bg-white border-t border-slate-200 px-4 py-6 space-y-4 shadow-xl">
            <div className="p-3 bg-blue-50 border border-blue-100 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-900">24/7 Emergency Casualty</span>
                <span className="text-[10px] bg-red-500 text-white font-bold px-2 py-0.5 rounded-full">ACTIVE</span>
              </div>
              <a 
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 px-4 rounded-lg text-sm shadow"
              >
                <Phone className="w-4 h-4" />
                <span>Call Emergency: {HOSPITAL_INFO.phone}</span>
              </a>
            </div>

            <div className="grid grid-cols-1 gap-2 pt-2">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 rounded-lg text-slate-700 hover:bg-slate-50 font-medium text-sm transition"
                >
                  {link.label}
                </a>
              ))}
            </div>

            <div className="pt-2 grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAmbulance();
                }}
                className="flex items-center justify-center gap-1.5 p-2.5 rounded-lg border border-rose-300 bg-rose-50 text-rose-700 font-semibold text-xs"
              >
                <Ambulance className="w-4 h-4 text-rose-600" />
                <span>Ambulance</span>
              </button>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAyushman();
                }}
                className="flex items-center justify-center gap-1.5 p-2.5 rounded-lg border border-amber-300 bg-amber-50 text-amber-800 font-semibold text-xs"
              >
                <Award className="w-4 h-4 text-amber-600" />
                <span>Ayushman Card</span>
              </button>
            </div>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAppointment();
              }}
              className="w-full flex items-center justify-center gap-2 p-3 rounded-lg bg-blue-700 text-white font-bold text-sm shadow-md"
            >
              <Calendar className="w-4 h-4" />
              <span>{isHindi ? 'डॉक्टर परामर्श बुक करें' : 'Book OPD Appointment'}</span>
            </button>
          </div>
        )}
      </nav>
    </header>
  );
};
