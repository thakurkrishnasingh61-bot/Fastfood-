import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  X, 
  LogOut, 
  User, 
  Mail, 
  ShieldCheck, 
  Phone, 
  Heart, 
  MapPin, 
  Check, 
  AlertCircle,
  Clock,
  Droplet
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, isHindi }) => {
  const { user, profile, signInWithGoogle, signOut, updateProfileData } = useAuth();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isSigningOut, setIsSigningOut] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Editable health profile form
  const [bloodGroup, setBloodGroup] = useState(profile?.bloodGroup || '');
  const [emergencyContact, setEmergencyContact] = useState(profile?.emergencyContact || '');
  const [city, setCity] = useState(profile?.city || '');

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg(null);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: any) {
      console.error(err);
      if (err?.code === 'auth/popup-closed-by-user') {
        setErrorMsg(isHindi ? 'लॉगिन विंडो बंद कर दी गई थी।' : 'Sign-in popup was closed.');
      } else if (err?.code === 'auth/popup-blocked') {
        setErrorMsg(isHindi ? 'ब्राउज़र पॉप-अप ब्लॉक हो गया। कृपया पॉप-अप की अनुमति दें।' : 'Popup was blocked by browser. Please allow popups.');
      } else {
        setErrorMsg(err.message || (isHindi ? 'लॉगिन असफल रहा। पुनः प्रयास करें।' : 'Sign-in failed. Please try again.'));
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    setIsSigningOut(true);
    try {
      await signOut();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Logout failed');
    } finally {
      setIsSigningOut(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateProfileData({
        bloodGroup,
        emergencyContact,
        city
      });
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update details');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl bg-gradient-to-b from-[#081926] to-[#040c14] border border-cyan-500/30 p-6 text-white shadow-2xl shadow-cyan-950/60 overflow-hidden">
        
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-rose-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {!user ? (
          /* Sign In View */
          <div className="space-y-6 text-center py-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-tr from-cyan-500/20 to-blue-500/30 border border-cyan-400/40 flex items-center justify-center shadow-lg shadow-cyan-950/50">
              <ShieldCheck className="w-9 h-9 text-cyan-400" />
            </div>

            <div>
              <h2 className="text-2xl font-black tracking-tight text-white">
                {isHindi ? 'Google से लॉगिन करें' : 'Sign in with Google'}
              </h2>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {isHindi 
                  ? 'अपने आपातकालीन स्वास्थ्य प्रोफाइल, सहेजे गए अस्पताल, एम्बुलेंस बुकिंग और रक्तदाताओं की जानकारी को सुरक्षित रूप से सिंक करें।' 
                  : 'Sync your emergency medical profile, saved hospitals, ambulance dispatches, and emergency contacts.'}
              </p>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Google Sign In Button */}
            <div className="pt-2">
              <button
                onClick={handleGoogleSignIn}
                disabled={isSigningIn}
                className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl bg-white hover:bg-slate-100 text-slate-900 font-bold text-sm shadow-xl shadow-black/40 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-60"
              >
                {/* Official Google 'G' Icon */}
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.27 21.36 7.35 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.97 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>
                  {isSigningIn 
                    ? (isHindi ? 'लॉगिन हो रहा है...' : 'Connecting...') 
                    : (isHindi ? 'Google खाते से लॉगिन करें' : 'Continue with Google')}
                </span>
              </button>
            </div>

            <div className="pt-2 border-t border-white/10 flex items-center justify-center gap-2 text-[11px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isHindi ? '100% सुरक्षित एवं निजी (Firebase Auth)' : '100% Secure & Private Authentication'}</span>
            </div>
          </div>
        ) : (
          /* Profile & Sign Out View */
          <div className="space-y-5">
            {/* Header with Avatar */}
            <div className="flex items-center gap-3 pb-4 border-b border-white/10">
              {user.photoURL ? (
                <img 
                  src={user.photoURL} 
                  alt={user.displayName || 'User'} 
                  className="w-14 h-14 rounded-full border-2 border-cyan-400 shadow-lg object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-14 h-14 rounded-full bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 font-bold text-xl">
                  {user.displayName?.charAt(0) || user.email?.charAt(0) || 'U'}
                </div>
              )}

              <div className="flex-1 min-w-0">
                <h3 className="text-base font-bold text-white truncate">
                  {user.displayName || (isHindi ? 'उपयोगकर्ता' : 'User')}
                </h3>
                <p className="text-xs text-slate-400 truncate flex items-center gap-1">
                  <Mail className="w-3 h-3 text-slate-400 shrink-0" />
                  <span>{user.email}</span>
                </p>
                <div className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-500/40 text-[10px] font-bold text-emerald-400">
                  <Check className="w-2.5 h-2.5" />
                  <span>{isHindi ? 'Google प्रमाणित' : 'Google Verified'}</span>
                </div>
              </div>
            </div>

            {/* Emergency Medical Info Card */}
            <form onSubmit={handleSaveProfile} className="space-y-3 bg-[#061421] p-3.5 rounded-xl border border-white/10">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                  <Heart className="w-3.5 h-3.5 text-rose-400" />
                  {isHindi ? 'आपातकालीन स्वास्थ्य कार्ड' : 'Emergency Medical Profile'}
                </span>
                {saveSuccess && (
                  <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    {isHindi ? 'सहेजा गया' : 'Saved'}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <Droplet className="w-3 h-3 text-rose-400" />
                    {isHindi ? 'ब्लड ग्रुप' : 'Blood Group'}
                  </label>
                  <select
                    value={bloodGroup}
                    onChange={(e) => setBloodGroup(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0a1f33] border border-white/15 text-white text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="">{isHindi ? 'चुनें' : 'Select'}</option>
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(bg => (
                      <option key={bg} value={bg}>{bg}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-cyan-400" />
                    {isHindi ? 'शहर / गाँव' : 'City / Village'}
                  </label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder={isHindi ? 'जैसे हरदोई, लखनऊ' : 'e.g. Lucknow'}
                    className="w-full px-2.5 py-1.5 rounded-lg bg-[#0a1f33] border border-white/15 text-white text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1 flex items-center gap-1">
                  <Phone className="w-3 h-3 text-emerald-400" />
                  {isHindi ? 'आपातकालीन पारिवारिक संपर्क (SOS Contact)' : 'Emergency Contact Phone'}
                </label>
                <input
                  type="tel"
                  value={emergencyContact}
                  onChange={(e) => setEmergencyContact(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full px-2.5 py-1.5 rounded-lg bg-[#0a1f33] border border-white/15 text-white text-xs focus:outline-none focus:border-cyan-400"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition shadow"
              >
                {isHindi ? 'जानकारी सहेजें' : 'Save Details'}
              </button>
            </form>

            {/* Actions: Sign Out */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleSignOut}
                disabled={isSigningOut}
                className="flex-1 py-2.5 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                <LogOut className="w-4 h-4" />
                <span>{isSigningOut ? (isHindi ? 'लॉगआउट हो रहा है...' : 'Logging out...') : (isHindi ? 'लॉगआउट करें' : 'Logout')}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="py-2.5 px-5 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold transition"
              >
                {isHindi ? 'बंद करें' : 'Close'}
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
