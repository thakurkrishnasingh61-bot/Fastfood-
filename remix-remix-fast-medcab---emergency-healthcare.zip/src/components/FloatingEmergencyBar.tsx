import React from 'react';
import { Phone, Calendar, Navigation, Ambulance, Star } from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface FloatingEmergencyBarProps {
  onOpenAppointment: () => void;
  onOpenAmbulance: () => void;
  isHindi: boolean;
}

export const FloatingEmergencyBar: React.FC<FloatingEmergencyBarProps> = ({
  onOpenAppointment,
  onOpenAmbulance,
  isHindi
}) => {
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=Nova+Shekhar+Hospital+MGIMT+Campus+Banthara+Kanpur+Road+Uttar+Pradesh`;

  return (
    <aside aria-label="Quick Action Toolbar" className="fixed bottom-0 inset-x-0 z-40 bg-slate-900/95 backdrop-blur-md border-t border-slate-800 p-2 sm:p-3 shadow-2xl transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Left hospital info snippet for tablet/desktop */}
        <div className="hidden md:flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-400/30">
            <Star className="w-3.5 h-3.5 fill-amber-400" />
            <span>5.04 ★ Google</span>
          </div>
          <div className="text-xs text-slate-300">
            <span className="font-bold text-white">NOVA SHEKHAR HOSPITAL</span> · NH-25 Banthara (Closes 5pm, 24/7 ICU)
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between sm:justify-end gap-2 w-full md:w-auto">
          
          {/* Direct Phone */}
          <a
            href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
            className="flex-1 sm:flex-initial py-2.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition animate-pulse"
          >
            <Phone className="w-4 h-4" />
            <span>Call: {HOSPITAL_INFO.phone}</span>
          </a>

          {/* Book Appointment */}
          <button
            onClick={onOpenAppointment}
            className="flex-1 sm:flex-initial py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition"
          >
            <Calendar className="w-4 h-4" />
            <span>{isHindi ? 'अपॉइंटमेंट' : 'Book OPD'}</span>
          </button>

          {/* Ambulance Dispatch */}
          <button
            onClick={onOpenAmbulance}
            className="hidden sm:flex py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-300 border border-slate-700 font-semibold text-xs items-center gap-1.5 transition"
          >
            <Ambulance className="w-4 h-4 text-rose-400" />
            <span>Ambulance</span>
          </button>

          {/* Directions */}
          <a
            href={googleMapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden sm:flex py-2.5 px-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs items-center gap-1.5 transition"
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-400" />
            <span>Directions</span>
          </a>

        </div>

      </div>
    </aside>
  );
};
