import React, { useState } from 'react';
import { 
  MapPin, 
  Navigation, 
  Phone, 
  Clock, 
  Compass, 
  Car, 
  CheckCircle2, 
  ExternalLink, 
  ShieldAlert, 
  Ambulance, 
  Building
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface LocationSectionProps {
  onOpenAmbulance: () => void;
  isHindi: boolean;
}

export const LocationSection: React.FC<LocationSectionProps> = ({
  onOpenAmbulance,
  isHindi
}) => {
  const [selectedRoute, setSelectedRoute] = useState<number>(0);

  const routes = [
    {
      from: "Banthara Bazaar / Khandedev",
      distance: "1.2 km",
      time: "3 mins",
      routeNotes: "Drive straight on Kanpur Road (NH-25) towards MGIMT Campus entrance."
    },
    {
      from: "Amausi Airport (Chaudhary Charan Singh)",
      distance: "10.5 km",
      time: "12 mins",
      routeNotes: "Head straight towards Kanpur on NH-25 bypass, hospital is on the left inside MGIMT Campus."
    },
    {
      from: "Sarojini Nagar, Lucknow",
      distance: "6.8 km",
      time: "8 mins",
      routeNotes: "Direct four-lane highway connectivity on Kanpur Road."
    },
    {
      from: "Charbagh / Alambagh, Lucknow",
      distance: "19.5 km",
      time: "24 mins",
      routeNotes: "Take Kanpur Road flyover past Transport Nagar, straight to Banthara."
    },
    {
      from: "Unnao City / Highway",
      distance: "36 km",
      time: "35 mins",
      routeNotes: "Drive towards Lucknow on NH-25, convenient U-turn/highway entry right at MGIMT Campus."
    }
  ];

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=Nova+Shekhar+Hospital+MGIMT+Campus+Banthara+Kanpur+Road+Uttar+Pradesh`;

  return (
    <section id="location" className="py-16 sm:py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Compass className="w-3.5 h-3.5 text-blue-600" />
            <span>Prime Highway Connectivity</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {isHindi ? "अस्पताल का पता एवं पहुंचने का मार्ग" : "Hospital Location & Driving Directions"}
          </h2>
          <p className="text-slate-600 mt-2 text-base">
            {isHindi 
              ? "एमजीआईएमटी कैंपस, कानपुर रोड (NH-25), बंथरा, उत्तर प्रदेश 226401. लखनऊ एवं उन्नाव दोनों ओर से आसान व सीधा रास्ता।"
              : "Located inside MGIMT Campus on Kanpur - Lucknow National Highway 25. Rapid access for emergency highway trauma and scheduled OPD consultations."
            }
          </p>
        </div>

        {/* Location Content Box */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Official Contact Card & Route Calculator */}
          <div className="lg:col-span-6 space-y-6 flex flex-col justify-between">
            
            {/* Address Box */}
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 text-white shadow-xl space-y-6">
              <div>
                <span className="text-xs font-bold tracking-wider uppercase text-blue-400">
                  Official Registered Address
                </span>
                <h3 className="text-2xl font-black text-white mt-1">
                  NOVA SHEKHAR HOSPITAL
                </h3>
                <p className="text-slate-300 text-sm mt-2 leading-relaxed flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-1" />
                  <span>
                    <strong>MGIMT CAMPUS, KANPUR -ROAD (NH-25), BANTHARA</strong>, Uttar Pradesh 226401
                  </span>
                </p>
              </div>

              {/* Quick Specs Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>OPD Working Hours</span>
                  </div>
                  <div className="text-sm font-bold text-white">Open · Closes 5:00 PM</div>
                  <div className="text-[11px] text-amber-300">Mon - Sun: 9am - 5pm</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700 space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Emergency & ICU</span>
                  </div>
                  <div className="text-sm font-bold text-emerald-400">Open 24 Hours</div>
                  <div className="text-[11px] text-slate-400">Trauma & ICU Casualty</div>
                </div>
              </div>

              {/* Phone Contacts */}
              <div className="p-4 rounded-xl bg-slate-800/90 border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3">
                <div>
                  <span className="text-xs text-slate-400 block">Direct Telephone / Ambulance:</span>
                  <a 
                    href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`} 
                    className="text-lg font-black text-white hover:text-emerald-400 transition"
                  >
                    {HOSPITAL_INFO.phone}
                  </a>
                </div>
                <a
                  href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                  className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow transition"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call Hospital</span>
                </a>
              </div>

              {/* Direction CTAs */}
              <div className="flex flex-wrap gap-3 pt-1">
                <a
                  href={googleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition"
                >
                  <Navigation className="w-4 h-4" />
                  <span>Open in Google Maps</span>
                </a>

                <button
                  onClick={onOpenAmbulance}
                  className="py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md transition"
                >
                  <Ambulance className="w-4 h-4" />
                  <span>Call Ambulance</span>
                </button>
              </div>

            </div>

            {/* Travel Times Calculator */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <Car className="w-4 h-4 text-blue-600" />
                  <span>Estimated Driving Distance to MGIMT Campus</span>
                </h4>
                <span className="text-[11px] text-slate-500">Select Starting Point:</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {routes.map((r, i) => (
                  <button
                    key={r.from}
                    onClick={() => setSelectedRoute(i)}
                    className={`p-2.5 rounded-xl text-left transition border text-xs ${
                      selectedRoute === i
                        ? 'bg-blue-700 text-white border-blue-700 shadow-sm font-bold'
                        : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
                    }`}
                  >
                    <div className="truncate font-semibold">{r.from}</div>
                    <div className={`text-[11px] mt-0.5 ${selectedRoute === i ? 'text-blue-100' : 'text-slate-500'}`}>
                      {r.time} ({r.distance})
                    </div>
                  </button>
                ))}
              </div>

              <div className="p-3.5 rounded-xl bg-white border border-slate-200 text-xs text-slate-600 space-y-1">
                <div className="font-bold text-slate-900 flex items-center justify-between">
                  <span>From: {routes[selectedRoute].from}</span>
                  <span className="text-emerald-700 font-bold">{routes[selectedRoute].distance} • {routes[selectedRoute].time}</span>
                </div>
                <p className="text-slate-500">{routes[selectedRoute].routeNotes}</p>
              </div>
            </div>

          </div>

          {/* Right Column: Embedded Map Simulation + Campus Amenities */}
          <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
            
            {/* Map Frame */}
            <div className="rounded-3xl overflow-hidden border border-slate-200 shadow-md bg-slate-100 relative h-96 sm:h-[420px]">
              
              {/* Real OpenStreetMap embed centered on Banthara / Kanpur Road NH-25 */}
              <iframe
                title="Nova Shekhar Hospital Location Map"
                className="w-full h-full border-0"
                src="https://www.openstreetmap.org/export/embed.html?bbox=80.7958%2C26.6776%2C80.8558%2C26.7176&amp;layer=mapnik&amp;marker=26.6976%2C80.8258"
              ></iframe>

              {/* Map Floating Card */}
              <div className="absolute top-4 left-4 right-4 sm:right-auto sm:max-w-xs bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-slate-200 space-y-2 pointer-events-auto">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-600 animate-ping"></div>
                  <span className="font-black text-slate-900 text-xs">NOVA SHEKHAR HOSPITAL</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-tight">
                  MGIMT Campus, Kanpur Road (NH-25), Banthara, Uttar Pradesh
                </p>
                <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[11px]">
                  <span className="text-amber-600 font-bold">5.0 ★ Google reviews</span>
                  <a 
                    href={googleMapsUrl}
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-700 font-bold hover:underline flex items-center gap-1"
                  >
                    <span>Directions</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Bottom Quick Overlay */}
              <div className="absolute bottom-4 right-4 bg-slate-900/90 backdrop-blur-md text-white px-3 py-1.5 rounded-xl text-xs font-bold shadow">
                NH-25 Highway Entry Gate
              </div>
            </div>

            {/* Campus Amenities & Accessibility */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-200 space-y-3">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Building className="w-4 h-4 text-blue-600" />
                <span>MGIMT Campus Facilities for Patients & Families</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
                <div className="p-3 rounded-xl bg-white border border-slate-100 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Ample Car & Ambulance Parking</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-slate-100 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Wheelchair & Stretcher Ramps</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-slate-100 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Spacious Green Campus Environment</span>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
