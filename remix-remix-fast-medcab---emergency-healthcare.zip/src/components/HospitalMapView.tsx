import React from 'react';
import { HospitalItem } from '../types';
import { FacilityMapView } from './FacilityMapView';

interface HospitalMapViewProps {
  hospitals: HospitalItem[];
  onSelectHospital: (hospital: HospitalItem) => void;
  searchLocation?: string;
}

export const HospitalMapView: React.FC<HospitalMapViewProps> = ({
  hospitals,
  onSelectHospital,
  searchLocation = ''
}) => {
  return (
    <FacilityMapView
      category="hospital"
      hospitals={hospitals}
      ambulances={[]}
      bloodDonors={[]}
      doctors={[]}
      pharmacies={[]}
      labs={[]}
      searchLocation={searchLocation}
      onSelectHospital={onSelectHospital}
    />
  );
};
