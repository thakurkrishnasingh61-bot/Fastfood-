import React from 'react';
import { 
  Phone, 
  MapPin, 
  Clock, 
  Star, 
  Calendar, 
  Navigation, 
  HeartPulse, 
  Eye, 
  Baby, 
  Droplets, 
  Activity, 
  CheckCircle2, 
  ShieldAlert
} from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface HeroProps {
  onOpenAppointment: () => void;
  onOpenAmbulance: () => void;
  isHindi: boolean;
}

export const Hero: React.FC<HeroProps> = ({
  onOpenAppointment,
  onOpenAmbulance,
  isHindi
}) => {
  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=Nova+Shekhar+Hospital+MGIMT+Campus+Banthara+Kanpur+Road+Uttar+Pradesh`;

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-blue-900 via-slate-900 to-slate-950 text-white pt-8 pb-16 lg:pt-14 lg:pb-24">
      {/* Background ambient lighting effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/3 right-10 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-full max-w-5xl h-32 bg-blue-500/10 blur-2xl pointer-events-none"></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Badges */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-xs sm:text-sm font-semibold">
            <div className="flex items-center text-amber-400">
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
              <Star className="w-4 h-4 fill-amber-400" />
            </div>
            <span className="font-bold text-white">5.04</span>
            <span className="text-amber-200">Google reviews</span>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs sm:text-sm font-medium">
            <MapPin className="w-3.5 h-3.5 text-blue-400" />
            <span>Khandedev, Banthara (NH-25 Kanpur Road, UP)</span>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs sm:text-sm font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>24/7 Emergency & ICU Active</span>
          </div>
        </div>

        {/* Grid layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Heading, Subtitle, Actions */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-3">
              <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight">
                NOVA SHEKHAR <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-300 to-emerald-400">
                  HOSPITAL
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl font-semibold text-slate-200">
                {isHindi 
                  ? "24/7 मल्टी-स्पेशलिटी हॉस्पिटल, क्रिटिकल आईसीयू, नेत्र चिकित्सालय एवं डायलिसिस केंद्र"
                  : "24/7 Multi-Speciality, Critical Trauma ICU, Eye Hospital & Hemodialysis Centre"
                }
              </p>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
                {isHindi
                  ? "एमजीआईएमटी कैंपस, कानपुर रोड (NH-25), बंथरा, उत्तर प्रदेश में स्थित। उच्च कोटि के अनुभवी डॉक्टरों, अत्याधुनिक वेंटिलेटर आईसीयू, मॉड्युलर ऑपरेशन थिएटर, फेको आई सर्जरी, डायलिसिस एवं महिला प्रसूति रोग विशेषज्ञ द्वारा विश्वसनीय उपचार।"
                  : "Located at MGIMT Campus on Kanpur Road (NH-25), Banthara, Uttar Pradesh. Equipped with state-of-the-art ICU ventilators, specialized Eye Hospital, sterile Modular OTs, high-flux Hemodialysis, and 24/7 emergency casualty response."
                }
              </p>
            </div>

            {/* Core Department Badges matching user prompt */}
            <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 backdrop-blur-sm space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                From NOVA SHEKHAR HOSPITAL:
              </span>
              <div className="flex flex-wrap gap-2 text-xs sm:text-sm font-bold">
                <span className="px-3 py-1 rounded-lg bg-red-500/20 text-red-300 border border-red-500/40 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                  EMERGENCY 24x7
                </span>
                <span className="px-3 py-1 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1.5">
                  <HeartPulse className="w-3.5 h-3.5 text-rose-400" />
                  ICU (VENTILATORS)
                </span>
                <span className="px-3 py-1 rounded-lg bg-sky-500/20 text-sky-300 border border-sky-500/40 flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5 text-sky-400" />
                  EYE HOSPITAL (PHACO)
                </span>
                <span className="px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-emerald-400" />
                  MODULAR OT
                </span>
                <span className="px-3 py-1 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/40 flex items-center gap-1.5">
                  <Droplets className="w-3.5 h-3.5 text-blue-400" />
                  DIALYSIS UNIT
                </span>
                <span className="px-3 py-1 rounded-lg bg-pink-500/20 text-pink-300 border border-pink-500/40 flex items-center gap-1.5">
                  <Baby className="w-3.5 h-3.5 text-pink-400" />
                  GYNECOLOGIST
                </span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-3 sm:gap-4 pt-2">
              <a
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-black text-sm sm:text-base shadow-lg shadow-red-600/30 transition transform hover:-translate-y-0.5"
              >
                <Phone className="w-5 h-5 animate-pulse" />
                <span>Call Emergency: {HOSPITAL_INFO.phone}</span>
              </a>

              <button
                onClick={onOpenAppointment}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm sm:text-base shadow-lg shadow-blue-600/30 transition transform hover:-translate-y-0.5"
              >
                <Calendar className="w-5 h-5" />
                <span>{isHindi ? 'डॉक्टर परामर्श बुक करें' : 'Book OPD Appointment'}</span>
              </button>

              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm transition"
              >
                <Navigation className="w-4 h-4 text-emerald-400" />
                <span>{isHindi ? 'रास्ता देखें (Google Maps)' : 'Directions (NH-25)'}</span>
              </a>
            </div>

            {/* Trust points */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Ayushman & Cashless TPA</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero Wait Highway Triage</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>24x7 In-House Pharmacy & Lab</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hospital Quick Summary Card & Highlights */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-gradient-to-br from-slate-800/90 to-slate-900/90 border border-slate-700 p-6 shadow-2xl backdrop-blur-md space-y-6">
              
              {/* Card Header with Google Reviews */}
              <div className="flex items-start justify-between border-b border-slate-700/80 pb-4">
                <div>
                  <span className="text-[11px] font-bold tracking-wider uppercase text-blue-400">
                    Official Business Profile
                  </span>
                  <h3 className="text-xl font-bold text-white mt-0.5">
                    NOVA SHEKHAR HOSPITAL
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    MGIMT Campus, Kanpur - Road (NH-25), Banthara, UP 226401
                  </p>
                </div>
                <div className="text-right shrink-0 bg-slate-900/80 p-2 rounded-xl border border-slate-700">
                  <div className="flex items-center gap-1 text-amber-400 font-black text-lg">
                    <span>5.04</span>
                    <Star className="w-4 h-4 fill-amber-400" />
                  </div>
                  <span className="text-[10px] text-slate-400">Google rating</span>
                </div>
              </div>

              {/* Status Indicators */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <Clock className="w-3.5 h-3.5 text-amber-400" />
                    <span>OPD Consultation</span>
                  </div>
                  <div className="mt-1 font-bold text-white text-sm">
                    9:00 AM – 5:00 PM
                  </div>
                  <span className="inline-block mt-0.5 text-[10px] text-amber-300 font-medium">
                    Closes 5:00 PM today
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                  <div className="flex items-center gap-1.5 text-xs text-slate-400">
                    <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                    <span>Emergency & ICU</span>
                  </div>
                  <div className="mt-1 font-bold text-white text-sm">
                    Open 24 Hours
                  </div>
                  <span className="inline-block mt-0.5 text-[10px] text-emerald-400 font-medium">
                    ● Always Available
                  </span>
                </div>
              </div>

              {/* Highway Location highlight */}
              <div className="p-3.5 rounded-xl bg-blue-950/40 border border-blue-800/40 space-y-1.5">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-300">
                  <MapPin className="w-4 h-4 text-blue-400 shrink-0" />
                  <span>Strategic Highway Access</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Located directly on Kanpur-Lucknow National Highway (NH-25) inside MGIMT Campus. Immediate trauma intake for Banthara, Khandedev, Sarojini Nagar, and Unnao travelers.
                </p>
              </div>

              {/* Direct Quick Contact Buttons */}
              <div className="space-y-2.5 pt-1">
                <a
                  href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-between transition shadow-md"
                >
                  <span className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    <span>Helpline: {HOSPITAL_INFO.phone}</span>
                  </span>
                  <span className="text-xs bg-emerald-700/80 px-2 py-0.5 rounded">Call Now</span>
                </a>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={onOpenAmbulance}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                  >
                    <span className="w-2 h-2 rounded-full bg-red-500"></span>
                    <span>NH-25 Ambulance</span>
                  </button>

                  <a
                    href="#reviews"
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                  >
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>Read 5.0 Reviews</span>
                  </a>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
