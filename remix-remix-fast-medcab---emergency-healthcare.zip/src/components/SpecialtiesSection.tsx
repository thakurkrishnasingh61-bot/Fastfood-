import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  HeartPulse, 
  Eye, 
  Activity, 
  Droplets, 
  Baby, 
  Stethoscope, 
  Check, 
  Calendar, 
  Phone, 
  Clock, 
  Sparkles
} from 'lucide-react';
import { SPECIALTIES_DATA, HOSPITAL_INFO } from '../data/hospitalData';

interface SpecialtiesSectionProps {
  onSelectDepartment: (deptId: string) => void;
  isHindi: boolean;
}

export const SpecialtiesSection: React.FC<SpecialtiesSectionProps> = ({
  onSelectDepartment,
  isHindi
}) => {
  const [selectedId, setSelectedId] = useState<string>(SPECIALTIES_DATA[0].id);

  // Sync tab with URL hash if navigated via Navbar or deep links
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.toLowerCase();
      if (hash.includes('eye')) {
        setSelectedId('eye');
      } else if (hash.includes('dialysis') || hash.includes('ot')) {
        setSelectedId('dialysis');
      } else if (hash.includes('emergency') || hash.includes('icu')) {
        setSelectedId('emergency');
      }
    };

    handleHash();
    window.addEventListener('hashchange', handleHash);
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const activeSpecialty = SPECIALTIES_DATA.find(s => s.id === selectedId) || SPECIALTIES_DATA[0];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldAlert': return <ShieldAlert className="w-6 h-6" />;
      case 'HeartPulse': return <HeartPulse className="w-6 h-6" />;
      case 'Eye': return <Eye className="w-6 h-6" />;
      case 'Activity': return <Activity className="w-6 h-6" />;
      case 'Droplets': return <Droplets className="w-6 h-6" />;
      case 'Baby': return <Baby className="w-6 h-6" />;
      case 'Stethoscope': return <Stethoscope className="w-6 h-6" />;
      default: return <Activity className="w-6 h-6" />;
    }
  };

  return (
    <section id="specialties" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 border border-blue-200 text-blue-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>From NOVA SHEKHAR HOSPITAL</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {isHindi ? "प्रमुख चिकित्सा विभाग एवं विशेषज्ञ सेवाएं" : "Core Specialties & Advanced Clinical Units"}
          </h2>
          <p className="text-slate-600 mt-3 text-base">
            {isHindi 
              ? "कानपुर रोड (NH-25), बंथरा में चौबीसों घंटे आपातकालीन चिकित्सा, उच्च स्तरीय आईसीयू, फेको नेत्र अस्पताल, मॉड्युलर ओटी एवं डायलिसिस की पूर्ण व्यवस्था।"
              : "State-of-the-art emergency trauma, intensive care, eye hospital, sterile modular surgical suites, and hemodialysis at MGIMT Campus, Banthara."
            }
          </p>
        </div>

        {/* Department Pills / Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-thin scrollbar-thumb-slate-300">
          {SPECIALTIES_DATA.map((specialty) => {
            const isSelected = specialty.id === selectedId;
            return (
              <button
                key={specialty.id}
                onClick={() => setSelectedId(specialty.id)}
                className={`shrink-0 flex items-center gap-2.5 px-4 py-3 rounded-xl font-bold text-xs sm:text-sm transition shadow-sm ${
                  isSelected
                    ? 'bg-blue-700 text-white shadow-blue-600/20'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                <span className={isSelected ? 'text-white' : 'text-blue-600'}>
                  {getIcon(specialty.icon)}
                </span>
                <span>{isHindi ? specialty.hindiName.split('(')[0] : specialty.name.split('(')[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Active Specialty Detailed Showcase Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            
            {/* Left Column: Details */}
            <div className="lg:col-span-7 p-6 sm:p-10 space-y-6">
              
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 font-bold text-xs uppercase tracking-wide">
                    {activeSpecialty.stats}
                  </span>
                  <span className="flex items-center gap-1 text-xs text-slate-500 font-medium">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    {activeSpecialty.timing}
                  </span>
                </div>

                <h3 className="text-2xl sm:text-3xl font-black text-slate-900">
                  {isHindi ? activeSpecialty.hindiName : activeSpecialty.name}
                </h3>

                <p className="text-slate-600 text-base leading-relaxed">
                  {activeSpecialty.fullDesc}
                </p>
              </div>

              {/* Feature Points */}
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Key Capabilities & Infrastructure:
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {activeSpecialty.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-slate-50 border border-slate-100 text-slate-700 text-xs sm:text-sm">
                      <div className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                      <span className="font-medium">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* In-Charge & Direct Booking */}
              <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <span className="text-xs text-slate-400 block font-medium">Head Consultant / Team:</span>
                  <span className="text-sm font-bold text-slate-800">{activeSpecialty.headDoctor}</span>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={() => onSelectDepartment(activeSpecialty.id)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs sm:text-sm shadow-md transition"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>Book For This Dept</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Right Column: Visual Feature Grid */}
            <div className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-blue-950 text-white p-6 sm:p-10 flex flex-col justify-between space-y-6">
              
              <div>
                <div className="w-14 h-14 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center text-blue-300 mb-6 border border-white/10">
                  {getIcon(activeSpecialty.icon)}
                </div>

                <h4 className="text-xl font-black text-white mb-2">
                  Nova Shekhar Standards
                </h4>
                <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-6">
                  Equipped to handle both routine outpatients and high-acuity surgical admissions under strict clinical hygiene protocols.
                </p>

                <div className="space-y-3">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                    <span className="text-slate-300">Sterilization Standard</span>
                    <span className="font-bold text-emerald-400">Class 100 HEPA Filtered</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                    <span className="text-slate-300">OPD Consultation Timing</span>
                    <span className="font-bold text-amber-300">9:00 AM – 5:00 PM</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                    <span className="text-slate-300">Emergency & Trauma OT</span>
                    <span className="font-bold text-rose-400">Ready 24x7</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                    <span className="text-slate-300">Google Patient Rating</span>
                    <span className="font-bold text-amber-300">5.0 ★ Top Rated</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-slate-400">MGIMT Campus, Banthara</span>
                <a
                  href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                  className="text-xs text-emerald-400 hover:underline font-bold flex items-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call {HOSPITAL_INFO.phone}</span>
                </a>
              </div>

            </div>

          </div>
        </div>

        {/* 6 Quick Highlights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
          
          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center font-bold">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-lg">24/7 Emergency & ICU</h4>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Immediate stabilization for road accident trauma on Kanpur Road (NH-25), acute cardiac failure, stroke, and poisoning with in-house ventilator support.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center font-bold">
              <Eye className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-lg">Nova Eye Hospital</h4>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Specialized ophthalmology branch featuring sutureless Phacoemulsification cataract surgery, computerized vision testing, and comprehensive glaucoma care.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
              <Droplets className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-slate-900 text-lg">Hemodialysis & Kidney Care</h4>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Modern hemodialysis unit saving rural patients from travelling 25 km into Lucknow city. High-grade medical RO water and isolated viral care stations.
            </p>
          </div>

        </div>

      </div>
    </section>
  );
};
