import React from 'react';
import { Zap, MapPin, Smartphone, ShieldAlert, HeartHandshake, CheckCircle } from 'lucide-react';

export const WhyUs: React.FC = () => {
  const features = [
    {
      title: 'Ultra-Fast Access',
      desc: 'Engineered for high stress scenarios — get verified hospital, ICU and ambulance numbers with zero clutter.',
      icon: Zap,
      color: '#00e5ff',
    },
    {
      title: 'GPS Proximity Sorting',
      desc: 'Automatic radius calculation prioritizes the nearest available emergency services to minimize travel time.',
      icon: MapPin,
      color: '#ff3150',
    },
    {
      title: 'Mobile-First Design',
      desc: 'Optimized touch targets, 1-tap calling, and rapid loading even on low-speed 3G/4G network corridors.',
      icon: Smartphone,
      color: '#00ff9d',
    },
    {
      title: 'Emergency Focused',
      desc: 'Built specifically around real emergencies with built-in siren alarms, blood donor networks and live CPR guides.',
      icon: ShieldAlert,
      color: '#ffd166',
    },
    {
      title: 'Community Blood Network',
      desc: 'Direct connection between voluntary donors and critical patient attendants without middleman delays.',
      icon: HeartHandshake,
      color: '#ff4d67',
    },
    {
      title: '100% Verified Centers',
      desc: 'Hospitals and diagnostic facilities are pre-screened for genuine emergency response and round-the-clock staffing.',
      icon: CheckCircle,
      color: '#38bdf8',
    },
  ];

  return (
    <section id="about" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#040b12]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-widest text-[#00e5ff] inline-block mb-2">
            WHY FAST MEDCAB
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
            One Platform. Every Emergency.
          </h2>
          <p className="text-sm sm:text-base text-[#9db3be] mt-3">
            FAST MEDCAB brings vital healthcare infrastructure into a single unified dashboard, saving critical golden-hour minutes.
          </p>
        </div>

        {/* Features Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-white/20 transition-all flex items-start gap-4 group"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-110"
                  style={{
                    backgroundColor: `${feat.color}15`,
                    color: feat.color,
                    border: `1px solid ${feat.color}35`,
                  }}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white mb-1 group-hover:text-[#00e5ff] transition-colors">
                    {feat.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#9bb0bc] leading-relaxed">
                    {feat.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
