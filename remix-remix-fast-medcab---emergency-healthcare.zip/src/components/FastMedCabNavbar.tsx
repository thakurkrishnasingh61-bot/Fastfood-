import React, { useState } from 'react';
import { 
  Phone, 
  MapPin, 
  Menu, 
  X, 
  Ambulance, 
  ShieldAlert, 
  Globe, 
  Droplet, 
  Hospital, 
  UserRoundCheck, 
  Pill, 
  FlaskConical, 
  Map, 
  Radio, 
  HeartHandshake,
  User,
  LogIn
} from 'lucide-react';
import { ServiceCategory } from '../types';
import { useAuth } from '../context/AuthContext';

interface FastMedCabNavbarProps {
  activeCategory: ServiceCategory;
  onSelectCategory: (cat: ServiceCategory) => void;
  onOpenSos: () => void;
  onOpenAmbulanceDispatch: () => void;
  onOpenBloodRequest: () => void;
  onOpenAyushman: () => void;
  onOpenAuth: () => void;
  onToggleMapView: () => void;
  isMapView: boolean;
  isHindi: boolean;
  setIsHindi: React.Dispatch<React.SetStateAction<boolean>>;
}

export const FastMedCabNavbar: React.FC<FastMedCabNavbarProps> = ({
  activeCategory,
  onSelectCategory,
  onOpenSos,
  onOpenAmbulanceDispatch,
  onOpenBloodRequest,
  onOpenAyushman,
  onOpenAuth,
  onToggleMapView,
  isMapView,
  isHindi,
  setIsHindi,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, profile } = useAuth();

  const categories: { id: ServiceCategory; label: string; hindiLabel: string; icon: any }[] = [
    { id: 'hospital', label: 'Hospitals', hindiLabel: 'अस्पताल व आईसीयू', icon: Hospital },
    { id: 'ambulance', label: 'Ambulance', hindiLabel: 'एम्बुलेंस', icon: Ambulance },
    { id: 'blood', label: 'Blood Bank', hindiLabel: 'रक्तदान / ब्लड बैंक', icon: Droplet },
    { id: 'doctor', label: 'Doctors', hindiLabel: 'आपातकालीन डॉक्टर', icon: UserRoundCheck },
    { id: 'pharmacy', label: '24/7 Pharmacy', hindiLabel: 'रात की दवा दुकान', icon: Pill },
    { id: 'lab', label: 'Diagnostic Labs', hindiLabel: 'जांच प्रयोगशालाएं', icon: FlaskConical },
  ];

  return (
    <header className="sticky top-0 z-50 w-full shadow-lg">
      {/* Top Emergency Strip */}
      <div className="bg-[#03090e] text-slate-200 text-xs py-2 px-4 border-b border-red-900/40">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2 sm:gap-4">
          
          <div className="flex items-center gap-3 sm:gap-6 flex-wrap">
            <div className="flex items-center gap-2 text-rose-400 font-bold">
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600"></span>
              </span>
              <span className="tracking-wide">
                {isHindi ? '24/7 राष्ट्रीय आपातकालीन नेटवर्क' : '24/7 NATIONAL EMERGENCY NETWORK'}
              </span>
            </div>

            <div className="hidden md:flex items-center gap-4 text-slate-300">
              <a href="tel:112" className="hover:text-cyan-400 transition flex items-center gap-1 font-semibold">
                <Radio className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                <span>Police / Rescue: <strong className="text-white">112</strong></span>
              </a>
              <span className="text-slate-700">|</span>
              <a href="tel:108" className="hover:text-cyan-400 transition flex items-center gap-1 font-semibold">
                <Ambulance className="w-3.5 h-3.5 text-amber-400" />
                <span>Govt Ambulance: <strong className="text-white">108</strong></span>
              </a>
              <span className="text-slate-700">|</span>
              <a href="tel:102" className="hover:text-cyan-400 transition hidden lg:inline flex items-center gap-1">
                <span>Maternal / Neonatal: <strong className="text-white">102</strong></span>
              </a>
            </div>
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <button
              onClick={onOpenAyushman}
              className="text-[11px] font-semibold text-amber-300 hover:text-amber-200 px-2.5 py-1 rounded-md bg-amber-950/50 border border-amber-500/30 transition hidden sm:inline-flex items-center gap-1"
            >
              <span>{isHindi ? 'आयुष्मान (PM-JAY) कैशलेस' : 'Ayushman PM-JAY Free'}</span>
            </button>

            {/* Language toggle */}
            <button
              onClick={() => setIsHindi(!isHindi)}
              className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition"
              title="Change Language / भाषा बदलें"
            >
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isHindi ? 'English' : 'हिंदी'}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Main Navbar */}
      <nav className="bg-[#07131d] border-b border-cyan-500/20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Logo Branding */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-600 via-rose-600 to-cyan-600 flex items-center justify-center text-white shadow-[0_0_25px_rgba(255,49,80,0.5)] p-0.5 relative group">
              <div className="w-full h-full bg-[#061421] rounded-[14px] flex items-center justify-center">
                <Ambulance className="w-6 h-6 text-rose-500 group-hover:scale-110 transition-transform" />
              </div>
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-rose-500 rounded-full border-2 border-[#07131d] animate-ping" />
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl sm:text-2xl font-black tracking-tight text-white font-sans">
                  FAST
                </span>
                <span className="text-xl sm:text-2xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-rose-400">
                  MEDCAB
                </span>
              </div>
              <p className="text-[10px] sm:text-xs text-cyan-300/80 font-medium tracking-wide">
                {isHindi ? '24/7 आपातकालीन स्वास्थ्य सेवा एवं एम्बुलेंस नेटवर्क' : 'Emergency Healthcare & Rapid Dispatch'}
              </p>
            </div>
          </div>

          {/* Service Category Buttons (Desktop) */}
          <div className="hidden xl:flex items-center gap-1 bg-[#0a1b2a] p-1.5 rounded-2xl border border-white/10">
            {categories.map((cat) => {
              const Icon = cat.icon;
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{isHindi ? cat.hindiLabel : cat.label}</span>
                </button>
              );
            })}
          </div>

          {/* Action CTAs */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Map Toggle Button */}
            <button
              onClick={onToggleMapView}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                isMapView 
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 shadow-[0_0_15px_rgba(0,229,255,0.3)]'
                  : 'bg-white/5 text-slate-200 border-white/10 hover:bg-white/10'
              }`}
            >
              <Map className="w-3.5 h-3.5 text-cyan-400" />
              <span>{isMapView ? (isHindi ? 'सूची' : 'List') : (isHindi ? 'नक्शा' : 'Map')}</span>
            </button>

            {/* Book Ambulance Button */}
            <button
              onClick={onOpenAmbulanceDispatch}
              className="px-3.5 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 shadow-md transition flex items-center gap-1.5"
            >
              <Ambulance className="w-4 h-4" />
              <span>{isHindi ? 'एम्बुलेंस' : 'Ambulance'}</span>
            </button>

            {/* SOS Emergency Button */}
            <button
              onClick={onOpenSos}
              className="px-3.5 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 hover:from-rose-500 hover:to-red-500 text-white shadow-[0_0_20px_rgba(255,49,80,0.6)] transition flex items-center gap-1.5 animate-pulse"
            >
              <ShieldAlert className="w-4 h-4" />
              <span>SOS</span>
            </button>

            {/* Google Login / Profile Button */}
            <button
              onClick={onOpenAuth}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 border transition ${
                user
                  ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-200 hover:bg-cyan-900/60'
                  : 'bg-white text-slate-900 hover:bg-slate-100 border-white shadow-md shadow-black/30'
              }`}
              title={user ? (user.displayName || user.email || 'Profile') : 'Google Login'}
            >
              {user ? (
                <>
                  {user.photoURL ? (
                    <img 
                      src={user.photoURL} 
                      alt={user.displayName || 'User'} 
                      className="w-5 h-5 rounded-full object-cover border border-cyan-400" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-5 h-5 rounded-full bg-cyan-500/30 text-cyan-300 text-[10px] flex items-center justify-center font-bold">
                      {user.displayName?.charAt(0) || 'U'}
                    </div>
                  )}
                  <span className="max-w-[85px] truncate text-[11px]">
                    {user.displayName?.split(' ')[0] || (isHindi ? 'प्रोफ़ाइल' : 'Account')}
                  </span>
                </>
              ) : (
                <>
                  {/* Google 'G' icon */}
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.27 21.36 7.35 24 12 24z"/>
                    <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.97 0 12s.46 3.84 1.26 5.42l4.02-3.15z"/>
                    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                  </svg>
                  <span>{isHindi ? 'लॉगिन' : 'Login'}</span>
                </>
              )}
            </button>
          </div>

          {/* Mobile Header Buttons */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={onOpenAuth}
              className="p-1.5 rounded-xl border border-white/20 bg-white/5 text-white flex items-center justify-center"
              title={user ? 'User Profile' : 'Login'}
            >
              {user && user.photoURL ? (
                <img 
                  src={user.photoURL} 
                  alt="Avatar" 
                  className="w-6 h-6 rounded-full border border-cyan-400 object-cover" 
                  referrerPolicy="no-referrer"
                />
              ) : (
                <User className="w-4 h-4 text-cyan-300" />
              )}
            </button>

            <button
              onClick={onOpenSos}
              className="px-2.5 py-1.5 rounded-xl text-xs font-black bg-rose-600 text-white flex items-center gap-1 animate-pulse shadow-md"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>SOS</span>
            </button>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-800 text-white hover:bg-slate-700 transition"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden bg-[#050f17] border-t border-slate-800 px-4 py-5 space-y-4 shadow-2xl">
            <div className="grid grid-cols-2 gap-2">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isActive = activeCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => {
                      onSelectCategory(cat.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-2 p-3 rounded-xl text-xs font-bold text-left transition ${
                      isActive
                        ? 'bg-cyan-500 text-slate-950'
                        : 'bg-white/5 text-slate-300 hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="truncate">{isHindi ? cat.hindiLabel : cat.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-slate-800 flex flex-col gap-2">
              <button
                onClick={() => {
                  onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-600 to-blue-600 text-white flex items-center justify-center gap-2 shadow-lg"
              >
                {user ? (
                  <>
                    <User className="w-4 h-4" />
                    <span>{user.displayName || user.email} ({isHindi ? 'प्रोफ़ाइल व लॉगआउट' : 'Profile & Logout'})</span>
                  </>
                ) : (
                  <>
                    {/* Google G icon */}
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path fill="#ffffff" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"/>
                      <path fill="#ffffff" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.27 21.36 7.35 24 12 24z"/>
                      <path fill="#ffffff" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.97 0 12s.46 3.84 1.26 5.42l4.02-3.15z"/>
                      <path fill="#ffffff" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
                    </svg>
                    <span>{isHindi ? 'Google से लॉगिन करें' : 'Sign in with Google'}</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  onToggleMapView();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl text-xs font-bold bg-cyan-950 text-cyan-300 border border-cyan-500/40 flex items-center justify-center gap-2"
              >
                <Map className="w-4 h-4" />
                <span>{isMapView ? 'Switch to List View' : 'Open Live Map View'}</span>
              </button>

              <button
                onClick={() => {
                  onOpenAmbulanceDispatch();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl text-xs font-bold bg-amber-500 text-slate-950 flex items-center justify-center gap-2"
              >
                <Ambulance className="w-4 h-4" />
                <span>{isHindi ? 'एम्बुलेंस बुलाएं (108 / प्राइवेट)' : 'Book Ambulance (108 / Private)'}</span>
              </button>

              <button
                onClick={() => {
                  onOpenBloodRequest();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl text-xs font-bold bg-rose-950 text-rose-300 border border-rose-800 flex items-center justify-center gap-2"
              >
                <Droplet className="w-4 h-4" />
                <span>{isHindi ? 'रक्त अनुरोध / ब्लड बैंक' : 'Request Blood / Donors'}</span>
              </button>

              <button
                onClick={() => {
                  onOpenAyushman();
                  setMobileMenuOpen(false);
                }}
                className="w-full py-2.5 rounded-xl text-xs font-semibold bg-white/5 text-amber-300 flex items-center justify-center gap-1.5"
              >
                <HeartHandshake className="w-4 h-4" />
                <span>Ayushman PM-JAY Cashless Helpdesk</span>
              </button>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};
