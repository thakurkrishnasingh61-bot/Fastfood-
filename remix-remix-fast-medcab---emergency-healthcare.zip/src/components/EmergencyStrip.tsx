import React from 'react';
import { Ambulance, ShieldAlert, HeartPulse, Clock } from 'lucide-react';
import { HOSPITAL_INFO } from '../data/hospitalData';

interface EmergencyStripProps {
  onOpenAppointment: () => void;
  onOpenAmbulance: () => void;
  onOpenAyushman: () => void;
  isHindi: boolean;
}

export const EmergencyStrip: React.FC<EmergencyStripProps> = ({
  onOpenAppointment,
  onOpenAmbulance,
  onOpenAyushman,
  isHindi
}) => {
  return (
    <div className="bg-slate-900 border-y border-slate-800 text-white shadow-xl relative z-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-center">
          
          {/* Quick Item 1: 24/7 Emergency */}
          <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="w-10 h-10 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center shrink-0 border border-red-500/30">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <span>{isHindi ? 'आपातकालीन कैजुअल्टी' : '24x7 Casualty & Trauma'}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              </div>
              <a 
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`} 
                className="font-bold text-sm text-white hover:text-red-400 transition truncate block"
              >
                {HOSPITAL_INFO.phone}
              </a>
            </div>
          </div>

          {/* Quick Item 2: ICU & Ventilator */}
          <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="w-10 h-10 rounded-lg bg-rose-600/20 text-rose-400 flex items-center justify-center shrink-0 border border-rose-500/30">
              <HeartPulse className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs text-slate-400">
                {isHindi ? 'आईसीयू एवं वेंटिलेटर' : 'ICU & Ventilators'}
              </div>
              <div className="font-bold text-sm text-slate-100 flex items-center gap-1">
                <span>Active 24/7 Support</span>
              </div>
            </div>
          </div>

          {/* Quick Item 3: OPD Timings */}
          <div className="flex items-center gap-3.5 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
            <div className="w-10 h-10 rounded-lg bg-amber-600/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/30">
              <Clock className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs text-slate-400">
                {isHindi ? 'ओपीडी परामर्श समय' : 'OPD Timings'}
              </div>
              <div className="font-bold text-sm text-amber-300">
                Open · Closes 5:00 PM
              </div>
            </div>
          </div>

          {/* Quick Item 4: Ambulance on NH-25 */}
          <div className="flex items-center gap-3">
            <button
              onClick={onOpenAmbulance}
              className="flex-1 py-3 px-3.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-red-600/20 transition"
            >
              <Ambulance className="w-4 h-4 animate-bounce" />
              <span>{isHindi ? 'एम्बुलेंस बुलाएं' : 'Request Ambulance'}</span>
            </button>

            <button
              onClick={onOpenAppointment}
              className="flex-1 py-3 px-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition"
            >
              <span>{isHindi ? 'अपॉइंटमेंट' : 'Book OPD'}</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
