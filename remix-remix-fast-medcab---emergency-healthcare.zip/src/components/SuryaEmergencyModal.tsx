import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  PhoneCall, 
  MapPin, 
  CheckCircle2, 
  AlertTriangle, 
  HeartPulse, 
  Wind,
  Truck
} from 'lucide-react';
import { SURYA_HOSPITAL } from '../data/suryaHospitalData';

interface SuryaEmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHindi: boolean;
}

export const SuryaEmergencyModal: React.FC<SuryaEmergencyModalProps> = ({
  isOpen,
  onClose,
  isHindi
}) => {
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [needsOxygen, setNeedsOxygen] = useState(true);
  const [needsVentilator, setNeedsVentilator] = useState(false);
  const [dispatched, setDispatched] = useState(false);

  if (!isOpen) return null;

  const handleDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone) return;
    setDispatched(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border-2 border-rose-500 overflow-hidden relative animate-in fade-in zoom-in-95">
        
        {/* Red Emergency Strip */}
        <div className="bg-rose-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldAlert className="w-6 h-6 animate-pulse text-white" />
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest bg-rose-700 px-2 py-0.5 rounded">
                Surya Hospital 24/7 Trauma & ICU
              </span>
              <h3 className="text-lg font-black mt-0.5">
                {isHindi ? "आपातकालीन सहायता एवं एम्बुलेंस" : "24/7 Emergency & ICU Ambulance"}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-rose-700 text-white transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {dispatched ? (
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                <Truck className="w-8 h-8 animate-bounce" />
              </div>
              <h4 className="text-xl font-black text-slate-900">
                {isHindi ? "एम्बुलेंस डिस्पैच अनुरोध दर्ज!" : "Emergency Ambulance Dispatched!"}
              </h4>
              <p className="text-xs sm:text-sm text-slate-600">
                Surya ALS Ambulance is rolling towards your location. Our casualty control room is calling your number <strong>+91 {phone}</strong> immediately.
              </p>
              <div className="bg-slate-50 p-4 rounded-xl text-xs text-left border border-slate-200">
                <p><strong>ETA:</strong> 8 to 14 Minutes</p>
                <p><strong>Support:</strong> ALS Paramedic onboard with {needsVentilator ? 'Ventilator &' : ''} {needsOxygen ? 'High-Flow Oxygen' : ''}</p>
                <p><strong>Hospital Casualty Code:</strong> SURYA-ICU-STAT</p>
              </div>
              <button
                onClick={onClose}
                className="w-full bg-slate-900 text-white font-bold py-3 rounded-xl text-sm"
              >
                Close Window
              </button>
            </div>
          ) : (
            <div className="space-y-5 text-xs sm:text-sm">
              
              {/* Immediate Direct Dial Button */}
              <a
                href={`tel:${SURYA_HOSPITAL.emergencyPhone.replace(/\s+/g, '')}`}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-black py-3.5 px-4 rounded-2xl flex items-center justify-center gap-3 shadow-lg shadow-rose-600/30 transition text-sm sm:text-base text-center"
              >
                <PhoneCall className="w-5 h-5 animate-pulse" />
                <span>TAP TO CALL EMERGENCY: {SURYA_HOSPITAL.emergencyPhone}</span>
              </a>

              <div className="relative text-center">
                <span className="bg-white px-3 text-slate-400 font-bold text-[11px] uppercase tracking-wider relative z-10">
                  Or Request Instant Ambulance Dispatch
                </span>
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
              </div>

              <form onSubmit={handleDispatch} className="space-y-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "संपर्क नंबर *" : "Contact Mobile Number *"}
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="Enter 10-digit mobile number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs sm:text-sm"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {isHindi ? "मरीज का पता / लोकेशन *" : "Patient Address / Landmark *"}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="House/Building, Street, Landmark, Area"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs sm:text-sm"
                  />
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                  <span className="block font-bold text-slate-800 text-xs uppercase tracking-wider">
                    Equipment Needed on Ambulance:
                  </span>
                  <div className="flex items-center gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={needsOxygen}
                        onChange={(e) => setNeedsOxygen(e.target.checked)}
                        className="rounded text-rose-600 focus:ring-rose-500"
                      />
                      <span className="text-xs text-slate-700 font-medium">Oxygen Cylinder</span>
                    </label>

                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={needsVentilator}
                        onChange={(e) => setNeedsVentilator(e.target.checked)}
                        className="rounded text-rose-600 focus:ring-rose-500"
                      />
                      <span className="text-xs text-slate-700 font-medium">Transport Ventilator</span>
                    </label>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-xs sm:text-sm transition flex items-center justify-center gap-2"
                >
                  <Truck className="w-4 h-4 text-rose-400" />
                  <span>Request Immediate GPS Ambulance</span>
                </button>
              </form>

              <div className="text-[11px] text-slate-500 flex items-center justify-center gap-1.5 pt-1">
                <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
                <span>Zero admission waiting time for trauma and acute pulmonary distress.</span>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
