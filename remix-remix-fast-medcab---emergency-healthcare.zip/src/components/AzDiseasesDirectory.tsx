import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Biohazard, 
  Activity, 
  Filter, 
  ChevronRight, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  Stethoscope, 
  Calendar, 
  X,
  Sparkles,
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { AZ_DISEASES } from '../data/azDiseasesData';
import { DiseaseSummary, DiseaseCategory } from '../types';

interface AzDiseasesDirectoryProps {
  onSelectArticle: (articleId: string) => void;
  onOpenAppointment: (dept?: string, doctor?: string) => void;
  isHindi: boolean;
  initialSearchQuery?: string;
}

export const AzDiseasesDirectory: React.FC<AzDiseasesDirectoryProps> = ({
  onSelectArticle,
  onOpenAppointment,
  isHindi,
  initialSearchQuery = ''
}) => {
  const [searchQuery, setSearchQuery] = useState(initialSearchQuery);
  const [selectedLetter, setSelectedLetter] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<DiseaseCategory>('All');
  const [selectedDiseaseModal, setSelectedDiseaseModal] = useState<DiseaseSummary | null>(null);

  const alphabet = ['All', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U'];
  
  const categories: DiseaseCategory[] = [
    'All',
    'Viral & Infectious',
    'Respiratory',
    'Zoonotic & Vector-Borne',
    'Cardiovascular & Renal',
    'Metabolic & Lifestyle'
  ];

  // Filter logic
  const filteredDiseases = useMemo(() => {
    return AZ_DISEASES.filter((disease) => {
      // Letter filter
      if (selectedLetter !== 'All' && !disease.name.toUpperCase().startsWith(selectedLetter)) {
        return false;
      }
      // Category filter
      if (selectedCategory !== 'All' && disease.category !== selectedCategory) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchName = disease.name.toLowerCase().includes(q);
        const matchHindi = disease.hindiName.toLowerCase().includes(q);
        const matchScientific = disease.scientificName?.toLowerCase().includes(q) || false;
        const matchDesc = disease.shortDesc.toLowerCase().includes(q);
        const matchSym = disease.commonSymptoms.some(s => s.toLowerCase().includes(q));
        if (!matchName && !matchHindi && !matchScientific && !matchDesc && !matchSym) {
          return false;
        }
      }
      return true;
    });
  }, [searchQuery, selectedLetter, selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Directory Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950 text-white rounded-3xl p-6 sm:p-10 shadow-lg mb-8 relative overflow-hidden">
        <div className="max-w-3xl relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 mb-4">
            <Biohazard className="w-3.5 h-3.5 text-amber-400" />
            <span>{isHindi ? "सूर्य हॉस्पिटल मेडिकल एनसाइक्लोपीडिया" : "Surya Hospital Medical Knowledge Center"}</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight mb-3">
            {isHindi ? "A-Z रोग डायरेक्टरी एवं लक्षण गाइड" : "A-Z Diseases Encyclopedia & Clinical Guides"}
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            {isHindi
              ? "विभिन्न वायरल, संक्रामक, जूनोटिक और श्वसन रोगों के लक्षण, कारण, उपचार और रोकथाम के विशेषज्ञ-सत्यापित मेडिकल गाइड ब्राउज़ करें।"
              : "Explore medically reviewed disease profiles, symptoms, transmission modes, laboratory diagnostics, and evidence-based prevention protocols curated by Surya Hospital specialists."}
          </p>

          {/* Search Bar inside Hero */}
          <div className="relative max-w-xl">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isHindi ? "रोग, रोगाणु या लक्षण खोजें (उदा: हंतावायरस, डेंगू, दमा)..." : "Search disease, pathogen, or symptoms (e.g., Hantavirus, Dengue, Asthma)..."}
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:bg-white/20 text-sm sm:text-base transition"
            />
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Alphabet Filter Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm mb-6">
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-amber-600" />
            <span>{isHindi ? "वर्णमाला के अनुसार फ़िल्टर करें" : "Filter by Alphabetical Index"}</span>
          </span>
          <span className="text-xs font-semibold text-slate-600">
            {filteredDiseases.length} {isHindi ? "रोग उपलब्ध" : "Conditions Listed"}
          </span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          {alphabet.map((letter) => (
            <button
              key={letter}
              onClick={() => setSelectedLetter(letter)}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-lg text-xs font-bold transition flex items-center justify-center ${
                selectedLetter === letter
                  ? 'bg-amber-500 text-white shadow-sm'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {letter}
            </button>
          ))}
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition border ${
              selectedCategory === cat
                ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:border-slate-300'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Disease Cards Grid */}
      {filteredDiseases.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-slate-200 p-8">
          <Activity className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-slate-800 mb-1">
            {isHindi ? "कोई परिणाम नहीं मिला" : "No Diseases Found"}
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            {isHindi ? "कृपया कोई अन्य खोज शब्द या फ़िल्टर आज़माएं।" : "Try adjusting your search keywords or resetting alphabetical filters."}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedLetter('All');
              setSelectedCategory('All');
            }}
            className="px-4 py-2 rounded-lg bg-amber-500 text-white text-xs font-bold hover:bg-amber-600 transition"
          >
            {isHindi ? "फ़िल्टर रीसेट करें" : "Reset Filters"}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDiseases.map((disease) => {
            const isFeatured = disease.isFeatured || disease.id === 'hantavirus';
            return (
              <div
                key={disease.id}
                className={`bg-white rounded-2xl border transition-all flex flex-col justify-between overflow-hidden relative group hover:shadow-md ${
                  isFeatured 
                    ? 'border-amber-400/90 ring-2 ring-amber-400/20' 
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {isFeatured && (
                  <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white text-[11px] font-extrabold uppercase tracking-wider py-1 px-3 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      Featured In-Depth Guide
                    </span>
                    <span className="text-[10px] bg-white/20 px-1.5 rounded">Full Article</span>
                  </div>
                )}

                <div className="p-5 sm:p-6 flex-1 flex flex-col">
                  {/* Category & Severity */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-full">
                      {disease.category}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      disease.severity === 'Critical / Life-Threatening'
                        ? 'bg-rose-100 text-rose-800'
                        : disease.severity === 'Moderate to Severe'
                        ? 'bg-orange-100 text-orange-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {disease.severity}
                    </span>
                  </div>

                  {/* Disease Title */}
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-amber-600 transition mb-1">
                    {isHindi ? disease.hindiName : disease.name}
                  </h3>
                  {disease.scientificName && (
                    <p className="text-xs text-slate-500 italic mb-2">
                      {disease.scientificName}
                    </p>
                  )}

                  {/* Short Description */}
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4 flex-1">
                    {isHindi && disease.hindiShortDesc ? disease.hindiShortDesc : disease.shortDesc}
                  </p>

                  {/* Key Common Symptoms Preview */}
                  <div className="mb-4">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block mb-1.5">
                      Key Clinical Manifestations:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {disease.commonSymptoms.slice(0, 3).map((sym, idx) => (
                        <span key={idx} className="text-[11px] bg-amber-50 text-amber-900 border border-amber-200/60 px-2 py-0.5 rounded-md font-medium">
                          {sym}
                        </span>
                      ))}
                      {disease.commonSymptoms.length > 3 && (
                        <span className="text-[10px] text-slate-500 font-semibold self-center">
                          +{disease.commonSymptoms.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Incubation & Dept */}
                  <div className="pt-3 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{disease.incubation}</span>
                    </span>
                    <span className="font-semibold text-slate-700 text-[11px]">
                      {disease.hospitalDepartment.split('&')[0]}
                    </span>
                  </div>
                </div>

                {/* Bottom Action Footer */}
                <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center gap-2">
                  {disease.id === 'hantavirus' ? (
                    <button
                      onClick={() => onSelectArticle('hantavirus')}
                      className="w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow-sm"
                    >
                      <BookOpen className="w-4 h-4" />
                      <span>{isHindi ? "संपूर्ण हंतावायरस गाइड पढ़ें" : "Read Full Comprehensive Guide"}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => setSelectedDiseaseModal(disease)}
                        className="flex-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 font-bold py-2 px-3 rounded-xl text-xs flex items-center justify-center gap-1 transition"
                      >
                        <span>{isHindi ? "विवरण देखें" : "Clinical Details"}</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onOpenAppointment(disease.hospitalDepartment)}
                        className="bg-amber-600 hover:bg-amber-700 text-white font-semibold py-2 px-3 rounded-xl text-xs flex items-center justify-center transition"
                        title="Book Doctor"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Disease Detail Modal */}
      {selectedDiseaseModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 sm:p-8 relative">
            <button
              onClick={() => setSelectedDiseaseModal(null)}
              className="absolute top-5 right-5 p-2 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-800 transition"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-bold bg-amber-100 text-amber-900 px-2.5 py-0.5 rounded-full">
                {selectedDiseaseModal.category}
              </span>
              <span className="text-xs font-bold bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-full">
                {selectedDiseaseModal.severity}
              </span>
            </div>

            <h2 className="text-2xl font-extrabold text-slate-900 mb-1">
              {isHindi ? selectedDiseaseModal.hindiName : selectedDiseaseModal.name}
            </h2>
            {selectedDiseaseModal.scientificName && (
              <p className="text-xs text-slate-500 italic mb-4">
                Pathogen: {selectedDiseaseModal.scientificName}
              </p>
            )}

            <p className="text-sm text-slate-700 leading-relaxed mb-6">
              {selectedDiseaseModal.shortDesc}
            </p>

            <div className="space-y-4 text-xs sm:text-sm mb-6">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="font-bold text-slate-900 mb-1 flex items-center gap-1.5">
                  <Biohazard className="w-4 h-4 text-amber-600" />
                  <span>Mode of Transmission & Incubation</span>
                </h4>
                <p className="text-slate-600 mb-1">{selectedDiseaseModal.transmission}</p>
                <p className="text-slate-500 font-medium">Typical Incubation Period: {selectedDiseaseModal.incubation}</p>
              </div>

              <div className="bg-amber-50/60 p-4 rounded-xl border border-amber-200">
                <h4 className="font-bold text-amber-900 mb-2 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>Primary Symptoms & Warning Signs</span>
                </h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {selectedDiseaseModal.commonSymptoms.map((sym, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-slate-800">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                      <span>{sym}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="bg-emerald-50/60 p-4 rounded-xl border border-emerald-200">
                <h4 className="font-bold text-emerald-900 mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Prevention & Protective Guidelines</span>
                </h4>
                <ul className="space-y-1.5">
                  {selectedDiseaseModal.keyPrevention.map((prev, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-slate-700">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 flex-shrink-0"></span>
                      <span>{prev}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 pt-4 border-t border-slate-100">
              <button
                onClick={() => {
                  const dept = selectedDiseaseModal.hospitalDepartment;
                  setSelectedDiseaseModal(null);
                  onOpenAppointment(dept);
                }}
                className="w-full sm:flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition shadow-sm"
              >
                <Stethoscope className="w-4 h-4" />
                <span>Book Specialist at Surya Hospital</span>
              </button>

              <button
                onClick={() => setSelectedDiseaseModal(null)}
                className="w-full sm:w-auto px-5 py-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-sm transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
