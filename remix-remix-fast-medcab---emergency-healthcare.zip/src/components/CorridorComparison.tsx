import React from 'react';
import { 
  Check, 
  Star, 
  Award, 
  Sparkles, 
  HeartPulse,
  Droplets,
  Eye,
  Activity
} from 'lucide-react';
import { NEARBY_SEARCHED_HOSPITALS, HOSPITAL_INFO } from '../data/hospitalData';

interface CorridorComparisonProps {
  onOpenAppointment: () => void;
  isHindi: boolean;
}

export const CorridorComparison: React.FC<CorridorComparisonProps> = ({
  onOpenAppointment,
  isHindi
}) => {
  return (
    <section className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-100 border border-blue-200 text-blue-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Kanpur Road Healthcare Corridor</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {isHindi ? "कानपुर रोड व बंथरा क्षेत्र में नोवा शेखर क्यों है सर्वश्रेष्ठ?" : "Why Nova Shekhar Hospital is Rated 5.0 Stars"}
          </h2>
          <p className="text-slate-600 mt-2 text-base">
            {isHindi 
              ? "बंथरा एवं खांडेदेव क्षेत्र में आईसीयू वेंटिलेटर, किडनी डायलिसिस, फेको आई सर्जरी एवं 24 घंटे आपातकालीन कैजुअल्टी की संपूर्ण इन-हाउस सुविधा।"
              : "Compare healthcare facilities on Kanpur Road (NH-25). Nova Shekhar Hospital is the sole center combining 24/7 ICU, dedicated Eye Hospital, Hemodialysis, and Modular OT on one campus."
            }
          </p>
        </div>

        {/* Comparison Table / Card Matrix */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden mb-10">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[640px]">
              <thead>
                <tr className="bg-slate-900 text-white text-xs uppercase tracking-wider">
                  <th className="p-4 sm:p-5 font-bold">Facility / Hospital</th>
                  <th className="p-4 sm:p-5 font-bold">Google Rating</th>
                  <th className="p-4 sm:p-5 font-bold">24/7 ICU & Ventilator</th>
                  <th className="p-4 sm:p-5 font-bold">Eye Surgery (Phaco)</th>
                  <th className="p-4 sm:p-5 font-bold">Hemodialysis Unit</th>
                  <th className="p-4 sm:p-5 font-bold">Maternity & OT</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                
                {/* Nova Shekhar Hospital (Featured Row) */}
                <tr className="bg-blue-50/70 font-semibold text-slate-900 border-b-2 border-blue-300">
                  <td className="p-4 sm:p-5">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                      <div>
                        <span className="font-extrabold text-blue-900 text-base">NOVA SHEKHAR HOSPITAL</span>
                        <div className="text-[11px] text-blue-700 font-normal">MGIMT Campus, NH-25 Banthara</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5">
                    <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 font-black text-xs">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
                      <span>5.04 ★</span>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>In-House (24x7)</span>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Nova Eye Wing</span>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Dedicated RO Unit</span>
                    </div>
                  </td>
                  <td className="p-4 sm:p-5">
                    <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
                      <Check className="w-4 h-4 stroke-[3]" />
                      <span>Modular OT Active</span>
                    </div>
                  </td>
                </tr>

                {/* Lovee Shubh Hospital */}
                <tr className="hover:bg-slate-50 text-slate-600">
                  <td className="p-4 sm:p-5">
                    <span className="font-bold text-slate-800">Lovee Shubh Hospital</span>
                    <div className="text-[11px] text-slate-400">Nearby Kanpur Road Clinic</div>
                  </td>
                  <td className="p-4 sm:p-5">4.2 ★</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Basic ICU / Referral</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Limited</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Not Available</td>
                  <td className="p-4 sm:p-5 text-xs text-slate-600">General OPD</td>
                </tr>

                {/* R R dental and multi speciality hospital */}
                <tr className="hover:bg-slate-50 text-slate-600">
                  <td className="p-4 sm:p-5">
                    <span className="font-bold text-slate-800">R R dental & multi speciality</span>
                    <div className="text-[11px] text-slate-400">Dental & OPD Focus</div>
                  </td>
                  <td className="p-4 sm:p-5">4.4 ★</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Not Available</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Not Available</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Not Available</td>
                  <td className="p-4 sm:p-5 text-xs text-slate-600">Dental & Minor OT</td>
                </tr>

                {/* New Max Hospital */}
                <tr className="hover:bg-slate-50 text-slate-600">
                  <td className="p-4 sm:p-5">
                    <span className="font-bold text-slate-800">New Max Hospital</span>
                    <div className="text-[11px] text-slate-400">Private Community Centre</div>
                  </td>
                  <td className="p-4 sm:p-5">4.1 ★</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Basic Beds</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Visiting Doctor</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">External</td>
                  <td className="p-4 sm:p-5 text-xs text-slate-600">General Surgery</td>
                </tr>

                {/* Shine MultiSpeciality Hospital */}
                <tr className="hover:bg-slate-50 text-slate-600">
                  <td className="p-4 sm:p-5">
                    <span className="font-bold text-slate-800">Shine MultiSpeciality Hospital</span>
                    <div className="text-[11px] text-slate-400">Highway Route Clinic</div>
                  </td>
                  <td className="p-4 sm:p-5">4.3 ★</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Limited Capacity</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Basic Eye OPD</td>
                  <td className="p-4 sm:p-5 text-slate-400 text-xs">Visiting</td>
                  <td className="p-4 sm:p-5 text-xs text-slate-600">Maternity Care</td>
                </tr>

              </tbody>
            </table>
          </div>

          <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
            <span className="flex items-center gap-1.5">
              <Award className="w-4 h-4 text-blue-600" />
              <span>Independent data compiled from Google Maps local searches on Banthara / Khandedev healthcare corridor.</span>
            </span>
            <button
              onClick={onOpenAppointment}
              className="px-4 py-2 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs transition"
            >
              Book OPD at Nova Shekhar
            </button>
          </div>
        </div>

        {/* Four Key Pillar Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <HeartPulse className="w-6 h-6 text-rose-600" />
            <h4 className="font-bold text-slate-900 text-sm">Critical ICU & Ventilators</h4>
            <p className="text-xs text-slate-500">
              Immediate multi-para monitoring and life-support ventilators without requiring ambulance transfer into congested city centers.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <Eye className="w-6 h-6 text-sky-600" />
            <h4 className="font-bold text-slate-900 text-sm">Nova Eye Wing</h4>
            <p className="text-xs text-slate-500">
              Dedicated ophthalmic surgical unit with stitchless cataract phaco technology and computerized eyesight testing.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <Droplets className="w-6 h-6 text-blue-600" />
            <h4 className="font-bold text-slate-900 text-sm">Dialysis on Campus</h4>
            <p className="text-xs text-slate-500">
              High-flux dialyzers with dedicated medical RO filtration for chronic kidney failure patients living near Banthara & Unnao.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2">
            <Activity className="w-6 h-6 text-emerald-600" />
            <h4 className="font-bold text-slate-900 text-sm">Modular OT & Maternity</h4>
            <p className="text-xs text-slate-500">
              Infection-free laminar airflow surgical theatres with C-Arm and 24/7 cesarean and normal delivery readiness.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
