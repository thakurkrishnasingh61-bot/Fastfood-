import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Navigation, 
  Hospital, 
  Ambulance, 
  Droplet, 
  UserRoundCheck, 
  Pill, 
  FlaskConical, 
  CheckCircle2,
  Phone,
  ShieldCheck,
  Building2,
  Stethoscope,
  X,
  Compass,
  Map,
  List,
  FileSpreadsheet,
  UploadCloud,
  Trash2,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { ServiceCategory, BloodGroup, HospitalTier, HospitalItem } from '../types';
import { INDIAN_STATES, NATIONAL_EMERGENCY_HELPLINES, POPULAR_INDIAN_CITIES } from '../data/indiaLocations';
import { parseHospitalExcel } from '../utils/excelHospitalParser';

interface QuickSearchProps {
  activeCategory: ServiceCategory;
  onSelectCategory: (category: ServiceCategory) => void;
  searchLocation: string;
  onLocationChange: (loc: string) => void;
  searchQuery: string;
  onQueryChange: (q: string) => void;
  selectedState: string;
  onStateChange: (state: string) => void;
  selectedTier: string;
  onTierChange: (tier: string) => void;
  ayushmanOnly: boolean;
  onToggleAyushman: () => void;
  selectedBloodGroup: BloodGroup | 'ALL';
  onBloodGroupChange: (bg: BloodGroup | 'ALL') => void;
  filter247: boolean;
  onToggle247: () => void;
  resultsCount: number;
  viewMode?: 'list' | 'map';
  onViewModeChange?: (mode: 'list' | 'map') => void;
  isHindi?: boolean;
  onImportHospitals?: (hospitals: HospitalItem[]) => void;
  customHospitalsCount?: number;
  onClearCustomHospitals?: () => void;
}

const CATEGORIES: { id: ServiceCategory; label: string; icon: any; color: string }[] = [
  { id: 'hospital', label: 'Hospitals', icon: Hospital, color: '#00e5ff' },
  { id: 'ambulance', label: 'Ambulance', icon: Ambulance, color: '#ff3150' },
  { id: 'blood', label: 'Blood Donors', icon: Droplet, color: '#ff4d67' },
  { id: 'doctor', label: 'Doctors', icon: UserRoundCheck, color: '#38bdf8' },
  { id: 'pharmacy', label: 'Pharmacy', icon: Pill, color: '#00ff9d' },
  { id: 'lab', label: 'Diagnostic Labs', icon: FlaskConical, color: '#ffd166' },
];

const BLOOD_GROUPS: (BloodGroup | 'ALL')[] = ['ALL', 'O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'];

const HOSPITAL_TIERS: { id: string; label: string }[] = [
  { id: 'ALL', label: 'All Hospital Tiers' },
  { id: 'AIIMS & Apex Central Institute', label: 'AIIMS & Apex Central' },
  { id: 'Govt Medical College', label: 'Govt Medical Colleges' },
  { id: 'District Hospital', label: 'District Civil Hospitals' },
  { id: 'CHC/PHC Community Center', label: 'CHC / PHC Rural & Small Town' },
  { id: 'Private Multi-Specialty', label: 'Private Multi-Specialty' },
];

const QUICK_CITIES = [
  'All India',
  'Hardoi',
  'Pali',
  'Pipraich',
  'Babhnan',
  'Kachhauna',
  'Lucknow',
  'Kanpur',
  'Gorakhpur',
  'Varanasi',
  'Sitapur',
  'Shahjahanpur',
  'Bareilly',
  'New Delhi',
  'Patna',
  'Mumbai',
  'Bengaluru',
  'Kolkata',
  'Jaipur',
  'Ayodhya',
  'Chandigarh'
];

export const QuickSearch: React.FC<QuickSearchProps> = ({
  activeCategory,
  onSelectCategory,
  searchLocation,
  onLocationChange,
  searchQuery,
  onQueryChange,
  selectedState,
  onStateChange,
  selectedTier,
  onTierChange,
  ayushmanOnly,
  onToggleAyushman,
  selectedBloodGroup,
  onBloodGroupChange,
  filter247,
  onToggle247,
  resultsCount,
  viewMode = 'list',
  onViewModeChange,
  isHindi = false,
  onImportHospitals,
  customHospitalsCount = 0,
  onClearCustomHospitals
}) => {
  const [detectingGps, setDetectingGps] = useState(false);
  const [detectedNote, setDetectedNote] = useState<string | null>(null);
  const [isUploadingExcel, setIsUploadingExcel] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isDraggingFile, setIsDraggingFile] = useState(false);

  const processExcelFile = async (file: File) => {
    setIsUploadingExcel(true);
    setUploadFeedback(null);

    try {
      const buffer = await file.arrayBuffer();
      const result = parseHospitalExcel(buffer);

      if (result.count === 0) {
        setUploadFeedback({
          type: 'error',
          message: isHindi 
            ? 'फ़ाइल में से अस्पतालों का डेटा नहीं मिल सका। कृपया मान्य Excel (.xlsx) फ़ाइल चुनें।' 
            : 'No hospital records could be parsed. Please ensure it is a valid .xlsx file.'
        });
      } else {
        if (onImportHospitals) {
          onImportHospitals(result.hospitals);
        }
        setUploadFeedback({
          type: 'success',
          message: isHindi
            ? `✅ सफलता! "${file.name}" से ${result.count} अस्पताल सीधे सर्च में जोड़ दिए गए हैं। अब आप किसी भी शहर, गाँव या अस्पताल के नाम से सर्च कर सकते हैं!`
            : `✅ Success! ${result.count} hospitals from "${file.name}" are now live in search. You can search by city, village, hospital name, or pincode!`
        });
      }
    } catch (err: any) {
      console.error('Error parsing Excel:', err);
      setUploadFeedback({
        type: 'error',
        message: isHindi 
          ? 'फ़ाइल पढ़ने में त्रुटि हुई। कृपया Excel (.xlsx) फ़ाइल की जाँच करें।' 
          : 'Failed to read file. Please verify it is a valid Excel spreadsheet.'
      });
    } finally {
      setIsUploadingExcel(false);
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processExcelFile(file);
    }
    // reset input value so re-uploading the same file works
    e.target.value = '';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFile(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processExcelFile(file);
    }
  };

  const handleDetectLocation = () => {
    setDetectingGps(true);
    setDetectedNote(null);

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setDetectingGps(false);
          const lat = pos.coords.latitude.toFixed(3);
          const lon = pos.coords.longitude.toFixed(3);
          setDetectedNote(`GPS: ${lat}, ${lon}`);
          if (!searchLocation) {
            onLocationChange('Current GPS Location');
          }
        },
        (err) => {
          setDetectingGps(false);
          setDetectedNote('Location blocked. Showing all nearby.');
          onLocationChange('');
        },
        { timeout: 6000 }
      );
    } else {
      setDetectingGps(false);
      setDetectedNote('Geolocation not supported by browser.');
    }
  };

  const handleCityChipClick = (city: string) => {
    if (city === 'All India') {
      onLocationChange('');
      onStateChange('All India');
    } else {
      onLocationChange(city);
      const cityToStateMap: Record<string, string> = {
        'Hardoi': 'Uttar Pradesh',
        'Pali': 'Uttar Pradesh',
        'Pipraich': 'Uttar Pradesh',
        'Babhnan': 'Uttar Pradesh',
        'Kachhauna': 'Uttar Pradesh',
        'Sitapur': 'Uttar Pradesh',
        'Shahjahanpur': 'Uttar Pradesh',
        'Bareilly': 'Uttar Pradesh',
        'Lucknow': 'Uttar Pradesh',
        'Gorakhpur': 'Uttar Pradesh',
        'Varanasi': 'Uttar Pradesh',
        'Kanpur': 'Uttar Pradesh',
        'Agra': 'Uttar Pradesh',
        'Prayagraj': 'Uttar Pradesh',
        'Meerut': 'Uttar Pradesh',
        'Ayodhya': 'Uttar Pradesh',
        'New Delhi': 'Delhi',
        'Patna': 'Bihar',
        'Mumbai': 'Maharashtra',
        'Pune': 'Maharashtra',
        'Bengaluru': 'Karnataka',
        'Chennai': 'Tamil Nadu',
        'Kolkata': 'West Bengal',
        'Jaipur': 'Rajasthan',
        'Ahmedabad': 'Gujarat',
        'Hyderabad': 'Telangana',
        'Chandigarh': 'Chandigarh',
        'Bhopal': 'Madhya Pradesh',
        'Guwahati': 'Assam',
        'Srinagar': 'Jammu & Kashmir',
        'Kochi': 'Kerala'
      };
      if (cityToStateMap[city]) {
        onStateChange(cityToStateMap[city]);
      } else {
        onStateChange('All India');
      }
    }
  };

  const currentStateInfo = INDIAN_STATES.find(s => s.name === selectedState);

  return (
    <section id="search" className="relative py-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#071722] to-[#040b12] border-y border-white/10">
      <div className="max-w-7xl mx-auto">
        
        {/* National Emergency Hotline Quick Strip */}
        <div className="mb-6 p-3 sm:p-4 rounded-2xl bg-gradient-to-r from-[#ff3150]/20 via-[#ff003d]/15 to-[#00e5ff]/15 border border-[#ff3150]/40 backdrop-blur-md">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff3150] animate-ping" />
              <span className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#ff3150]" />
                24x7 Pan-India Emergency Helplines:
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs">
              {NATIONAL_EMERGENCY_HELPLINES.map((helpline) => (
                <a
                  key={helpline.number}
                  href={`tel:${helpline.number}`}
                  className="px-2.5 py-1 rounded-lg bg-black/50 hover:bg-[#ff3150] text-white border border-white/20 hover:border-[#ff3150] font-black flex items-center gap-1 transition-all"
                  title={helpline.description}
                >
                  <Phone className="w-3 h-3 text-[#00ff9d]" />
                  <span>{helpline.number}</span>
                  <span className="text-[10px] text-gray-300 font-normal hidden md:inline">({helpline.service})</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00e5ff]/10 border border-[#00e5ff]/30 text-xs font-extrabold uppercase tracking-widest text-[#00e5ff] mb-3">
            <Compass className="w-3.5 h-3.5 animate-spin" />
            <span>PAN-INDIA LIVE EMERGENCY RADAR • 28 STATES & UTs</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Search Hospitals & Doctors in Any Indian City
          </h2>
          <p className="text-sm sm:text-base text-[#9db3be] mt-2">
            Instant directory across metros, district capitals, tier-2/3 cities, and rural CHCs. Verified ICU beds, Ayushman Bharat PM-JAY support, and emergency on-call doctors.
          </p>
        </div>

        {/* Search Box Container */}
        <div className="p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-white/[0.07] to-white/[0.02] border border-white/15 shadow-[0_20px_50px_rgba(0,0,0,0.5)] backdrop-blur-xl">
          
          {/* Excel File Import Strip - Specifically optimized for List of Hospital - 596707.xlsx */}
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`mb-6 p-3.5 sm:p-4 rounded-xl border transition-all ${
              isDraggingFile 
                ? 'bg-emerald-500/20 border-emerald-400 scale-[1.01]' 
                : 'bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-slate-900/60 border-emerald-500/30'
            }`}
          >
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-start sm:items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5">
                      {isHindi ? 'अस्पताल एक्सेल फ़ाइल इम्पोर्ट:' : 'Hospital Excel File Sync:'}
                      <span className="text-emerald-300 font-mono text-xs bg-emerald-950/90 px-2 py-0.5 rounded border border-emerald-500/40">
                        List of Hospital - 596707.xlsx
                      </span>
                    </span>
                    {customHospitalsCount > 0 && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-black">
                        {customHospitalsCount} {isHindi ? 'अस्पताल लाइव' : 'Live Loaded'}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] sm:text-xs text-slate-300 mt-0.5">
                    {isHindi 
                      ? 'अपनी एक्सेल फ़ाइल को यहाँ चुनें या ड्रैग करें — सभी अस्पताल, गाँव, शहर, डॉक्टर व बेड तुरंत सर्च में उपलब्ध हो जाएंगे।'
                      : 'Upload or drag your .xlsx file here — all hospitals, villages, doctors, ICU beds will be instantly searchable.'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center w-full sm:w-auto justify-end">
                <label className="cursor-pointer px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-950/50 transition-all hover:scale-105 active:scale-95">
                  <UploadCloud className="w-4 h-4" />
                  <span>{isUploadingExcel ? (isHindi ? 'लोड हो रहा है...' : 'Parsing...') : (isHindi ? 'फ़ाइल चुनें (.xlsx)' : 'Choose .xlsx File')}</span>
                  <input 
                    type="file" 
                    accept=".xlsx, .xls, .csv" 
                    onChange={handleFileInputChange} 
                    className="hidden" 
                    disabled={isUploadingExcel}
                  />
                </label>

                {customHospitalsCount > 0 && onClearCustomHospitals && (
                  <button
                    type="button"
                    onClick={onClearCustomHospitals}
                    title={isHindi ? 'कस्टम अस्पताल हटाएं' : 'Reset imported hospitals'}
                    className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Upload feedback banner */}
            {uploadFeedback && (
              <div className={`mt-3 p-2.5 rounded-lg text-xs flex items-start gap-2 border ${
                uploadFeedback.type === 'success'
                  ? 'bg-emerald-950/90 text-emerald-200 border-emerald-500/50'
                  : 'bg-rose-950/90 text-rose-200 border-rose-500/50'
              }`}>
                {uploadFeedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                )}
                <span>{uploadFeedback.message}</span>
              </div>
            )}
          </div>

          {/* Service Category Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 sm:gap-3 mb-6">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isSelected = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  type="button"
                  id={`cat-btn-${cat.id}`}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`flex flex-col items-center justify-center p-3 sm:p-4 rounded-xl border transition-all text-center group ${
                    isSelected
                      ? 'bg-gradient-to-b from-white/15 to-white/5 border-[#00e5ff] shadow-[0_0_20px_rgba(0,229,255,0.25)] text-white'
                      : 'bg-white/[0.03] border-white/10 hover:border-white/25 text-[#9db3be] hover:text-white'
                  }`}
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center mb-2 transition-transform group-hover:scale-110"
                    style={{
                      backgroundColor: isSelected ? `${cat.color}25` : 'rgba(255,255,255,0.05)',
                      color: isSelected ? cat.color : '#c2d2da',
                    }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-xs sm:text-sm font-bold tracking-tight whitespace-nowrap">
                    {cat.label}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Quick City Selector Chips */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#a0b5c1] flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#00e5ff]" />
                Select Any City Across India:
              </span>
              <span className="text-[10px] text-[#00ff9d] font-bold">28 States & 750+ Districts Covered</span>
            </div>
            
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-white/20">
              {QUICK_CITIES.map((city) => {
                const isActive = (city === 'All India' && !searchLocation && selectedState === 'All India') ||
                  (searchLocation.toLowerCase() === city.toLowerCase());
                return (
                  <button
                    key={city}
                    type="button"
                    onClick={() => handleCityChipClick(city)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${
                      isActive
                        ? 'bg-[#00e5ff] text-black border-[#00e5ff] shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                        : 'bg-white/5 text-gray-300 border-white/10 hover:border-[#00e5ff]/50 hover:text-white'
                    }`}
                  >
                    {city}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Main Filter Row: State Dropdown, City / Location Input, Keyword Search */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 sm:gap-4 items-center">
            
            {/* State / UT Selector */}
            <div className="md:col-span-3 relative">
              <label className="block text-[11px] font-bold text-[#a0b5c1] uppercase tracking-wider mb-1.5 flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-[#00e5ff]" />
                State / Union Territory
              </label>
              <div className="relative">
                <select
                  id="state-selector-input"
                  value={selectedState}
                  onChange={(e) => {
                    onStateChange(e.target.value);
                  }}
                  className="w-full py-3 px-3 rounded-xl bg-black/60 border border-white/20 text-white text-xs sm:text-sm font-semibold focus:outline-none focus:border-[#00e5ff] transition-all cursor-pointer appearance-none"
                >
                  {INDIAN_STATES.map((state) => (
                    <option key={state.name} value={state.name} className="bg-[#071722] text-white">
                      {state.name} {state.code !== 'IN' ? `(${state.code})` : ''}
                    </option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-400">
                  ▼
                </div>
              </div>
            </div>

            {/* City / Village / District / Area Input */}
            <div className="md:col-span-5 relative">
              <label className="block text-[11px] font-bold text-[#a0b5c1] uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>📍 Village / Tehsil / City / Pincode (गाँव या शहर)</span>
                {detectedNote && (
                  <span className="text-[10px] text-[#00e5ff] lowercase">{detectedNote}</span>
                )}
              </label>
              <div className="relative flex items-center">
                <MapPin className="absolute left-3.5 w-4 h-4 text-[#00e5ff]" />
                <input
                  type="text"
                  id="search-location-input"
                  value={searchLocation}
                  onChange={(e) => onLocationChange(e.target.value)}
                  placeholder="e.g. Pipraich, Babhnan, Kachhauna, Gorakhpur, Lucknow, Patna..."
                  className="w-full pl-10 pr-24 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-gray-500 text-xs sm:text-sm focus:outline-none focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] transition-all"
                />
                <button
                  type="button"
                  id="search-gps-btn"
                  onClick={handleDetectLocation}
                  disabled={detectingGps}
                  className="absolute right-2 px-2.5 py-1.5 rounded-lg text-[11px] font-bold bg-[#00e5ff]/15 hover:bg-[#00e5ff]/25 text-[#00e5ff] border border-[#00e5ff]/30 flex items-center gap-1 transition-all disabled:opacity-50"
                  title="Detect My Location"
                >
                  <Navigation className={`w-3 h-3 ${detectingGps ? 'animate-spin' : ''}`} />
                  <span>{detectingGps ? 'Locating...' : 'GPS'}</span>
                </button>
              </div>
            </div>

            {/* Keyword / Doctor / Hospital Name / Specialty */}
            <div className="md:col-span-4 relative">
              <label className="block text-[11px] font-bold text-[#a0b5c1] uppercase tracking-wider mb-1.5">
                🔍 Hospital, Doctor or Specialty
              </label>
              <div className="relative flex items-center">
                <Search className="absolute left-3.5 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  id="search-query-input"
                  value={searchQuery}
                  onChange={(e) => onQueryChange(e.target.value)}
                  placeholder={
                    activeCategory === 'hospital'
                      ? 'AIIMS, District Hospital, ICU, Cardiology...'
                      : activeCategory === 'doctor'
                        ? 'Pediatric, Cardiologist, Dr. Sharma...'
                        : activeCategory === 'blood'
                          ? 'Blood Bank, O+ donor, Platelets...'
                          : 'Search by name or facility...'
                  }
                  className="w-full pl-10 pr-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-gray-500 text-xs sm:text-sm focus:outline-none focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] transition-all"
                />
              </div>
            </div>

          </div>

          {/* Secondary Filter Row: Hospital Tier Chips, Ayushman PM-JAY Toggle, 24/7 Toggle */}
          <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            
            {/* Hospital Tiers Filter (shown for hospitals) */}
            {activeCategory === 'hospital' && (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-[11px] font-bold text-gray-400 uppercase mr-1">Hospital Tier:</span>
                {HOSPITAL_TIERS.map((tier) => (
                  <button
                    key={tier.id}
                    type="button"
                    onClick={() => onTierChange(tier.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold border transition-all ${
                      selectedTier === tier.id
                        ? 'bg-[#00e5ff]/20 text-[#00e5ff] border-[#00e5ff] shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                        : 'bg-white/5 text-gray-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    {tier.label}
                  </button>
                ))}
              </div>
            )}

            {/* Quick Feature Toggles */}
            <div className="flex flex-wrap items-center gap-2 ml-auto">
              {/* Ayushman Bharat PM-JAY Filter */}
              {(activeCategory === 'hospital' || activeCategory === 'doctor') && (
                <button
                  type="button"
                  id="filter-ayushman-btn"
                  onClick={onToggleAyushman}
                  className={`py-1.5 px-3 rounded-xl text-xs font-extrabold flex items-center gap-1.5 border transition-all ${
                    ayushmanOnly
                      ? 'bg-[#00ff9d]/20 border-[#00ff9d] text-[#00ff9d] shadow-[0_0_15px_rgba(0,255,157,0.3)]'
                      : 'bg-white/5 border-white/15 text-gray-300 hover:border-white/30'
                  }`}
                  title="Filter Ayushman Bharat (PM-JAY) eligible hospitals and doctors"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-[#00ff9d]" />
                  <span>Ayushman Bharat (PM-JAY): {ayushmanOnly ? 'ONLY' : 'ALL'}</span>
                </button>
              )}

              {/* 24/7 Emergency Filter */}
              <button
                type="button"
                id="filter-247-btn"
                onClick={onToggle247}
                className={`py-1.5 px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
                  filter247
                    ? 'bg-[#ff3150]/20 border-[#ff3150] text-[#ff3150] shadow-[0_0_15px_rgba(255,49,80,0.3)]'
                    : 'bg-white/5 border-white/15 text-gray-300 hover:border-white/30'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-[#ff3150]" />
                <span>24/7 Emergency: {filter247 ? 'ON' : 'OFF'}</span>
              </button>
            </div>

          </div>

          {/* Blood Group Selector (Shown when Blood is selected) */}
          {activeCategory === 'blood' && (
            <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-[#ff4d67] uppercase tracking-wider mr-2 flex items-center gap-1">
                <Droplet className="w-3.5 h-3.5" /> Select Blood Group:
              </span>
              {BLOOD_GROUPS.map((bg) => (
                <button
                  key={bg}
                  type="button"
                  id={`bg-filter-${bg}`}
                  onClick={() => onBloodGroupChange(bg)}
                  className={`px-3 py-1 rounded-lg text-xs font-extrabold transition-all ${
                    selectedBloodGroup === bg
                      ? 'bg-[#ff3150] text-white shadow-[0_0_12px_rgba(255,49,80,0.5)] scale-105'
                      : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                  }`}
                >
                  {bg}
                </button>
              ))}
            </div>
          )}

          {/* Quick Stats & Active Filters Banner */}
          <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between text-xs text-[#9db3be] gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="inline-block w-2 h-2 rounded-full bg-[#00e5ff] animate-pulse" />
              <span>
                Found <strong className="text-white">{resultsCount}</strong> verified entries in{' '}
                <strong className="text-[#00e5ff]">{selectedState}</strong>
                {searchLocation && <span> • city: <strong className="text-white">"{searchLocation}"</strong></span>}
                {ayushmanOnly && <span className="text-[#00ff9d]"> • Ayushman Bharat PM-JAY</span>}
                {selectedTier !== 'ALL' && <span className="text-[#ffd166]"> • {selectedTier}</span>}
              </span>
            </div>

            <div className="flex items-center gap-3">
              {/* Quick View Mode Switcher */}
              <div className="flex items-center gap-1 p-1 rounded-xl bg-black/60 border border-white/10">
                <button
                  type="button"
                  id="qs-viewmode-list-btn"
                  onClick={() => {
                    onViewModeChange?.('list');
                    const el = document.getElementById('services');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                    viewMode === 'list'
                      ? 'bg-[#00e5ff] text-black shadow-[0_0_10px_rgba(0,229,255,0.4)]'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <List className="w-3.5 h-3.5" />
                  <span>List</span>
                </button>
                <button
                  type="button"
                  id="qs-viewmode-map-btn"
                  onClick={() => {
                    onViewModeChange?.('map');
                    const el = document.getElementById('services');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                    viewMode === 'map'
                      ? 'bg-[#00ff9d] text-black shadow-[0_0_10px_rgba(0,255,157,0.4)]'
                      : 'text-gray-400 hover:text-white'
                  }`}
                >
                  <Map className="w-3.5 h-3.5" />
                  <span>Interactive Map (मैप)</span>
                </button>
              </div>

              {(searchLocation || searchQuery || selectedState !== 'All India' || selectedTier !== 'ALL' || ayushmanOnly || filter247 || selectedBloodGroup !== 'ALL') && (
                <button
                  type="button"
                  id="reset-filters-btn"
                  onClick={() => {
                    onLocationChange('');
                    onQueryChange('');
                    onStateChange('All India');
                    onTierChange('ALL');
                    onBloodGroupChange('ALL');
                    if (ayushmanOnly) onToggleAyushman();
                    if (filter247) onToggle247();
                  }}
                  className="text-xs text-[#00e5ff] hover:underline font-semibold flex items-center gap-1"
                >
                  <X className="w-3 h-3" />
                  <span>Reset all</span>
                </button>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
