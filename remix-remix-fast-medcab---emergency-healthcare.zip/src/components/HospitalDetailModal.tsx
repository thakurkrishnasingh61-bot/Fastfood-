import React, { useState, useEffect } from 'react';
import { HospitalItem } from '../types';
import { 
  X, 
  Phone, 
  MapPin, 
  Navigation, 
  ShieldCheck, 
  Star, 
  Bed, 
  Wind, 
  Activity, 
  HeartHandshake, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Building2, 
  Share2, 
  Calendar, 
  Check, 
  Ambulance, 
  Droplet, 
  FileText,
  BadgePercent,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HospitalDetailModalProps {
  hospital: HospitalItem | null;
  onClose: () => void;
  onDispatchAmbulance?: (hospital: HospitalItem) => void;
}

export const HospitalDetailModal: React.FC<HospitalDetailModalProps> = ({
  hospital,
  onClose,
  onDispatchAmbulance,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'beds' | 'facilities' | 'insurance' | 'booking'>('overview');
  const [copied, setCopied] = useState(false);
  
  // Emergency Bed Alert form states
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [emergencyType, setEmergencyType] = useState('Accident / Trauma');
  const [triageStatus, setTriageStatus] = useState<string | null>(null);
  const [bookingToken, setBookingToken] = useState<string | null>(null);

  // Close on ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!hospital) return null;

  const getMapsUrl = (name: string, address: string) => {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name}, ${address}`)}`;
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: hospital.name,
        text: `Emergency hospital details: ${hospital.name}, ${hospital.city}. Emergency: ${hospital.emergencyPhone || hospital.phone}`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(`${hospital.name}, ${hospital.address} - Emergency: ${hospital.emergencyPhone || hospital.phone}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleBedBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !patientPhone) return;

    const token = `FAST-ICU-${Math.floor(100000 + Math.random() * 900000)}`;
    setBookingToken(token);
    setTriageStatus('CONFIRMED');
  };

  // Bed statistics calculation
  const totalIcu = hospital.totalIcuBeds || 40;
  const availIcu = hospital.icuBedsAvailable || 8;
  const icuPercent = Math.round((availIcu / totalIcu) * 100);

  const totalGeneral = hospital.totalGeneralBeds || (typeof hospital.bedsCapacity === 'number' ? hospital.bedsCapacity : 300);
  const availGeneral = hospital.generalBedsAvailable || Math.max(15, Math.floor(Number(totalGeneral) * 0.22));

  const totalOxygen = hospital.totalOxygenBeds || Math.floor(Number(totalGeneral) * 0.4);
  const availOxygen = hospital.oxygenBedsAvailable || Math.max(10, Math.floor(Number(totalOxygen) * 0.28));

  const totalVent = hospital.totalVentilators || Math.max(6, Math.floor(totalIcu * 0.35));
  const availVent = hospital.ventilatorBedsAvailable || Math.max(2, Math.floor(totalVent * 0.25));

  const totalNicu = hospital.totalNicuBeds || 16;
  const availNicu = hospital.nicuBedsAvailable || 6;

  const facilities = hospital.facilitiesList || [
    '24/7 Level-1 Dedicated Trauma Triage OT',
    hospital.bloodBankAttached ? 'In-House Blood Bank with Component Separation' : 'Attached Regional Blood Center Support',
    'Advanced High-Speed CT Scanner & 3T MRI Unit',
    'Cardiac Cath Lab for 24/7 Primary Angioplasty',
    'Central Liquid Medical Oxygen (LMO) Plant',
    'Zero-Delay Emergency Casualty Wards',
    'Ayushman PM-JAY Cashless Helpdesk Counter',
    'Dedicated ALS/BLS Ambulance Standby Bay'
  ];

  const schemes = hospital.schemesAccepted || [
    hospital.ayushmanBharat ? 'Ayushman Bharat (PM-JAY) 100% Free / ₹5 Lakh Cashless' : 'State Subsidized Healthcare',
    'UP Mukhyamantri Jan Arogya Yojana',
    'Janani Shishu Suraksha Karyakram (JSSK)',
    'CGHS, ECHS & ESIC Empanelled',
    'Zero-Advance Emergency Admission Mandate'
  ];

  const insuranceList = hospital.insurancePartners || [
    'PM-JAY Golden Card',
    'Star Health & Allied Insurance',
    'HDFC ERGO Health Insurance',
    'ICICI Lombard General Insurance',
    'Care Health Insurance (Religare)',
    'Niva Bupa Health Insurance',
    'Medi Assist TPA'
  ];

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md overflow-y-auto"
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ duration: 0.2 }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-4xl max-h-[92vh] flex flex-col rounded-3xl bg-[#061421] border border-white/20 shadow-[0_25px_70px_rgba(0,0,0,0.8)] text-white overflow-hidden"
      >
        {/* Top Header Banner */}
        <div className="relative p-5 sm:p-7 bg-gradient-to-r from-[#0a2335] via-[#0d2e46] to-[#081b2b] border-b border-white/10 shrink-0">
          {/* Action buttons top right */}
          <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
            <button
              type="button"
              onClick={handleShare}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-gray-200 hover:text-white border border-white/15 transition-all text-xs flex items-center gap-1.5"
              title="Share Hospital Details"
            >
              {copied ? <Check className="w-4 h-4 text-[#00ff9d]" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copied ? 'Copied' : 'Share'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-[#ff3150] text-gray-200 hover:text-white border border-white/15 hover:border-[#ff3150] transition-all"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Badges */}
          <div className="flex flex-wrap items-center gap-2 mb-2 pr-24">
            <span className="px-2.5 py-0.5 rounded-md text-[11px] font-extrabold uppercase tracking-wide bg-[#00e5ff]/15 text-[#00e5ff] border border-[#00e5ff]/40">
              {hospital.tier || hospital.type}
            </span>
            {hospital.ayushmanBharat && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[11px] font-extrabold bg-[#00ff9d]/20 text-[#00ff9d] border border-[#00ff9d]/40 shadow-[0_0_10px_rgba(0,255,157,0.2)]">
                <ShieldCheck className="w-3.5 h-3.5 text-[#00ff9d]" />
                <span>Ayushman Bharat (PM-JAY) 100% Free</span>
              </span>
            )}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-[#ffd166]/15 text-[#ffd166] border border-[#ffd166]/30">
              <Star className="w-3.5 h-3.5 fill-[#ffd166]" />
              <span>{hospital.rating} Rating</span>
            </span>
            <span className="text-xs text-[#00ff9d] font-bold">
              ● 24x7 Level-1 Emergency Active
            </span>
          </div>

          {/* Hospital Name */}
          <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-tight mb-2 pr-12">
            {hospital.name}
          </h2>

          {/* Address & Pincode */}
          <div className="flex flex-wrap items-center gap-y-1 gap-x-3 text-xs sm:text-sm text-[#a0b6c2]">
            <span className="flex items-center gap-1.5 text-gray-300">
              <MapPin className="w-4 h-4 text-[#00e5ff] shrink-0" />
              <span>{hospital.address}</span>
            </span>
            {hospital.pincode && (
              <span className="px-2 py-0.5 rounded bg-black/40 text-gray-300 font-mono text-xs border border-white/10">
                PIN: {hospital.pincode}
              </span>
            )}
            <span className="text-[#00ff9d] font-bold">
              📍 ~{hospital.distanceKm} km away
            </span>
          </div>

          {/* Primary Quick Contact Bar */}
          <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-2">
            <a
              href={`tel:${hospital.emergencyPhone || hospital.phone}`}
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-black shadow-[0_4px_20px_rgba(255,49,80,0.4)] transition-all"
            >
              <Phone className="w-4 h-4 animate-pulse" />
              <span>Call Casualty ({hospital.emergencyPhone || hospital.phone})</span>
            </a>

            <a
              href={getMapsUrl(hospital.name, hospital.address)}
              target="_blank"
              rel="noreferrer"
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white border border-white/20 text-xs font-bold transition-all"
            >
              <Navigation className="w-4 h-4 text-[#00e5ff]" />
              <span>Google Maps Route</span>
            </a>

            <button
              type="button"
              onClick={() => setActiveTab('booking')}
              className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#00e5ff]/20 hover:bg-[#00e5ff]/30 text-[#00e5ff] border border-[#00e5ff]/50 text-xs font-bold transition-all"
            >
              <Zap className="w-4 h-4" />
              <span>Reserve ICU / Bed Alert</span>
            </button>

            {onDispatchAmbulance && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onDispatchAmbulance(hospital);
                }}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-[#00ff9d]/20 hover:bg-[#00ff9d]/30 text-[#00ff9d] border border-[#00ff9d]/40 text-xs font-bold transition-all"
              >
                <Ambulance className="w-4 h-4" />
                <span>Call Ambulance Here</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-white/10 bg-[#040e18] px-4 sm:px-7 overflow-x-auto shrink-0 scrollbar-none">
          <button
            type="button"
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-extrabold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'overview'
                ? 'border-[#00e5ff] text-[#00e5ff] bg-white/[0.04]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            📋 Overview & Doctors
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('beds')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-extrabold border-b-2 transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'beds'
                ? 'border-[#00ff9d] text-[#00ff9d] bg-white/[0.04]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            <Bed className="w-3.5 h-3.5" />
            <span>Live Beds & ICU ({availIcu} Free)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('facilities')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-extrabold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'facilities'
                ? 'border-[#38bdf8] text-[#38bdf8] bg-white/[0.04]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            🏥 Facilities & OT
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('insurance')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-extrabold border-b-2 transition-all whitespace-nowrap ${
              activeTab === 'insurance'
                ? 'border-[#ffd166] text-[#ffd166] bg-white/[0.04]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            🛡️ Ayushman & Insurance
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('booking')}
            className={`py-3 px-3 sm:px-4 text-xs sm:text-sm font-extrabold border-b-2 transition-all whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'booking'
                ? 'border-[#ff3150] text-[#ff3150] bg-white/[0.04]'
                : 'border-transparent text-gray-400 hover:text-white'
            }`}
          >
            🚨 Emergency Admission Alert
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-5 sm:p-7 overflow-y-auto flex-1 space-y-6">

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Description */}
              {hospital.description && (
                <div className="p-4 rounded-2xl bg-black/30 border border-white/10 text-sm text-gray-300 leading-relaxed">
                  <p>{hospital.description}</p>
                  {hospital.landmarks && (
                    <div className="mt-2 text-xs text-[#00e5ff] flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5" />
                      <span><strong>Landmark:</strong> {hospital.landmarks}</span>
                    </div>
                  )}
                </div>
              )}

              {/* Key Medical Officers & In-Charge */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#00e5ff]/10 to-transparent border border-[#00e5ff]/20">
                <div className="flex items-center gap-2 text-xs font-bold text-[#00e5ff] uppercase tracking-wider mb-2">
                  <Building2 className="w-4 h-4" />
                  <span>Hospital Administration & Emergency On-Duty Desk</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-gray-400 block">Chief Medical Officer / Superintendent:</span>
                    <span className="text-white font-bold text-sm">{hospital.cmoName || 'Duty Chief Medical Officer (CMO)'}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">General OPD Timings:</span>
                    <span className="text-white font-semibold">{hospital.opdTimings || '24/7 Emergency Casualty | OPD: 8:00 AM - 2:00 PM'}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">OPD Registration Fee:</span>
                    <span className="text-[#00ff9d] font-bold text-sm">{hospital.consultationFee || 'Free / ₹1 Govt Registration Token'}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 block">Emergency Advance Deposit:</span>
                    <span className="text-[#ffd166] font-bold text-sm">{hospital.admissionDeposit || '₹0 (Zero Advance Required in Emergency)'}</span>
                  </div>
                </div>
              </div>

              {/* Medical Specialties & Departments */}
              <div>
                <h4 className="text-sm font-extrabold uppercase tracking-wider text-white mb-3 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-[#00e5ff]" />
                  <span>Key Departments & Critical Specialties</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                  {hospital.specialties.map((spec, i) => (
                    <div 
                      key={i} 
                      className="p-3 rounded-xl bg-white/[0.04] border border-white/10 flex items-center gap-2.5 text-xs font-medium text-gray-200"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#00ff9d] shrink-0" />
                      <span>{spec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Direct Emergency Extensions */}
              <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-gray-400 mb-3">
                  Direct Department Extensions (One-Tap Calling)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <a
                    href={`tel:${hospital.casualtyHelpline || hospital.emergencyPhone || hospital.phone}`}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-between transition-all"
                  >
                    <div>
                      <span className="text-[10px] text-gray-400 uppercase font-bold block">Casualty Triage</span>
                      <span className="text-xs font-extrabold text-white">{hospital.casualtyHelpline || hospital.emergencyPhone || '108'}</span>
                    </div>
                    <Phone className="w-4 h-4 text-[#ff3150]" />
                  </a>

                  <a
                    href={`tel:${hospital.bloodBankHelpline || '104'}`}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-between transition-all"
                  >
                    <div>
                      <span className="text-[10px] text-gray-400 uppercase font-bold block">Blood Bank Direct</span>
                      <span className="text-xs font-extrabold text-white">{hospital.bloodBankHelpline || '104 / Blood Ext.'}</span>
                    </div>
                    <Droplet className="w-4 h-4 text-[#ff4d67]" />
                  </a>

                  <a
                    href={`tel:${hospital.ambulanceHelpline || '108'}`}
                    className="p-3 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-between transition-all"
                  >
                    <div>
                      <span className="text-[10px] text-gray-400 uppercase font-bold block">Ambulance Bay</span>
                      <span className="text-xs font-extrabold text-white">{hospital.ambulanceHelpline || '108'}</span>
                    </div>
                    <Ambulance className="w-4 h-4 text-[#00ff9d]" />
                  </a>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LIVE BEDS */}
          {activeTab === 'beds' && (
            <div className="space-y-6">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#00ff9d]/10 via-[#00e5ff]/10 to-transparent border border-[#00ff9d]/30">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-extrabold uppercase text-[#00ff9d] tracking-wider">
                    ● Real-Time Bed Occupancy Telemetry
                  </span>
                  <span className="text-xs text-gray-300">Updated: Just Now</span>
                </div>
                <p className="text-xs text-gray-300">
                  Direct data link with state health dashboard and institutional bed counters. Patients arriving in critical conditions receive immediate triage priority.
                </p>
              </div>

              {/* Bed Category Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1. ICU Beds */}
                <div className="p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Bed className="w-5 h-5 text-[#00ff9d]" />
                      <h4 className="font-extrabold text-sm text-white">ICU (Intensive Care Beds)</h4>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#00ff9d]/20 text-[#00ff9d] border border-[#00ff9d]/40">
                      {availIcu > 0 ? 'Available' : 'Full'}
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl font-black text-[#00ff9d]">{availIcu}</span>
                    <span className="text-xs text-gray-400">/ {totalIcu} Total Beds</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mb-2">
                    <div 
                      className="h-full bg-gradient-to-r from-[#00ff9d] to-[#00e5ff] rounded-full"
                      style={{ width: `${Math.min(100, Math.max(10, icuPercent))}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Equipped with multipara monitors, arterial lines, central suction, and dedicated intensivist coverage.
                  </p>
                </div>

                {/* 2. Ventilator / Critical Care */}
                <div className="p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Wind className="w-5 h-5 text-[#38bdf8]" />
                      <h4 className="font-extrabold text-sm text-white">Ventilator Beds</h4>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#38bdf8]/20 text-[#38bdf8] border border-[#38bdf8]/40">
                      {availVent} Free
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl font-black text-[#38bdf8]">{availVent}</span>
                    <span className="text-xs text-gray-400">/ {totalVent} Total Ventilators</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mb-2">
                    <div 
                      className="h-full bg-[#38bdf8] rounded-full"
                      style={{ width: `${Math.round((availVent / totalVent) * 100)}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-400">
                    High-end invasive & non-invasive ventilators for respiratory failure, stroke, and trauma resuscitation.
                  </p>
                </div>

                {/* 3. Oxygen Supported Beds */}
                <div className="p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Wind className="w-5 h-5 text-[#00e5ff]" />
                      <h4 className="font-extrabold text-sm text-white">Oxygen Supported Beds</h4>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#00e5ff]/20 text-[#00e5ff] border border-[#00e5ff]/40">
                      High Reserve
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl font-black text-[#00e5ff]">{availOxygen}</span>
                    <span className="text-xs text-gray-400">/ {totalOxygen} Total Oxygen Beds</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mb-2">
                    <div 
                      className="h-full bg-[#00e5ff] rounded-full"
                      style={{ width: `${Math.round((availOxygen / totalOxygen) * 100)}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Connected to Central Liquid Medical Oxygen (LMO) tank with high-flow nasal cannula (HFNC) capability.
                  </p>
                </div>

                {/* 4. Neonatal ICU (NICU) / PICU */}
                <div className="p-5 rounded-2xl bg-black/40 border border-white/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <HeartHandshake className="w-5 h-5 text-[#ffd166]" />
                      <h4 className="font-extrabold text-sm text-white">NICU / Pediatric ICU</h4>
                    </div>
                    <span className="text-xs px-2 py-0.5 rounded-full font-bold bg-[#ffd166]/20 text-[#ffd166] border border-[#ffd166]/40">
                      Active
                    </span>
                  </div>
                  <div className="flex items-baseline gap-2 mb-2">
                    <span className="text-3xl font-black text-[#ffd166]">{availNicu}</span>
                    <span className="text-xs text-gray-400">/ {totalNicu} Warmers & Incubators</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden mb-2">
                    <div 
                      className="h-full bg-[#ffd166] rounded-full"
                      style={{ width: `${Math.round((availNicu / totalNicu) * 100)}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-400">
                    Level-3 neonatal care for premature babies, respiratory distress, phototherapy, and infant surgery.
                  </p>
                </div>
              </div>

              {/* General Emergency Ward Summary */}
              <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-white">General Emergency & Post-Operative Wards</h4>
                  <p className="text-xs text-gray-400">Male, female, and observation recovery beds</p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-black text-white">{availGeneral}</span>
                  <span className="text-xs text-gray-400"> / {totalGeneral} Available</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: FACILITIES */}
          {activeTab === 'facilities' && (
            <div className="space-y-6">
              <h4 className="text-sm font-extrabold uppercase tracking-wider text-white mb-3 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#38bdf8]" />
                <span>Diagnostic & Surgical Infrastructure Available 24x7</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {facilities.map((fac, idx) => (
                  <div key={idx} className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-start gap-3">
                    <CheckCircle2 className="w-4 h-4 text-[#00ff9d] shrink-0 mt-0.5" />
                    <div>
                      <span className="text-xs font-bold text-white block">{fac}</span>
                      <span className="text-[11px] text-gray-400">Operational round the clock with on-duty technicians</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Emergency Radiology & Blood Bank Highlights */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-gradient-to-br from-white/[0.05] to-transparent border border-white/10">
                  <h5 className="text-xs font-extrabold uppercase text-[#00e5ff] mb-2 flex items-center gap-1.5">
                    <Activity className="w-4 h-4" />
                    <span>Emergency Imaging & STAT Scans</span>
                  </h5>
                  <p className="text-xs text-gray-300 leading-relaxed mb-2">
                    In-house 128-slice CT scanner capable of immediate trauma whole-body pan-scan, brain stroke angiography, and emergency digital X-ray with zero transit delay.
                  </p>
                  <span className="text-[11px] font-semibold text-[#00ff9d]">✓ Radiologist on 24/7 duty roster</span>
                </div>

                <div className="p-4 rounded-2xl bg-gradient-to-br from-[#ff3150]/10 to-transparent border border-[#ff3150]/20">
                  <h5 className="text-xs font-extrabold uppercase text-[#ff4d67] mb-2 flex items-center gap-1.5">
                    <Droplet className="w-4 h-4" />
                    <span>Blood Bank & Cryo-storage</span>
                  </h5>
                  <p className="text-xs text-gray-300 leading-relaxed mb-2">
                    Stock of PRBC (Packed Red Blood Cells), Fresh Frozen Plasma (FFP), and Single Donor Platelets (SDP). Emergency cross-matching completed within 30 minutes.
                  </p>
                  <span className="text-[11px] font-semibold text-[#ffd166]">✓ All blood groups stocked for trauma emergencies</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: INSURANCE & AYUSHMAN */}
          {activeTab === 'insurance' && (
            <div className="space-y-6">
              {/* Ayushman Bharat Golden Banner */}
              {hospital.ayushmanBharat ? (
                <div className="p-5 rounded-2xl bg-gradient-to-r from-[#00ff9d]/20 via-[#00e5ff]/15 to-transparent border border-[#00ff9d]/40">
                  <div className="flex items-center gap-2 mb-2">
                    <ShieldCheck className="w-6 h-6 text-[#00ff9d]" />
                    <h3 className="text-base font-extrabold text-white">
                      Ayushman Bharat (PM-JAY) 100% Cashless Treatment
                    </h3>
                  </div>
                  <p className="text-xs text-gray-200 leading-relaxed mb-3">
                    Patients with an Ayushman Golden Card, PM-JAY letter, or eligible ration card receive completely free cashless treatment up to ₹5,00,000 per family per year, covering ICU stay, surgeries, emergency medicines, diagnostics, and food.
                  </p>
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-black/40 border border-white/20 text-xs text-[#00ff9d] font-bold">
                    <span>Ayushman Mitra Helpdesk: Counter #1 in Hospital Main Reception</span>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 text-xs text-gray-300">
                  Private super-specialty tariff applicable. Cashless processing available via private TPAs and corporate health cards.
                </div>
              )}

              {/* Supported Schemes */}
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-white mb-3">
                  Government & Welfare Schemes Accepted
                </h4>
                <div className="space-y-2">
                  {schemes.map((scheme, i) => (
                    <div key={i} className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center gap-2.5 text-xs text-gray-200">
                      <CheckCircle2 className="w-4 h-4 text-[#00ff9d] shrink-0" />
                      <span>{scheme}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Private Insurance Partners */}
              <div>
                <h4 className="text-xs font-extrabold uppercase tracking-wider text-white mb-3">
                  Cashless Insurance TPAs Empanelled
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                  {insuranceList.map((ins, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white/[0.03] border border-white/10 text-gray-300 font-medium">
                      ✓ {ins}
                    </div>
                  ))}
                </div>
              </div>

              {/* Patient Rights Box */}
              <div className="p-4 rounded-2xl bg-[#ffd166]/10 border border-[#ffd166]/30 text-xs text-gray-200 leading-relaxed">
                <div className="flex items-center gap-2 text-[#ffd166] font-bold mb-1">
                  <AlertCircle className="w-4 h-4" />
                  <span>Supreme Court Emergency Medical Care Mandate</span>
                </div>
                <p>
                  Under Article 21 and the Clinical Establishments Act, no hospital (government or private) can deny emergency stabilization, first aid, or life-saving care to an accident or critical emergency patient due to police formalities or advance payment.
                </p>
              </div>
            </div>
          )}

          {/* TAB 5: EMERGENCY BED BOOKING / ALERT */}
          {activeTab === 'booking' && (
            <div className="space-y-5">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-[#ff3150]/20 to-transparent border border-[#ff3150]/30">
                <h4 className="text-sm font-extrabold text-white flex items-center gap-2 mb-1">
                  <Zap className="w-4 h-4 text-[#ff3150]" />
                  <span>Instant Emergency ICU / Bed Reservation Alert</span>
                </h4>
                <p className="text-xs text-gray-300">
                  Notify the on-duty Casualty Medical Officer (CMO) at {hospital.name} to prepare the emergency trauma bay, stretcher, and critical care team before arrival.
                </p>
              </div>

              {triageStatus === 'CONFIRMED' ? (
                <div className="p-6 rounded-2xl bg-gradient-to-b from-[#00ff9d]/20 to-black/60 border border-[#00ff9d]/50 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-[#00ff9d]/20 border border-[#00ff9d] flex items-center justify-center mx-auto text-[#00ff9d]">
                    <Check className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white">Emergency Triage Alert Dispatched!</h3>
                    <p className="text-xs text-gray-300 mt-1">
                      {hospital.name} emergency casualty desk has been notified.
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-black/50 border border-white/10 max-w-sm mx-auto text-left">
                    <div className="text-[11px] text-gray-400">Emergency Priority Token:</div>
                    <div className="text-xl font-mono font-black text-[#00ff9d]">{bookingToken}</div>
                    <div className="text-xs text-gray-300 mt-2">
                      Patient: <strong>{patientName}</strong> ({patientAge} yrs)
                    </div>
                    <div className="text-xs text-gray-300">
                      Emergency: <strong className="text-[#ffd166]">{emergencyType}</strong>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                    <a
                      href={`tel:${hospital.emergencyPhone || hospital.phone}`}
                      className="px-4 py-2.5 rounded-xl bg-[#ff3150] text-white text-xs font-black shadow-[0_0_15px_rgba(255,49,80,0.4)] flex items-center gap-2"
                    >
                      <Phone className="w-4 h-4" />
                      <span>Speak with CMO ({hospital.emergencyPhone || hospital.phone})</span>
                    </a>
                    <a
                      href={getMapsUrl(hospital.name, hospital.address)}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold flex items-center gap-2"
                    >
                      <Navigation className="w-4 h-4 text-[#00e5ff]" />
                      <span>Start Navigation</span>
                    </a>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleBedBookingSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Patient Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={patientName}
                        onChange={(e) => setPatientName(e.target.value)}
                        placeholder="e.g. Ramesh Chandra"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white text-xs placeholder:text-gray-500 focus:outline-none focus:border-[#00e5ff]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Patient Age *
                      </label>
                      <input
                        type="number"
                        required
                        value={patientAge}
                        onChange={(e) => setPatientAge(e.target.value)}
                        placeholder="e.g. 48"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white text-xs placeholder:text-gray-500 focus:outline-none focus:border-[#00e5ff]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Attendant Mobile Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={patientPhone}
                        onChange={(e) => setPatientPhone(e.target.value)}
                        placeholder="e.g. 9839012345"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white text-xs placeholder:text-gray-500 focus:outline-none focus:border-[#00e5ff]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1">
                        Emergency Medical Condition *
                      </label>
                      <select
                        value={emergencyType}
                        onChange={(e) => setEmergencyType(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black/60 border border-white/15 text-white text-xs focus:outline-none focus:border-[#00e5ff]"
                      >
                        <option value="Accident / Road Trauma">Accident / Road Trauma</option>
                        <option value="Heart Attack / Severe Chest Pain">Heart Attack / Severe Chest Pain</option>
                        <option value="Stroke / Paralysis / Slurred Speech">Stroke / Paralysis / Slurred Speech</option>
                        <option value="Severe Breathing Difficulty / Low O2">Severe Breathing Difficulty / Low O2</option>
                        <option value="Emergency Labour / Maternity Delivery">Emergency Labour / Maternity Delivery</option>
                        <option value="Snakebite / Poisoning">Snakebite / Poisoning</option>
                        <option value="Severe Burns">Severe Burns</option>
                        <option value="General Critical ICU Admission">General Critical ICU Admission</option>
                      </select>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/[0.04] border border-white/10 text-xs text-gray-400">
                    ℹ️ By pressing Submit, an alert is transmitted to the emergency reception and casualty registrar. Zero booking fees charged.
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs sm:text-sm font-black shadow-[0_4px_25px_rgba(255,49,80,0.5)] transition-all flex items-center justify-center gap-2"
                  >
                    <Zap className="w-4 h-4" />
                    <span>Generate Emergency Admission Token & Alert Casualty</span>
                  </button>
                </form>
              )}
            </div>
          )}

        </div>

        {/* Bottom Sticky Action Footer */}
        <div className="p-4 sm:p-5 bg-[#040b12] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-gray-400">
            <ShieldCheck className="w-4 h-4 text-[#00ff9d]" />
            <span>Verified by State Health Department & National Health Portal</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <a
              href={`tel:${hospital.emergencyPhone || hospital.phone}`}
              className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-[#ff3150] hover:bg-[#ff1744] text-white text-xs font-black shadow-[0_0_15px_rgba(255,49,80,0.4)] flex items-center justify-center gap-1.5"
            >
              <Phone className="w-4 h-4" />
              <span>Call Emergency: {hospital.emergencyPhone || hospital.phone}</span>
            </a>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-gray-300 hover:text-white border border-white/15 text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>

      </motion.div>
    </div>
  );
};
