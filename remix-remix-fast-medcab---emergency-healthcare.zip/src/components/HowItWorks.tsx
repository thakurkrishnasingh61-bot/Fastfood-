import React from 'react';
import { MapPin, Stethoscope, Search, PhoneCall } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'Enter Location',
      desc: 'Enter your city, area or tap GPS to automatically find verified healthcare near your current location.',
      icon: MapPin,
      color: '#00e5ff',
    },
    {
      num: '02',
      title: 'Select Service',
      desc: 'Choose between Emergency Hospitals, Ambulance, Blood Donors, Doctors, 24/7 Pharmacy or Diagnostic Labs.',
      icon: Stethoscope,
      color: '#ff3150',
    },
    {
      num: '03',
      title: 'Check Live Readiness',
      desc: 'Review verified ICU beds, oxygen status, blood inventory, ambulance ETA, and doctor consultation fees.',
      icon: Search,
      color: '#00ff9d',
    },
    {
      num: '04',
      title: '1-Tap Contact & Go',
      desc: 'Directly dial emergency helplines, paramedic drivers, or open real-time navigation turn-by-turn routes.',
      icon: PhoneCall,
      color: '#ffd166',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-[#07131d] border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold uppercase tracking-widest text-[#00e5ff] inline-block mb-2">
            HOW IT WORKS
          </span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Healthcare Help In 4 Simple Steps
          </h2>
          <p className="text-sm sm:text-base text-[#9db3be] mt-2">
            FAST MEDCAB eliminates panic and confusion during medical emergencies when every minute counts.
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div
                key={step.num}
                className="relative p-6 rounded-2xl bg-white/[0.025] border border-white/10 hover:border-white/25 transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <div
                      className="w-12 h-12 rounded-xl flex items-center justify-center font-black font-mono text-base"
                      style={{
                        backgroundColor: `${step.color}20`,
                        color: step.color,
                        border: `1px solid ${step.color}40`,
                      }}
                    >
                      {step.num}
                    </div>
                    <Icon className="w-5 h-5 text-gray-400 group-hover:text-white transition-colors" />
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#00e5ff] transition-colors">
                    {step.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-[#9cb1be] leading-relaxed">
                    {step.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
