import React, { useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  Calendar, 
  Share2, 
  Printer, 
  BookOpen, 
  ChevronRight, 
  ChevronDown,
  ShieldCheck, 
  Stethoscope, 
  HeartPulse, 
  AlertCircle, 
  Sparkles, 
  Wind, 
  Droplets, 
  Bug, 
  Biohazard, 
  Check, 
  PhoneCall, 
  ArrowRight,
  Clock,
  HelpCircle,
  Building,
  UserCheck,
  FileText,
  ShieldAlert
} from 'lucide-react';
import { HANTAVIRUS_ARTICLE } from '../data/hantavirusData';
import { SURYA_HOSPITAL, SURYA_DOCTORS, SURYA_HEALTH_PACKAGES } from '../data/suryaHospitalData';

interface HantavirusArticleProps {
  onOpenAppointment: (dept?: string, doctor?: string) => void;
  onOpenEmergency: () => void;
  onNavigateToTab: (tab: 'article' | 'az-directory' | 'packages' | 'doctors' | 'screener') => void;
  isHindi: boolean;
}

export const HantavirusArticle: React.FC<HantavirusArticleProps> = ({
  onOpenAppointment,
  onOpenEmergency,
  onNavigateToTab,
  isHindi
}) => {
  const [activeTocId, setActiveTocId] = useState<string>('what-is-hantavirus');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [copiedLink, setCopiedLink] = useState(false);
  const [largeFont, setLargeFont] = useState(false);

  // In-article mini symptom screener state
  const [screenerFever, setScreenerFever] = useState(false);
  const [screenerRodent, setScreenerRodent] = useState(false);
  const [screenerBreathing, setScreenerBreathing] = useState(false);
  const [screenerSubmitted, setScreenerSubmitted] = useState(false);

  const article = HANTAVIRUS_ARTICLE;

  const scrollToSection = (id: string) => {
    setActiveTocId(id);
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.meta.title,
        text: article.meta.subtitle,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getScreenerResult = () => {
    if (screenerBreathing && (screenerFever || screenerRodent)) {
      return {
        level: 'Critical Emergency',
        color: 'bg-rose-50 border-rose-300 text-rose-900',
        badgeColor: 'bg-rose-600 text-white',
        text: isHindi 
          ? 'चेतावनी: सांस लेने में कठिनाई और चूहों के संपर्क का इतिहास आपातकालीन स्थिति है। तुरंत सूर्य हॉस्पिटल इमरजेंसी से संपर्क करें।' 
          : 'High Alert: Severe shortness of breath with fever/rodent exposure requires urgent emergency triage and Level-3 ICU assessment at Surya Hospital.',
        actionText: isHindi ? 'इमरजेंसी हेल्पलाइन डायल करें' : 'Call 24/7 ICU Emergency',
        action: onOpenEmergency
      };
    }
    if (screenerRodent && screenerFever) {
      return {
        level: 'Moderate Risk - Clinical Evaluation Advised',
        color: 'bg-amber-50 border-amber-300 text-amber-900',
        badgeColor: 'bg-amber-600 text-white',
        text: isHindi
          ? 'सलाह: चूहों के संपर्क के बाद बुखार होना संभावित जूनोटिक संक्रमण का संकेत हो सकता है। संक्रामक रोग विशेषज्ञ से परामर्श लें।'
          : 'Advisory: Fever following rodent exposure warrants immediate clinical evaluation, CBC platelet check, and viral screening.',
        actionText: isHindi ? 'डॉ. राजेश सूर्यवंशी से परामर्श लें' : 'Consult Infectious Disease Specialist',
        action: () => onOpenAppointment('Infectious Diseases', 'Dr. Rajesh Suryavanshi')
      };
    }
    return {
      level: 'Low Risk',
      color: 'bg-emerald-50 border-emerald-300 text-emerald-900',
      badgeColor: 'bg-emerald-600 text-white',
      text: isHindi
        ? 'फिलहाल गंभीर लक्षण नहीं हैं। यदि बुखार 101°F से अधिक हो या सांस फूले तो तुरंत डॉक्टर से संपर्क करें।'
        : 'Currently low immediate risk. Monitor your temperature and oxygen saturation (SpO2). Seek prompt care if fever or myalgia develop.',
      actionText: isHindi ? 'ओपीडी अपॉइंटमेंट बुक करें' : 'Book Preventive OPD Checkup',
      action: () => onOpenAppointment()
    };
  };

  return (
    <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 ${largeFont ? 'text-lg leading-relaxed' : 'text-base'}`}>
      
      {/* Breadcrumb Navigation */}
      <nav className="flex items-center space-x-2 text-xs text-slate-500 mb-6 flex-wrap">
        <button onClick={() => onNavigateToTab('article')} className="hover:text-amber-600 font-medium transition">
          {isHindi ? "सूर्य हॉस्पिटल" : "Surya Hospital"}
        </button>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        <button onClick={() => onNavigateToTab('az-directory')} className="hover:text-amber-600 font-medium transition">
          {isHindi ? "A-Z रोग डायरेक्टरी" : "A-Z Diseases Encyclopedia"}
        </button>
        <ChevronRight className="w-3 h-3 text-slate-400" />
        <span className="text-slate-800 font-semibold truncate max-w-xs sm:max-w-md">
          {isHindi ? "हंतावायरस: लक्षण, कारण, उपचार एवं बचाव" : "Hantavirus: Symptoms, Causes, Treatment & Prevention"}
        </span>
      </nav>

      {/* Article Header Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm mb-8 relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-64 h-64 bg-gradient-to-bl from-amber-100/60 to-transparent rounded-full pointer-events-none" />
        
        {/* Category & Badge */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-4">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200">
            <Biohazard className="w-3.5 h-3.5 text-amber-700" />
            {isHindi ? "A-Z रोग · जूनोटिक वायरल गाइड" : article.meta.category}
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            {isHindi ? "चिकित्सकीय रूप से सत्यापित" : "Clinically Verified by Surya Medical Board"}
          </span>
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium text-slate-500 bg-slate-100">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            {article.meta.readTime}
          </span>
        </div>

        {/* Title & Subtitle */}
        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-4">
          {isHindi ? article.meta.hindiTitle : article.meta.title}
        </h1>
        <p className="text-slate-600 text-base sm:text-lg max-w-4xl font-normal leading-relaxed mb-6">
          {isHindi ? article.meta.hindiSubtitle : article.meta.subtitle}
        </p>

        {/* Medical Reviewer & Action Bar */}
        <div className="pt-6 border-t border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          {/* Reviewer Profile */}
          <div className="flex items-center gap-3">
            <img 
              src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=120&auto=format&fit=crop&q=80" 
              alt="Dr. Rajesh Suryavanshi" 
              className="w-12 h-12 rounded-full object-cover border-2 border-amber-500/40 shadow-sm"
            />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-slate-900">
                  {isHindi ? "डॉ. राजेश सूर्यवंशी, MD, FICP" : article.meta.reviewedBy.name}
                </span>
                <span className="text-[10px] bg-slate-100 text-slate-700 font-bold px-1.5 py-0.5 rounded">
                  {isHindi ? "समीक्षक" : "Reviewer"}
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {isHindi ? "विभागाध्यक्ष - संक्रामक रोग एवं आईसीयू, सूर्य हॉस्पिटल" : article.meta.reviewedBy.role} · {article.meta.updatedDate}
              </p>
            </div>
          </div>

          {/* Quick Utility Buttons */}
          <div className="flex items-center gap-2 self-stretch sm:self-auto flex-wrap">
            <button
              onClick={() => setLargeFont(!largeFont)}
              className="px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition"
              title="Toggle Font Size"
            >
              {largeFont ? 'A- (Normal)' : 'A+ (Large)'}
            </button>
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition"
            >
              <Share2 className="w-3.5 h-3.5 text-slate-500" />
              <span>{copiedLink ? (isHindi ? "लिंक कॉपी हो गया!" : "Copied!") : (isHindi ? "शेयर करें" : "Share")}</span>
            </button>
            <button
              onClick={handlePrint}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 text-xs font-semibold text-slate-700 transition"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>{isHindi ? "प्रिंट गाइड" : "Print PDF"}</span>
            </button>
            <button
              onClick={() => onOpenAppointment('Infectious Diseases', 'Dr. Rajesh Suryavanshi')}
              className="flex items-center gap-1.5 bg-amber-600 hover:bg-amber-700 text-white px-4 py-1.5 rounded-lg text-xs font-bold shadow-sm transition"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>{isHindi ? "डॉक्टर परामर्श" : "Consult Specialist"}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Article Body (Left/Center) + Sidebar (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Main In-Depth Article (8 Cols) */}
        <article className="lg:col-span-8 space-y-10">
          
          {/* Quick Clinical Takeaways Card */}
          <section className="bg-gradient-to-br from-amber-50/90 via-orange-50/50 to-white border border-amber-200/80 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-2 text-amber-900 font-bold text-base sm:text-lg mb-3">
              <Sparkles className="w-5 h-5 text-amber-600" />
              <h2>{isHindi ? "मुख्य बिंदु एवं त्वरित क्लिनिकल सार (Key Takeaways)" : "Key Clinical Summary & Highlights"}</h2>
            </div>
            <ul className="space-y-2.5">
              {article.summaryPoints.map((point, idx) => (
                <li key={idx} className="flex items-start gap-2.5 text-slate-700 text-sm sm:text-base leading-relaxed">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-1" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* Quick Table of Contents (Mobile & Tablet Jump Menu) */}
          <section className="bg-slate-50 border border-slate-200 rounded-xl p-5">
            <h3 className="text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-amber-600" />
              <span>{isHindi ? "विषय सूची (Table of Contents)" : "Table of Contents - Jump to Topic"}</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm">
              {article.tableOfContents.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-left py-1.5 px-2.5 rounded-lg hover:bg-amber-100 hover:text-amber-900 text-slate-700 font-medium transition flex items-center justify-between group"
                >
                  <span className="truncate">{isHindi ? item.hindiTitle : item.title}</span>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-600 flex-shrink-0" />
                </button>
              ))}
            </div>
          </section>

          {/* SECTION 1: What is Hantavirus? */}
          <section id="what-is-hantavirus" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <Biohazard className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "1. हंतावायरस क्या है? (What is Hantavirus?)" : "1. What is Hantavirus?"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed">
              <strong>Hantaviruses</strong> are a family of enveloped, single-stranded negative-sense RNA viruses belonging to the order <em>Bunyavirales</em>. Unlike most other bunyaviruses that are arthropod-borne (transmitted by mosquitoes or ticks), hantaviruses are <strong>exclusively rodent-borne zoonoses</strong>. Each specific hantavirus species has co-evolved with a distinct rodent reservoir host—such as deer mice, white-footed mice, cotton rats, or bank voles.
            </p>
            <p className="text-slate-700 leading-relaxed">
              In their natural rodent hosts, hantaviruses cause chronic, asymptomatic infections without harming the rodent. However, when transmitted to humans, they can provoke massive, dysregulated immune cascades and vascular endothelial leakage, causing two severe and potentially fatal clinical syndromes:
            </p>

            {/* Two Syndromes Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-4">
                <div className="flex items-center gap-2 text-rose-900 font-bold mb-1">
                  <Wind className="w-4 h-4 text-rose-600" />
                  <h4>Hantavirus Pulmonary Syndrome (HPS)</h4>
                </div>
                <p className="text-xs sm:text-sm text-slate-700">
                  Primarily prevalent across the Americas. Characterized by sudden, fulminant non-cardiogenic pulmonary edema where fluid leaks into lung alveoli, causing rapid respiratory distress with mortality rates reaching <strong>35% to 40%</strong> without prompt mechanical ventilation.
                </p>
              </div>

              <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-4">
                <div className="flex items-center gap-2 text-blue-900 font-bold mb-1">
                  <Droplets className="w-4 h-4 text-blue-600" />
                  <h4>Hemorrhagic Fever with Renal Syndrome (HFRS)</h4>
                </div>
                <p className="text-xs sm:text-sm text-slate-700">
                  More common across Asia (including regional pockets in India and East Asia) and Europe. Characterized by intense fever, acute kidney injury (AKI), oliguria, retroperitoneal hemorrhage, and severe hypotension with a mortality rate of <strong>1% to 15%</strong> depending on the viral strain.
                </p>
              </div>
            </div>
          </section>

          {/* SECTION 2: Causes & How It Spreads */}
          <section id="transmission-causes" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <Bug className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "2. संक्रमण के कारण और फैलाव (Transmission & Causes)" : "2. Causes & How Hantavirus Spreads"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Rodents shed the live virus continuously in their <strong>saliva, urine, and droppings</strong>. The primary mechanism of human infection is <strong>airborne inhalation of microscopic viral aerosols</strong>.
            </p>

            {/* Aerosol Mechanism Infobox */}
            <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-xl">
              <div className="flex items-center gap-2 font-bold text-amber-900 mb-1">
                <AlertCircle className="w-5 h-5 text-amber-600" />
                <span>The Aerosolization Danger: Why Sweeping Is Catastrophic</span>
              </div>
              <p className="text-sm text-slate-700 leading-relaxed">
                When rodent droppings or urine dry out inside dark, undisturbed spaces (like attics, closed farmhouses, storage cabins, sheds, and garages), the viral particles remain stable for several days. When someone enters and sweeps with a dry broom or runs a domestic vacuum cleaner, the dust is churned into microscopic airborne droplets. Inhaling this contaminated air transports the virus directly into the alveolar sacs of your lungs.
              </p>
            </div>

            {/* Transmission Pathways Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <span className="w-8 h-8 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center font-bold text-sm mb-2">1</span>
                <h5 className="font-bold text-slate-900 text-sm mb-1">Aerosol Inhalation (90%+)</h5>
                <p className="text-xs text-slate-600">
                  Breathing dust containing dried rodent urine or droppings during cleaning or renovating unventilated spaces.
                </p>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <span className="w-8 h-8 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center font-bold text-sm mb-2">2</span>
                <h5 className="font-bold text-slate-900 text-sm mb-1">Direct Contact & Mucosa</h5>
                <p className="text-xs text-slate-600">
                  Touching contaminated surfaces and subsequently touching the eyes, nose, or mouth before washing hands.
                </p>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <span className="w-8 h-8 rounded-lg bg-orange-100 text-orange-700 flex items-center justify-center font-bold text-sm mb-2">3</span>
                <h5 className="font-bold text-slate-900 text-sm mb-1">Rodent Bites & Bites (&lt;2%)</h5>
                <p className="text-xs text-slate-600">
                  Rare direct bites from wild mice or handling trapped rodents without protective puncture-resistant gloves.
                </p>
              </div>
            </div>

            {/* Note on Human to Human */}
            <div className="bg-slate-100 rounded-xl p-4 text-xs sm:text-sm text-slate-700 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Is it contagious between people?</strong> In nearly all clinical scenarios, Hantavirus cannot be transmitted from person to person. You cannot catch Hantavirus from casual contact with an infected person. (The only documented exception is the Andes strain in South America among close household contacts).
              </span>
            </div>
          </section>

          {/* SECTION 3: Symptoms & Clinical Timeline */}
          <section id="symptoms-timeline" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <HeartPulse className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "3. लक्षण एवं चरणबद्ध समयसीमा (Symptoms & Clinical Stages)" : "3. Symptoms & Clinical Stages"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Hantavirus disease progresses through distinct clinical phases. Because the incubation period spans <strong>1 to 8 weeks</strong> (median 14–21 days), patients frequently do not recall their exposure by the time severe symptoms strike.
            </p>

            {/* Timeline Cards */}
            <div className="space-y-4">
              {article.stages.map((stage, idx) => (
                <div 
                  key={idx} 
                  className={`border rounded-2xl p-5 sm:p-6 transition ${
                    stage.severity === 'Critical' 
                      ? 'bg-rose-50/60 border-rose-200' 
                      : stage.severity === 'Emergency'
                      ? 'bg-orange-50/60 border-orange-200'
                      : 'bg-amber-50/50 border-amber-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded text-xs font-bold ${
                        stage.severity === 'Critical' 
                          ? 'bg-rose-600 text-white' 
                          : stage.severity === 'Emergency'
                          ? 'bg-orange-600 text-white'
                          : 'bg-amber-600 text-white'
                      }`}>
                        {stage.phase}
                      </span>
                      <span className="text-xs font-semibold text-slate-500">
                        {stage.timeframe}
                      </span>
                    </div>
                    <span className="text-xs font-bold text-slate-700">{stage.title}</span>
                  </div>

                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
                    {stage.symptoms.map((sym, sIdx) => (
                      <li key={sIdx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-800">
                        <AlertTriangle className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                          stage.severity === 'Critical' ? 'text-rose-600' : 'text-amber-600'
                        }`} />
                        <span>{sym}</span>
                      </li>
                    ))}
                  </ul>

                  <div className="pt-2 border-t border-slate-200/60 text-xs text-slate-600 italic">
                    <strong>Surya Clinical Note:</strong> {stage.clinicalNote}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION 4: HPS vs HFRS Comparison Table */}
          <section id="hps-vs-hfrs" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <FileText className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "4. HPS बनाम HFRS: दो मुख्य प्रकार" : "4. HPS vs HFRS: Comparison Matrix"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed text-sm">
              Depending on the geographic viral strain, the infection targets different end-organs:
            </p>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-xs sm:text-sm text-left border-collapse">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="p-3">Clinical Dimension</th>
                    <th className="p-3 text-rose-800 bg-rose-50/50">HPS (Pulmonary Syndrome)</th>
                    <th className="p-3 text-blue-800 bg-blue-50/50">HFRS (Renal Syndrome)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white text-slate-700">
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">Primary Target Organ</td>
                    <td className="p-3">Lungs & Pulmonary Microvasculature</td>
                    <td className="p-3">Kidneys, Vascular Endothelium & Platelets</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">Dominant Pathology</td>
                    <td className="p-3">Non-cardiogenic pulmonary edema & severe hypoxemia</td>
                    <td className="p-3">Acute tubular necrosis, oliguria & internal bleeding</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">Common Viral Strains</td>
                    <td className="p-3">Sin Nombre virus, Andes virus, Black Creek Canal</td>
                    <td className="p-3">Hantaan virus, Dobrava virus, Puumala, Seoul virus</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">Fatality Rate</td>
                    <td className="p-3 font-bold text-rose-700">30% to 38% (High)</td>
                    <td className="p-3 font-bold text-blue-700">1% to 15% (Strain dependent)</td>
                  </tr>
                  <tr>
                    <td className="p-3 font-semibold text-slate-900">Surya ICU Intervention</td>
                    <td className="p-3">Lung-protective ventilation, ECMO, fluid restriction</td>
                    <td className="p-3">CRRT Hemodialysis, platelet transfusions, BP support</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* SECTION 5: Diagnosis & Lab Workup at Surya Hospital */}
          <section id="diagnosis-tests" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <Stethoscope className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "5. जांच एवं डायग्नोस्टिक्स (Diagnosis at Surya Hospital)" : "5. Diagnosis & Lab Testing Protocol"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed">
              Because early hantavirus mimics influenza or dengue, rapid differential diagnosis is critical. Surya Hospital operates an on-site 24/7 NABL-accredited molecular virology and stat hematology lab to detect hallmarks within hours:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {article.diagnosticTests.map((t, idx) => (
                <div key={idx} className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:border-amber-400 transition">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <h4 className="font-bold text-sm text-slate-900">{t.testName}</h4>
                    <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                      {t.turnaround}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mb-2 leading-relaxed">{t.purpose}</p>
                  <div className="text-[11px] text-emerald-700 font-medium flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{t.suryaFacility}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Diagnostic Triad Card */}
            <div className="bg-slate-900 text-white rounded-xl p-5 text-xs sm:text-sm">
              <h4 className="font-bold text-amber-400 text-sm mb-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                <span>The Classic HPS Laboratory Diagnostic Triad</span>
              </h4>
              <p className="text-slate-300 leading-relaxed mb-3">
                In acute Hantavirus Pulmonary Syndrome, routine blood work frequently shows this pathognomonic triad before respiratory failure fully manifests:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="bg-slate-800 p-3 rounded-lg border border-slate-700">
                  <span className="text-amber-300 font-bold block mb-1">1. Severe Thrombocytopenia</span>
                  <span className="text-slate-300">Platelet count typically plummets rapidly below 100,000 / µL.</span>
                </div>
                <div className="bg-slate-800 p-3 rounded-lg border border-slate-700">
                  <span className="text-amber-300 font-bold block mb-1">2. Hemoconcentration</span>
                  <span className="text-slate-300">Elevated Hematocrit (HCT &gt; 50%) due to massive plasma leakage into alveoli.</span>
                </div>
                <div className="bg-slate-800 p-3 rounded-lg border border-slate-700">
                  <span className="text-amber-300 font-bold block mb-1">3. Atypical Lymphocytosis</span>
                  <span className="text-slate-300">Left-shift leukocytosis with &gt; 10% immunoblasts / atypical T-cells.</span>
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 6: Treatment & Intensive Care Management */}
          <section id="treatment-icu" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <Building className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "6. उपचार एवं सूर्य हॉस्पिटल आईसीयू प्रबंधन" : "6. Medical Treatment & Level-3 ICU Management"}</span>
              </h2>
            </div>
            <p className="text-slate-700 leading-relaxed">
              There is currently <strong>no definitive antiviral medication or cure</strong> proven effective for acute HPS. Ribavirin has shown modest benefit in early HFRS when given within the first 5 days, but has not demonstrated mortality reduction in cardiopulmonary HPS.
            </p>
            <p className="text-slate-700 leading-relaxed">
              Survival hinges entirely on <strong>rapid recognition and Level-3 Intensive Care Unit (MICU) management</strong> before irreversible shock sets in:
            </p>

            <div className="space-y-3">
              <div className="flex items-start gap-3 bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <Wind className="w-5 h-5 text-amber-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Lung-Protective Mechanical Ventilation</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Surya Hospital utilizes low tidal volume ventilation (6 mL/kg ideal body weight) with appropriate PEEP (Positive End-Expiratory Pressure) to oxygenate without causing secondary barotrauma to inflamed alveolar walls.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <Droplets className="w-5 h-5 text-blue-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Cautious Hemodynamic & Fluid Management</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Over-hydration is lethal in HPS because leaky pulmonary capillaries dump fluids straight into the airspaces. Our intensivists use continuous invasive arterial line and cardiac output monitoring, favoring early inotropes (norepinephrine, dobutamine) over aggressive crystalloids.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <HeartPulse className="w-5 h-5 text-rose-600 flex-shrink-0 mt-1" />
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">Extracorporeal Membrane Oxygenation (ECMO) Standby</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    For refractory hypoxemic respiratory failure (PaO2/FiO2 ratio &lt; 80) or severe cardiogenic shock, Surya Hospital provides Veno-Venous (VV) or Veno-Arterial (VA) ECMO life-support to oxygenate blood externally while the lungs heal.
                  </p>
                </div>
              </div>
            </div>
          </section>

          {/* SECTION 7: Safe Rodent Cleanup Protocol (CDC & WHO Guidelines) */}
          <section id="rodent-cleanup" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <ShieldAlert className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "7. चूहों के अपशिष्ट की सुरक्षित सफाई (CDC 5-Step Protocol)" : "7. Safe Rodent Cleanup Protocol (CDC Guidelines)"}</span>
              </h2>
            </div>
            
            <div className="bg-rose-50 border border-rose-300 rounded-xl p-4 text-rose-900 text-sm font-semibold flex items-center gap-3">
              <AlertTriangle className="w-6 h-6 text-rose-600 flex-shrink-0" />
              <span>
                CRITICAL WARNING: NEVER use a vacuum cleaner, electric blower, or dry broom to clean rodent droppings, nests, or dusty storage sheds. It instantly aerosolizes deadly viral particles!
              </span>
            </div>

            <div className="space-y-4 pt-2">
              {article.cleanupSteps.map((step) => (
                <div key={step.step} className="bg-white border border-slate-200 rounded-xl p-4 sm:p-5 shadow-sm">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="w-7 h-7 rounded-full bg-amber-500 text-white font-bold text-xs flex items-center justify-center flex-shrink-0">
                      {step.step}
                    </span>
                    <h4 className="font-bold text-slate-900 text-sm sm:text-base">{step.title}</h4>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed pl-10 mb-2">
                    {step.description}
                  </p>
                  {step.warning && (
                    <div className="ml-10 p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-xs text-amber-900 font-medium flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                      <span>{step.warning}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* SECTION 8: Prevention Guidelines */}
          <section id="prevention-tips" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <span>{isHindi ? "8. दीर्घकालिक बचाव एवं सावधानियां" : "8. Long-Term Prevention Guidelines"}</span>
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Rodent-Proof Your Property</span>
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Seal all exterior holes larger than 6 mm (size of a pencil eraser) using steel wool, metal screening, and cement caulking. Mice can squeeze through dime-sized gaps.
                </p>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Secure Food Supplies</span>
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Store human grains, pet food, and livestock feed in airtight, rodent-proof metal or heavy glass containers with tight lids. Clean food crumbs immediately.
                </p>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Clear Surrounding Perimeter</span>
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Remove woodpiles, brush, trash heaps, and tall weeds within 100 feet of home foundations to eliminate rodent nesting harborage.
                </p>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm">
                <h4 className="font-bold text-slate-900 text-sm mb-2 flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Safe Outdoor Camping Habits</span>
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  Never pitch tents near rodent burrows, woodpiles, or garbage dumps. Do not sleep directly on bare ground; use a tent with a raised, zipped floor.
                </p>
              </div>
            </div>
          </section>

          {/* SECTION 9: When to Seek Emergency Care */}
          <section id="when-to-see-doctor" className="scroll-mt-24">
            <div className="bg-gradient-to-r from-rose-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md">
              <div className="flex items-center gap-3 mb-4">
                <ShieldAlert className="w-7 h-7 text-rose-400 animate-pulse" />
                <h2 className="text-xl sm:text-2xl font-extrabold text-white">
                  {isHindi ? "तुरंत आपातकालीन चिकित्सा कब लें?" : "When to Seek Immediate Emergency Medical Care"}
                </h2>
              </div>
              <p className="text-slate-200 text-sm sm:text-base leading-relaxed mb-5">
                If you have a history of rodent exposure (such as cleaning sheds, opening cabins, or rural farming) and develop any of the following <strong>Red-Flag Symptoms</strong>, proceed immediately to the Surya Hospital 24/7 Emergency & Trauma Centre:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm text-slate-100 mb-6">
                <div className="flex items-center gap-2 bg-rose-950/60 p-2.5 rounded-lg border border-rose-800">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>Sudden acute shortness of breath or rapid panting</span>
                </div>
                <div className="flex items-center gap-2 bg-rose-950/60 p-2.5 rounded-lg border border-rose-800">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>SpO2 oxygen saturation dropping below 93% on room air</span>
                </div>
                <div className="flex items-center gap-2 bg-rose-950/60 p-2.5 rounded-lg border border-rose-800">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>High fever with intense thigh/back muscle aches</span>
                </div>
                <div className="flex items-center gap-2 bg-rose-950/60 p-2.5 rounded-lg border border-rose-800">
                  <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                  <span>Sharp drop in urine volume (sign of renal failure)</span>
                </div>
              </div>
              
              <div className="flex flex-wrap items-center gap-4">
                <button
                  onClick={onOpenEmergency}
                  className="bg-rose-500 hover:bg-rose-600 text-white font-extrabold px-6 py-3 rounded-xl text-sm shadow-lg shadow-rose-900/50 flex items-center gap-2 transition"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>Emergency Hotline: {SURYA_HOSPITAL.emergencyPhone}</span>
                </button>
                <span className="text-xs text-slate-400">
                  Priority Ambulance & ICU Bed Dispatch available 24 hours.
                </span>
              </div>
            </div>
          </section>

          {/* SECTION 10: Frequently Asked Questions (Accordion) */}
          <section id="faqs" className="scroll-mt-24 space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2.5">
                <HelpCircle className="w-6 h-6 text-amber-600" />
                <span>{isHindi ? "10. अक्सर पूछे जाने वाले सवाल (FAQs)" : "10. Frequently Asked Questions"}</span>
              </h2>
            </div>
            
            <div className="space-y-3">
              {article.faqs.map((faq, idx) => (
                <div 
                  key={idx} 
                  className="border border-slate-200 rounded-xl bg-white overflow-hidden transition"
                >
                  <button
                    onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                    className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-3 hover:bg-slate-50 transition"
                  >
                    <span className="font-bold text-slate-900 text-sm sm:text-base">
                      {isHindi ? faq.hindiQuestion : faq.question}
                    </span>
                    <ChevronDown className={`w-5 h-5 text-slate-400 flex-shrink-0 transition-transform ${
                      openFaqIndex === idx ? 'transform rotate-180 text-amber-600' : ''
                    }`} />
                  </button>
                  
                  {openFaqIndex === idx && (
                    <div className="px-4 pb-4 sm:px-5 sm:pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100 pt-3">
                      {isHindi ? faq.hindiAnswer : faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

        </article>

        {/* RIGHT COLUMN: Interactive Sidebar (4 Cols) */}
        <aside className="lg:col-span-4 space-y-6">
          
          {/* Quick Interactive Symptom & Exposure Screener */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 text-slate-900 font-bold text-base mb-1">
              <UserCheck className="w-5 h-5 text-amber-600" />
              <h3>{isHindi ? "त्वरित लक्षण जांच टूल" : "Self-Triage Risk Screener"}</h3>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              {isHindi ? "क्या आपमें हंतावायरस के लक्षण हैं? तुरंत जांचें:" : "Assess your risk based on exposure and early symptoms:"}
            </p>

            <div className="space-y-3 mb-4 text-xs sm:text-sm text-slate-800">
              <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition">
                <input 
                  type="checkbox" 
                  checked={screenerRodent} 
                  onChange={(e) => {
                    setScreenerRodent(e.target.checked);
                    setScreenerSubmitted(true);
                  }}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500"
                />
                <span>Recent exposure to rodents, sheds, or dusty cabins within past 1-6 weeks</span>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition">
                <input 
                  type="checkbox" 
                  checked={screenerFever} 
                  onChange={(e) => {
                    setScreenerFever(e.target.checked);
                    setScreenerSubmitted(true);
                  }}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500"
                />
                <span>Unexplained high fever (&gt;101°F) and severe thigh/back muscle aches</span>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 cursor-pointer transition">
                <input 
                  type="checkbox" 
                  checked={screenerBreathing} 
                  onChange={(e) => {
                    setScreenerBreathing(e.target.checked);
                    setScreenerSubmitted(true);
                  }}
                  className="mt-0.5 rounded text-amber-600 focus:ring-amber-500"
                />
                <span>Shortness of breath, dry cough, or low oxygen saturation (SpO2)</span>
              </label>
            </div>

            {/* Screener Result Calculation */}
            {screenerSubmitted && (
              <div className={`p-3.5 rounded-xl border mb-4 text-xs ${getScreenerResult().color}`}>
                <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider mb-1.5 ${getScreenerResult().badgeColor}`}>
                  {getScreenerResult().level}
                </span>
                <p className="leading-relaxed mb-3">{getScreenerResult().text}</p>
                <button
                  onClick={getScreenerResult().action}
                  className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2 px-3 rounded-lg flex items-center justify-center gap-1.5 transition text-xs shadow"
                >
                  <span>{getScreenerResult().actionText}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            <button 
              onClick={() => onNavigateToTab('screener')}
              className="w-full text-center text-xs text-amber-700 hover:text-amber-800 font-semibold pt-1 transition flex items-center justify-center gap-1"
            >
              <span>{isHindi ? "विस्तृत लक्षण आकलन खोलें" : "Open Full Interactive Diagnostic Tool"}</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Recommended Surya Diagnostic Packages */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
                <HeartPulse className="w-5 h-5 text-amber-600" />
                <h3>{isHindi ? "अनुशंसित स्वास्थ्य पैकेज" : "Recommended Health Checkups"}</h3>
              </div>
              <button 
                onClick={() => onNavigateToTab('packages')} 
                className="text-xs text-amber-700 hover:text-amber-800 font-bold"
              >
                {isHindi ? "सभी देखें" : "View All"}
              </button>
            </div>

            {SURYA_HEALTH_PACKAGES.slice(0, 2).map((pkg) => (
              <div key={pkg.id} className="border border-slate-200 rounded-xl p-3.5 hover:border-amber-400 transition bg-slate-50/50">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-bold text-xs sm:text-sm text-slate-900 line-clamp-2">
                    {isHindi ? pkg.hindiName : pkg.name}
                  </h4>
                </div>
                <p className="text-[11px] text-slate-500 mb-2">{pkg.tagline}</p>
                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="text-base font-extrabold text-slate-900">₹{pkg.price}</span>
                    <span className="text-xs text-slate-400 line-through ml-1.5">₹{pkg.originalPrice}</span>
                  </div>
                  <button
                    onClick={() => onOpenAppointment(pkg.category, pkg.name)}
                    className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-3 py-1 rounded text-xs transition"
                  >
                    Book Test
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Specialist Doctors on Duty Card */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-900 font-bold text-base">
                <Stethoscope className="w-5 h-5 text-amber-600" />
                <h3>{isHindi ? "संबंधित विशेषज्ञ डॉक्टर" : "Consulting Specialists"}</h3>
              </div>
              <button 
                onClick={() => onNavigateToTab('doctors')} 
                className="text-xs text-amber-700 hover:text-amber-800 font-bold"
              >
                {isHindi ? "सभी देखें" : "All Doctors"}
              </button>
            </div>

            {SURYA_DOCTORS.slice(0, 2).map((doc) => (
              <div key={doc.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-100 bg-slate-50">
                <img 
                  src={doc.image} 
                  alt={doc.name} 
                  className="w-12 h-12 rounded-full object-cover border border-slate-200"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                    {isHindi && doc.hindiName ? doc.hindiName : doc.name}
                  </h4>
                  <p className="text-[11px] text-amber-700 font-medium truncate">{doc.department}</p>
                  <p className="text-[10px] text-slate-500">{doc.opdTimings}</p>
                </div>
                <button
                  onClick={() => onOpenAppointment(doc.department, doc.name)}
                  className="bg-white border border-slate-300 hover:border-amber-500 hover:bg-amber-50 text-slate-800 font-semibold px-2.5 py-1 rounded text-xs transition flex-shrink-0"
                >
                  Book
                </button>
              </div>
            ))}
          </div>

          {/* Surya 24/7 Emergency Support Banner */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-5 shadow-sm">
            <div className="flex items-center gap-2 font-bold text-sm text-rose-400 mb-1">
              <ShieldAlert className="w-4 h-4 animate-pulse" />
              <span>Surya 24/7 Casualty & Trauma</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              Level-3 Negative Pressure Isolation Suites & High-Frequency Ventilators standing by.
            </p>
            <div className="space-y-2">
              <button
                onClick={onOpenEmergency}
                className="w-full bg-rose-600 hover:bg-rose-700 text-white font-bold py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 transition"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Call Emergency: {SURYA_HOSPITAL.emergencyPhone}</span>
              </button>
              <button
                onClick={() => onNavigateToTab('az-directory')}
                className="w-full bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium py-2 rounded-lg text-xs flex items-center justify-center gap-1.5 transition"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                <span>Browse A-Z Disease Library</span>
              </button>
            </div>
          </div>

        </aside>
      </div>

    </div>
  );
};
