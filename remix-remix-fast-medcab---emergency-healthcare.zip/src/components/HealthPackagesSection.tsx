import React, { useState } from 'react';
import { 
  Package, 
  CheckCircle2, 
  Clock, 
  Droplets, 
  Sparkles, 
  Calendar, 
  Home, 
  Building2, 
  ShieldCheck, 
  HelpCircle,
  FileCheck
} from 'lucide-react';
import { SURYA_HEALTH_PACKAGES } from '../data/suryaHospitalData';
import { HealthPackageItem } from '../types';

interface HealthPackagesSectionProps {
  onBookPackage: (packageName: string) => void;
  isHindi: boolean;
}

export const HealthPackagesSection: React.FC<HealthPackagesSectionProps> = ({
  onBookPackage,
  isHindi
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedPkgId, setExpandedPkgId] = useState<string | null>(null);

  const categories = ['All', 'Infectious & Tropical', 'Pulmonology', 'Preventive Wellness', 'Seasonal & Zoonotic'];

  const filteredPackages = selectedCategory === 'All'
    ? SURYA_HEALTH_PACKAGES
    : SURYA_HEALTH_PACKAGES.filter(p => p.category === selectedCategory);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header Banner */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200 mb-3">
          <Package className="w-3.5 h-3.5 text-amber-700" />
          <span>{isHindi ? "प्रिवेंटिव हेल्थ चेकअप एवं डायग्नोस्टिक्स" : "Surya Preventive Health & Diagnostic Checkups"}</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
          {isHindi ? "किफायती एवं व्यापक हेल्थ चेकअप पैकेज" : "Comprehensive Health Screening & Viral Panels"}
        </h2>
        <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
          {isHindi
            ? "वायरल फीवर, फेफड़ों की जांच, जूनोटिक संक्रमण और संपूर्ण शारीरिक स्वास्थ्य के लिए सूर्य हॉस्पिटल के एनएबीएल-मान्यता प्राप्त पैकेज।"
            : "Precision pathology profiles, early pathogen detection, respiratory assessments, and annual master checkups with free home sample collection across the city."}
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition border whitespace-nowrap ${
              selectedCategory === cat
                ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Package Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {filteredPackages.map((pkg) => {
          const isExpanded = expandedPkgId === pkg.id;
          return (
            <div
              key={pkg.id}
              className={`bg-white rounded-3xl border transition-all flex flex-col justify-between overflow-hidden shadow-sm hover:shadow-md ${
                pkg.popular ? 'border-amber-400 ring-2 ring-amber-400/20' : 'border-slate-200'
              }`}
            >
              {/* Card Top */}
              <div className="p-6 sm:p-7 flex-1">
                <div className="flex items-center justify-between gap-2 mb-3">
                  <span className="text-[11px] font-bold text-slate-600 bg-slate-100 px-3 py-1 rounded-full">
                    {pkg.category}
                  </span>
                  {pkg.popular && (
                    <span className="inline-flex items-center gap-1 text-[11px] font-extrabold bg-amber-500 text-white px-2.5 py-0.5 rounded-full shadow-xs">
                      <Sparkles className="w-3 h-3" />
                      Most Popular
                    </span>
                  )}
                </div>

                <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2">
                  {isHindi ? pkg.hindiName : pkg.name}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-4">
                  {pkg.tagline}
                </p>

                {/* Badges: Parameters, Fasting, TAT */}
                <div className="grid grid-cols-3 gap-2 py-3 border-y border-slate-100 text-center mb-4 bg-slate-50 rounded-xl p-2">
                  <div>
                    <span className="text-base font-extrabold text-amber-600 block">{pkg.testsCount}+</span>
                    <span className="text-[10px] text-slate-500 font-medium">Parameters</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 block truncate">{pkg.turnaroundTime.split('(')[0]}</span>
                    <span className="text-[10px] text-slate-500 font-medium">Turnaround</span>
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 block truncate">{pkg.fastingRequired.includes('Not') || pkg.fastingRequired.includes('No') ? 'No Fasting' : 'Fasting Req.'}</span>
                    <span className="text-[10px] text-slate-500 font-medium">Preparation</span>
                  </div>
                </div>

                {/* Recommended For Note */}
                <div className="mb-4 text-xs text-slate-600 bg-amber-50/70 border border-amber-200/60 p-2.5 rounded-xl">
                  <strong className="text-amber-900">Recommended for: </strong>
                  <span>{pkg.recommendedFor}</span>
                </div>

                {/* Parameters List (Collapsible) */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      Included Diagnostic Tests:
                    </span>
                    <button
                      onClick={() => setExpandedPkgId(isExpanded ? null : pkg.id)}
                      className="text-xs text-amber-700 hover:text-amber-800 font-bold"
                    >
                      {isExpanded ? "Hide Details" : `View All (${pkg.parameters.length})`}
                    </button>
                  </div>
                  
                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {(isExpanded ? pkg.parameters : pkg.parameters.slice(0, 4)).map((param, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
                        <span>{param}</span>
                      </li>
                    ))}
                  </ul>
                  {!isExpanded && pkg.parameters.length > 4 && (
                    <p className="text-[11px] text-slate-400 mt-1 pl-5">
                      + {pkg.parameters.length - 4} more specialized tests included
                    </p>
                  )}
                </div>
              </div>

              {/* Price & Book CTA Bottom */}
              <div className="p-5 sm:p-6 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-black text-slate-900">₹{pkg.price}</span>
                    <span className="text-xs text-slate-400 line-through">₹{pkg.originalPrice}</span>
                    <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                      {pkg.discountPercentage}% OFF
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-500">Free Home Sample Collection or Hospital Visit</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onBookPackage(pkg.name)}
                    className="flex-1 sm:flex-initial bg-amber-600 hover:bg-amber-700 text-white font-bold px-6 py-2.5 rounded-xl text-xs sm:text-sm transition shadow-sm flex items-center justify-center gap-2"
                  >
                    <Calendar className="w-4 h-4" />
                    <span>{isHindi ? "पैकेज बुक करें" : "Book Package"}</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Surya Diagnostics Quality Promise */}
      <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-bold text-sm text-white mb-1">NABL Accredited Quality</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              100% automated analyzers with daily two-level internal quality control and clinical pathologist sign-off.
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <Home className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-bold text-sm text-white mb-1">Safe Home Sample Collection</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Trained phlebotomists with sealed vacutainers and temperature-monitored cold-chain transport to the lab.
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <FileCheck className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-bold text-sm text-white mb-1">Fast Digital & WhatsApp Reports</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Instant PDF report delivery via SMS/WhatsApp with complimentary specialist consultation review.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
