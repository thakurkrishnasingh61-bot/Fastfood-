import React, { useState } from 'react';
import { 
  Star, 
  CheckCircle2, 
  ThumbsUp, 
  PenLine, 
  ExternalLink, 
  MapPin, 
  Filter,
  X
} from 'lucide-react';
import { GOOGLE_REVIEWS_DATA, ReviewItem, HOSPITAL_INFO } from '../data/hospitalData';

interface GoogleReviewsSectionProps {
  isHindi: boolean;
}

export const GoogleReviewsSection: React.FC<GoogleReviewsSectionProps> = ({ isHindi }) => {
  const [reviewsList, setReviewsList] = useState<ReviewItem[]>(GOOGLE_REVIEWS_DATA);
  const [writeModalOpen, setWriteModalOpen] = useState(false);
  const [newAuthor, setNewAuthor] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newTreatment, setNewTreatment] = useState('Emergency & ICU');
  const [newReviewText, setNewReviewText] = useState('');
  const [submittedMessage, setSubmittedMessage] = useState(false);
  const [filterTreatment, setFilterTreatment] = useState<string>('ALL');
  const [likedIds, setLikedIds] = useState<Set<string>>(new Set());

  const handleToggleLike = (id: string) => {
    setLikedIds(prev => {
      const next = new Set(prev);
      const isAlreadyLiked = next.has(id);
      if (isAlreadyLiked) {
        next.delete(id);
      } else {
        next.add(id);
      }
      setReviewsList(currentList => 
        currentList.map(item => {
          if (item.id === id) {
            return {
              ...item,
              likes: isAlreadyLiked ? Math.max(0, item.likes - 1) : item.likes + 1
            };
          }
          return item;
        })
      );
      return next;
    });
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newReviewText.trim()) return;

    const newRev: ReviewItem = {
      id: `rev-${Date.now()}`,
      author: newAuthor.trim(),
      initials: newAuthor.trim().slice(0, 2).toUpperCase(),
      rating: newRating,
      timeAgo: 'Just now',
      verified: true,
      content: newReviewText.trim(),
      treatment: newTreatment,
      likes: 1
    };

    setReviewsList([newRev, ...reviewsList]);
    setSubmittedMessage(true);
    setTimeout(() => {
      setSubmittedMessage(false);
      setWriteModalOpen(false);
      setNewAuthor('');
      setNewReviewText('');
    }, 1800);
  };

  const filteredReviews = filterTreatment === 'ALL'
    ? reviewsList
    : reviewsList.filter(r => r.treatment.toLowerCase().includes(filterTreatment.toLowerCase()));

  const googleMapsUrl = `https://www.google.com/maps/search/?api=1&query=Nova+Shekhar+Hospital+MGIMT+Campus+Banthara+Kanpur+Road+Uttar+Pradesh`;

  return (
    <section id="reviews" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Google Business Header Badge */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-10 shadow-sm mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Rating Summary */}
            <div className="lg:col-span-5 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black tracking-wider uppercase text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
                  Google Business Profile
                </span>
                <span className="text-xs text-slate-500 font-medium">Verified Reviews</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-black text-slate-900">
                NOVA SHEKHAR HOSPITAL
              </h2>
              
              <p className="text-slate-600 text-sm flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                <span>Hospital in Khandedev, Banthara, Uttar Pradesh 226401</span>
              </p>

              {/* Big Star Display */}
              <div className="flex items-baseline gap-4 pt-2">
                <div className="text-5xl font-black text-slate-900">5.04</div>
                <div>
                  <div className="flex items-center text-amber-400">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <Star key={s} className="w-5 h-5 fill-amber-400" />
                    ))}
                  </div>
                  <div className="text-xs text-slate-500 font-semibold mt-1">
                    Based on 100% 5-Star Google ratings
                  </div>
                </div>
              </div>
            </div>

            {/* Middle: Rating breakdown */}
            <div className="lg:col-span-4 space-y-2 border-y lg:border-y-0 lg:border-x border-slate-200 py-4 lg:py-0 lg:px-8">
              <div className="text-xs font-bold text-slate-700 mb-2">Rating Distribution:</div>
              <div className="space-y-1.5 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-3 font-bold text-slate-700">5</span>
                  <div className="flex-1 h-2.5 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full w-full"></div>
                  </div>
                  <span className="w-8 text-right font-medium text-slate-600">100%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 font-bold text-slate-700">4</span>
                  <div className="flex-1 h-2.5 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full w-0"></div>
                  </div>
                  <span className="w-8 text-right font-medium text-slate-400">0%</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 font-bold text-slate-700">3</span>
                  <div className="flex-1 h-2.5 rounded-full bg-slate-100 overflow-hidden">
                    <div className="h-full bg-amber-400 rounded-full w-0"></div>
                  </div>
                  <span className="w-8 text-right font-medium text-slate-400">0%</span>
                </div>
              </div>
              <div className="pt-2 text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Highest rated hospital on Kanpur Road corridor</span>
              </div>
            </div>

            {/* Right: Actions (Write Review, Open Maps) */}
            <div className="lg:col-span-3 flex flex-col gap-3">
              <button
                onClick={() => setWriteModalOpen(true)}
                className="w-full py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition"
              >
                <PenLine className="w-4 h-4" />
                <span>Write a Review</span>
              </button>

              <a
                href={googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2.5 px-4 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 font-semibold text-xs flex items-center justify-center gap-2 transition"
              >
                <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                <span>View on Google Maps</span>
              </a>

              <p className="text-[11px] text-center text-slate-400">
                Live feedback from local Banthara & highway patients
              </p>
            </div>

          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            <span className="text-xs font-bold text-slate-500 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5" />
              <span>Department:</span>
            </span>
            {['ALL', 'Emergency', 'Eye', 'Dialysis', 'Maternity'].map((cat) => (
              <button
                key={cat}
                onClick={() => setFilterTreatment(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                  filterTreatment === cat
                    ? 'bg-slate-900 text-white shadow-sm'
                    : 'bg-white hover:bg-slate-200 text-slate-700 border border-slate-200'
                }`}
              >
                {cat === 'ALL' ? 'All Reviews' : cat}
              </button>
            ))}
          </div>

          <div className="text-xs text-slate-500 font-medium">
            Showing <strong className="text-slate-800">{filteredReviews.length}</strong> patient experiences
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredReviews.map((review) => (
            <div 
              key={review.id}
              className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition space-y-4 flex flex-col justify-between"
            >
              <div className="space-y-3">
                
                {/* Author row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-indigo-700 text-white font-black text-sm flex items-center justify-center shadow-sm">
                      {review.initials}
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{review.author}</h4>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400">
                        <span>{review.timeAgo}</span>
                        <span>•</span>
                        <span className="text-emerald-700 font-semibold flex items-center gap-0.5">
                          <CheckCircle2 className="w-3 h-3" /> Verified Patient
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center text-amber-400">
                    {[...Array(review.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400" />
                    ))}
                  </div>
                </div>

                {/* Treatment Badge */}
                <div className="inline-block px-2.5 py-0.5 rounded-md bg-blue-50 border border-blue-200 text-blue-800 font-semibold text-[11px]">
                  Treated for: {review.treatment}
                </div>

                {/* Review Text */}
                <p className="text-slate-700 text-sm leading-relaxed italic">
                  "{review.content}"
                </p>

              </div>

              {/* Bottom bar */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
                <button
                  type="button"
                  onClick={() => handleToggleLike(review.id)}
                  className={`flex items-center gap-1.5 px-2 py-1 rounded-md transition ${
                    likedIds.has(review.id)
                      ? 'bg-blue-50 text-blue-700 font-bold'
                      : 'hover:bg-slate-100 hover:text-slate-700 text-slate-500'
                  }`}
                  title="Mark this review as helpful"
                >
                  <ThumbsUp className={`w-3.5 h-3.5 ${likedIds.has(review.id) ? 'fill-blue-600 text-blue-600' : ''}`} />
                  <span>Helpful ({review.likes})</span>
                </button>
                <span className="text-[11px] text-slate-400">Posted on Google</span>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Write a Review Modal */}
      {writeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
            <button
              onClick={() => setWriteModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            {submittedMessage ? (
              <div className="text-center py-8 space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-slate-900">Thank You for Your Review!</h3>
                <p className="text-slate-600 text-xs">
                  Your 5-star rating for Nova Shekhar Hospital has been recorded.
                </p>
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <div>
                  <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">Nova Shekhar Hospital</span>
                  <h3 className="text-xl font-black text-slate-900 mt-0.5">Write a Patient Review</h3>
                  <p className="text-slate-500 text-xs mt-1">
                    Help other patients in Banthara, Khandedev & Kanpur Road find quality healthcare.
                  </p>
                </div>

                {/* Rating selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">Rating</label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setNewRating(star)}
                        className="p-1 hover:scale-110 transition"
                      >
                        <Star 
                          className={`w-7 h-7 ${
                            star <= newRating ? 'text-amber-400 fill-amber-400' : 'text-slate-300'
                          }`} 
                        />
                      </button>
                    ))}
                    <span className="text-xs font-bold text-slate-700 ml-2">{newRating} Stars</span>
                  </div>
                </div>

                {/* Patient Name */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Your Name / Guardian Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Rajesh Kumar (Banthara)"
                    value={newAuthor}
                    onChange={(e) => setNewAuthor(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Treatment Category */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Department / Treatment</label>
                  <select
                    value={newTreatment}
                    onChange={(e) => setNewTreatment(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    <option value="Emergency & ICU">Emergency & ICU Care</option>
                    <option value="Phaco Cataract Eye Surgery">Nova Eye Hospital (Cataract / Vision)</option>
                    <option value="Hemodialysis Unit">Hemodialysis & Kidney Care</option>
                    <option value="Modular OT & Surgery">Modular Operation Theatre (Surgery)</option>
                    <option value="Maternity & Delivery">Gynecologist & Delivery</option>
                    <option value="General Medicine & Fever">General Medicine (Fever / Dengue / BP)</option>
                  </select>
                </div>

                {/* Review Text */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Your Feedback & Experience</label>
                  <textarea
                    required
                    rows={3}
                    placeholder="Share details about the doctors, staff behavior, ICU cleanliness, emergency speed..."
                    value={newReviewText}
                    onChange={(e) => setNewReviewText(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  ></textarea>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setWriteModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-blue-700 hover:bg-blue-800 text-white text-xs font-bold shadow-md transition"
                  >
                    Publish Review
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
