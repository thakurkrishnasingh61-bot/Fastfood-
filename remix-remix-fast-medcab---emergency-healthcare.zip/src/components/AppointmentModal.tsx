import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  Phone, 
  CheckCircle2, 
  Printer, 
  Copy, 
  Check, 
  AlertCircle
} from 'lucide-react';
import { SPECIALTIES_DATA, DOCTORS_DATA, HOSPITAL_INFO, Doctor } from '../data/hospitalData';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedDeptId?: string;
  preselectedDoctor?: Doctor | null;
  isHindi: boolean;
}

// Map doctor department string to clinical specialty id
const getDeptIdFromDoctor = (doc: Doctor): string => {
  const dept = doc.department.toLowerCase();
  if (dept.includes('gynecology') || dept.includes('maternity')) return 'gynecologist';
  if (dept.includes('eye') || dept.includes('ophthalmology')) return 'eye';
  if (dept.includes('dialysis') || dept.includes('renal')) return 'dialysis';
  if (dept.includes('modular') || dept.includes('surgery')) return 'ot';
  if (dept.includes('medicine') || dept.includes('physician')) return 'medicine';
  if (dept.includes('icu')) return 'icu';
  return 'emergency';
};

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  preselectedDeptId,
  preselectedDoctor,
  isHindi
}) => {
  const [patientName, setPatientName] = useState('');
  const [patientAge, setPatientAge] = useState('');
  const [patientGender, setPatientGender] = useState('Male');
  const [patientPhone, setPatientPhone] = useState('');
  const [patientLocation, setPatientLocation] = useState('Banthara');
  const [department, setDepartment] = useState('emergency');
  const [selectedDoctorId, setSelectedDoctorId] = useState('any');
  const [appointmentDate, setAppointmentDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [timeSlot, setTimeSlot] = useState('10:30 AM - 11:30 AM');
  const [symptoms, setSymptoms] = useState('');
  const [bookingCompleted, setBookingCompleted] = useState(false);
  const [appointmentPass, setAppointmentPass] = useState<{
    tokenNumber: string;
    patientName: string;
    patientAge: string;
    patientGender: string;
    patientPhone: string;
    patientLocation: string;
    department: string;
    doctor: string;
    date: string;
    timeSlot: string;
    symptoms: string;
    issuedAt: string;
  } | null>(null);
  const [copiedToken, setCopiedToken] = useState(false);

  // Sync state whenever modal opens or selection props change
  useEffect(() => {
    if (isOpen) {
      setBookingCompleted(false);
      setAppointmentPass(null);
      setCopiedToken(false);

      if (preselectedDoctor) {
        const matchingDept = getDeptIdFromDoctor(preselectedDoctor);
        setDepartment(matchingDept);
        setSelectedDoctorId(preselectedDoctor.id);
      } else if (preselectedDeptId) {
        setDepartment(preselectedDeptId);
        setSelectedDoctorId('any');
      } else {
        setDepartment('emergency');
        setSelectedDoctorId('any');
      }
    }
  }, [isOpen, preselectedDoctor, preselectedDeptId]);

  // Handle department change: adjust selected doctor if doctor does not belong to this department
  const handleDepartmentChange = (newDeptId: string) => {
    setDepartment(newDeptId);
    if (selectedDoctorId !== 'any') {
      const currentDoc = DOCTORS_DATA.find(d => d.id === selectedDoctorId);
      if (currentDoc && getDeptIdFromDoctor(currentDoc) !== newDeptId) {
        setSelectedDoctorId('any');
      }
    }
  };

  // Handle doctor change: auto-select matching department
  const handleDoctorChange = (doctorId: string) => {
    setSelectedDoctorId(doctorId);
    if (doctorId !== 'any') {
      const doc = DOCTORS_DATA.find(d => d.id === doctorId);
      if (doc) {
        setDepartment(getDeptIdFromDoctor(doc));
      }
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName.trim() || !patientPhone.trim()) return;

    const tokenNumber = `NSH-${Math.floor(1000 + Math.random() * 9000)}`;
    const matchedDoctor = DOCTORS_DATA.find(d => d.id === selectedDoctorId);
    const matchedDept = SPECIALTIES_DATA.find(s => s.id === department);

    const pass = {
      tokenNumber,
      patientName: patientName.trim(),
      patientAge: patientAge || 'Adult',
      patientGender,
      patientPhone: patientPhone.trim(),
      patientLocation: patientLocation || 'Banthara',
      department: matchedDept ? matchedDept.name : 'General OPD',
      doctor: matchedDoctor ? matchedDoctor.name : 'Consultant on Duty',
      date: appointmentDate,
      timeSlot,
      symptoms: symptoms.trim() || 'General Medical Consultation',
      issuedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setAppointmentPass(pass);
    setBookingCompleted(true);
  };

  const handleCopyPass = () => {
    if (!appointmentPass) return;
    const text = `NOVA SHEKHAR HOSPITAL - DIGITAL OPD PASS\nToken: ${appointmentPass.tokenNumber}\nPatient: ${appointmentPass.patientName} (${appointmentPass.patientAge}y, ${appointmentPass.patientGender})\nContact: ${appointmentPass.patientPhone}\nDept: ${appointmentPass.department}\nDoctor: ${appointmentPass.doctor}\nDate: ${appointmentPass.date} (${appointmentPass.timeSlot})\nHelpline: ${HOSPITAL_INFO.phone}\nMGIMT Campus, NH-25 Banthara, UP 226401`;
    
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text);
      setCopiedToken(true);
      setTimeout(() => setCopiedToken(false), 2500);
    }
  };

  const handlePrint = () => {
    try {
      window.print();
    } catch {
      handleCopyPass();
    }
  };

  const handleResetAndClose = () => {
    setBookingCompleted(false);
    setAppointmentPass(null);
    setPatientName('');
    setPatientPhone('');
    setSymptoms('');
    onClose();
  };

  // Doctors filtered by active department (or all)
  const availableDoctors = DOCTORS_DATA.filter(doc => getDeptIdFromDoctor(doc) === department);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8">
        
        {/* Close button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {bookingCompleted && appointmentPass ? (
          /* Confirmation & Digital OPD Slip */
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                Appointment Registered Successfully
              </span>
              <h3 className="text-2xl font-black text-slate-900">
                Digital OPD Pass Confirmed
              </h3>
              <p className="text-xs text-slate-500">
                Please show this pass at the Nova Shekhar Hospital OPD reception desk on arrival.
              </p>
            </div>

            {/* OPD Pass Card */}
            <div className="p-5 rounded-2xl bg-slate-50 border-2 border-dashed border-blue-200 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                <div>
                  <div className="font-extrabold text-blue-900 text-sm">NOVA SHEKHAR HOSPITAL</div>
                  <div className="text-[10px] text-slate-500">MGIMT Campus, Kanpur Road (NH-25), Banthara</div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block">Token Number</span>
                  <span className="text-base font-black text-blue-700">{appointmentPass.tokenNumber}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Patient Name:</span>
                  <span className="font-bold text-slate-800">{appointmentPass.patientName} ({appointmentPass.patientAge}y, {appointmentPass.patientGender})</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Contact Phone:</span>
                  <span className="font-bold text-slate-800">{appointmentPass.patientPhone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Department:</span>
                  <span className="font-bold text-blue-800">{appointmentPass.department}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Doctor / Specialist:</span>
                  <span className="font-bold text-slate-800">{appointmentPass.doctor}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Appointment Date:</span>
                  <span className="font-bold text-slate-800">{appointmentPass.date}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Reporting Time Slot:</span>
                  <span className="font-bold text-emerald-700">{appointmentPass.timeSlot}</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-blue-50/80 border border-blue-100 text-[11px] text-blue-900 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-blue-700 shrink-0" />
                <span>OPD counter closes at 5:00 PM. Please report 15 mins before your time slot.</span>
              </div>
            </div>

            {/* Pass Actions */}
            <div className="flex flex-wrap gap-2.5">
              <button
                onClick={handleCopyPass}
                className="flex-1 py-3 px-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                {copiedToken ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-700">Token Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy Token Pass</span>
                  </>
                )}
              </button>

              <button
                onClick={handlePrint}
                className="flex-1 py-3 px-3 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save</span>
              </button>

              <a
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="flex-1 py-3 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition shadow"
              >
                <Phone className="w-4 h-4" />
                <span>Call Hospital</span>
              </a>
            </div>

            <button
              onClick={handleResetAndClose}
              className="w-full py-2.5 text-center text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
            >
              Done & Return to Website
            </button>
          </div>
        ) : (
          /* Form View */
          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div>
              <span className="text-xs font-bold text-blue-700 uppercase tracking-wider">
                Nova Shekhar Hospital OPD
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-0.5">
                {isHindi ? "ऑनलाइन ओपीडी अपॉइंटमेंट" : "Book Doctor Consultation"}
              </h3>
              <p className="text-slate-500 text-xs mt-1">
                Consult with senior specialists in Emergency, Eye Hospital, Dialysis, ICU, Modular OT & Gynecology.
              </p>
            </div>

            {/* Department Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Select Clinical Department *
              </label>
              <select
                value={department}
                onChange={(e) => handleDepartmentChange(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium text-slate-800"
              >
                {SPECIALTIES_DATA.map((dept) => (
                  <option key={dept.id} value={dept.id}>
                    {dept.name} ({dept.timing})
                  </option>
                ))}
              </select>
            </div>

            {/* Doctor Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Preferred Doctor / Specialist
              </label>
              <select
                value={selectedDoctorId}
                onChange={(e) => handleDoctorChange(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white font-medium text-slate-800"
              >
                <option value="any">First Available Specialist on Duty</option>
                {availableDoctors.length > 0 ? (
                  availableDoctors.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.name} – {doc.experience}
                    </option>
                  ))
                ) : (
                  DOCTORS_DATA.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.name} – {doc.department}
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Patient Name & Age & Gender */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-6">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Patient Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Age
                </label>
                <input
                  type="number"
                  placeholder="e.g. 45"
                  value={patientAge}
                  onChange={(e) => setPatientAge(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="sm:col-span-3">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Gender
                </label>
                <select
                  value={patientGender}
                  onChange={(e) => setPatientGender(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            {/* Phone & Area */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mobile Number (Calling & SMS) *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 95550 14545"
                  value={patientPhone}
                  onChange={(e) => setPatientPhone(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Patient Location / Village
                </label>
                <input
                  type="text"
                  placeholder="e.g. Banthara, Khandedev, Unnao"
                  value={patientLocation}
                  onChange={(e) => setPatientLocation(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Date & Time Slot */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred OPD Date
                </label>
                <input
                  type="date"
                  value={appointmentDate}
                  onChange={(e) => setAppointmentDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Preferred Slot (Closes 5 PM)
                </label>
                <select
                  value={timeSlot}
                  onChange={(e) => setTimeSlot(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                >
                  <option value="09:30 AM - 10:30 AM">09:30 AM – 10:30 AM (Morning)</option>
                  <option value="10:30 AM - 11:30 AM">10:30 AM – 11:30 AM</option>
                  <option value="11:30 AM - 01:00 PM">11:30 AM – 01:00 PM (Midday)</option>
                  <option value="02:00 PM - 03:30 PM">02:00 PM – 03:30 PM (Afternoon)</option>
                  <option value="03:30 PM - 04:45 PM">03:30 PM – 04:45 PM (Before 5 PM Close)</option>
                  <option value="24x7 Emergency Casualty">24x7 Emergency Casualty (Urgent)</option>
                </select>
              </div>
            </div>

            {/* Symptoms Description */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Symptoms / Brief Description (Optional)
              </label>
              <textarea
                rows={2}
                placeholder="e.g., Cataract vision check, fever since 3 days, dialysis session booking, maternity antenatal check..."
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              ></textarea>
            </div>

            {/* Submit CTA */}
            <div className="pt-2 flex items-center justify-between gap-3">
              <a
                href={`tel:${HOSPITAL_INFO.phone.replace(/\s/g, '')}`}
                className="text-xs text-red-600 font-bold hover:underline flex items-center gap-1"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>Urgent? Call {HOSPITAL_INFO.phone}</span>
              </a>

              <button
                type="submit"
                className="px-6 py-3 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-sm shadow-md transition"
              >
                Generate OPD Pass
              </button>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
