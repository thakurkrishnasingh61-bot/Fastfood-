import React, { useEffect, useRef, useState, useMemo } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { 
  HospitalItem, 
  AmbulanceItem, 
  BloodDonorItem, 
  DoctorItem, 
  PharmacyItem, 
  DiagnosticLabItem,
  ServiceCategory 
} from '../types';
import { resolveFacilityCoordinates, getSearchLocationCenter, findClosestKnownCity } from '../data/geoCoordinates';
import { 
  Phone, 
  Navigation, 
  Bed, 
  ShieldCheck, 
  HeartPulse, 
  MapPin, 
  Layers,
  Crosshair,
  LocateFixed,
  Loader2,
  Star,
  Activity,
  Droplet,
  Ambulance,
  Hospital,
  Pill,
  FlaskConical,
  UserRoundCheck,
  Maximize2,
  Clock,
  Wind,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  ListFilter
} from 'lucide-react';

export interface UnifiedFacility {
  id: string;
  name: string;
  category: ServiceCategory;
  categoryLabel: string;
  subType: string;
  city: string;
  area: string;
  address: string;
  phone: string;
  emergencyPhone?: string;
  distanceKm: number;
  rating?: number;
  open247?: boolean;
  ayushmanBharat?: boolean;
  lat: number;
  lon: number;
  badgeColor: string;
  markerColor: string;
  iconSymbol: string;
  metrics: { label: string; value: string | number; highlight?: boolean }[];
  originalItem: HospitalItem | AmbulanceItem | BloodDonorItem | DoctorItem | PharmacyItem | DiagnosticLabItem;
}

interface FacilityMapViewProps {
  category: ServiceCategory;
  hospitals: HospitalItem[];
  ambulances: AmbulanceItem[];
  bloodDonors: BloodDonorItem[];
  doctors: DoctorItem[];
  pharmacies: PharmacyItem[];
  labs: DiagnosticLabItem[];
  searchLocation?: string;
  onSelectHospital?: (hospital: HospitalItem) => void;
  onTrackAmbulance?: (ambulance: AmbulanceItem) => void;
  onRequestBlood?: () => void;
  onSelectCategory?: (cat: ServiceCategory) => void;
  onLocationDetected?: (locationName: string) => void;
}

export const FacilityMapView: React.FC<FacilityMapViewProps> = ({
  category,
  hospitals,
  ambulances,
  bloodDonors,
  doctors,
  pharmacies,
  labs,
  searchLocation = '',
  onSelectHospital,
  onTrackAmbulance,
  onRequestBlood,
  onSelectCategory,
  onLocationDetected
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersGroupRef = useRef<L.LayerGroup | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);

  const [activeFacility, setActiveFacility] = useState<UnifiedFacility | null>(null);
  const [mapTheme, setMapTheme] = useState<'dark' | 'standard'>('dark');
  const [activeFilterCategory, setActiveFilterCategory] = useState<ServiceCategory | 'all'>('all');
  const [isLocatingUser, setIsLocatingUser] = useState<boolean>(false);
  const [userGpsLocation, setUserGpsLocation] = useState<{ lat: number; lon: number; label: string } | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);

  // Search center if known
  const searchCenter = useMemo(() => {
    return getSearchLocationCenter(searchLocation);
  }, [searchLocation]);

  // Transform all facilities into unified mappable objects
  const allMappableFacilities: UnifiedFacility[] = useMemo(() => {
    const list: UnifiedFacility[] = [];

    // 1. Hospitals
    hospitals.forEach((h, idx) => {
      const coord = resolveFacilityCoordinates(h, idx, searchCenter || undefined);
      const isApex = h.tier === 'AIIMS & Apex Central Institute' || h.name.toLowerCase().includes('apex');
      const isChc = h.tier === 'CHC/PHC Community Center' || h.name.toLowerCase().includes('chc') || h.name.toLowerCase().includes('phc');
      
      list.push({
        id: `hosp-${h.id}`,
        name: h.name,
        category: 'hospital',
        categoryLabel: 'Hospital',
        subType: h.tier || h.type,
        city: h.city,
        area: h.area,
        address: h.address,
        phone: h.phone,
        emergencyPhone: h.emergencyPhone || '108',
        distanceKm: h.distanceKm,
        rating: h.rating,
        open247: h.open247,
        ayushmanBharat: h.ayushmanBharat,
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: isApex ? '#ff3150' : isChc ? '#00ff9d' : '#00e5ff',
        markerColor: isApex ? '#ff3150' : isChc ? '#00ff9d' : '#00e5ff',
        iconSymbol: isApex ? '⚡' : isChc ? '🏥' : '✚',
        metrics: [
          { label: 'ICU Beds', value: `${h.icuBedsAvailable}/${h.totalIcuBeds}`, highlight: true },
          { label: 'General Beds', value: `${h.generalBedsAvailable ?? 30} Free` },
          { label: 'Oxygen Line', value: h.oxygenAvailable ? 'Available' : 'Standard' }
        ],
        originalItem: h
      });
    });

    // 2. Ambulances
    ambulances.forEach((a, idx) => {
      const coord = resolveFacilityCoordinates(
        { id: a.id, name: a.providerName, city: a.city, area: a.baseLocation, address: `${a.baseLocation}, ${a.city}` },
        idx,
        searchCenter || undefined
      );
      list.push({
        id: `amb-${a.id}`,
        name: a.providerName,
        category: 'ambulance',
        categoryLabel: 'Ambulance',
        subType: a.ambulanceType,
        city: a.city,
        area: a.baseLocation,
        address: `${a.baseLocation}, ${a.city}`,
        phone: a.phone,
        emergencyPhone: a.phone,
        distanceKm: a.distanceKm,
        rating: 4.9,
        open247: true,
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: '#ffd166',
        markerColor: '#ffd166',
        iconSymbol: '🚑',
        metrics: [
          { label: 'Vehicle No', value: a.vehicleNumber, highlight: true },
          { label: 'ETA', value: `~${a.etaMinutes} mins` },
          { label: 'Paramedic', value: a.driverName }
        ],
        originalItem: a
      });
    });

    // 3. Blood Donors & Banks
    bloodDonors.forEach((b, idx) => {
      const coord = resolveFacilityCoordinates(
        { id: b.id, name: b.name, city: b.city, area: b.area, address: `${b.area}, ${b.city}` },
        idx,
        searchCenter || undefined
      );
      list.push({
        id: `bld-${b.id}`,
        name: b.name,
        category: 'blood',
        categoryLabel: 'Blood Service',
        subType: `${b.bloodGroup} • ${b.donorType}`,
        city: b.city,
        area: b.area,
        address: `${b.area}, ${b.city}`,
        phone: b.phone,
        emergencyPhone: b.phone,
        distanceKm: b.distanceKm,
        rating: 4.8,
        open247: b.availability.includes('24/7'),
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: '#ff4d67',
        markerColor: '#ff3150',
        iconSymbol: '🩸',
        metrics: [
          { label: 'Blood Group', value: b.bloodGroup, highlight: true },
          { label: 'Stock / Units', value: `${b.unitsAvailable} Units` },
          { label: 'Availability', value: b.availability }
        ],
        originalItem: b
      });
    });

    // 4. Doctors
    doctors.forEach((d, idx) => {
      const coord = resolveFacilityCoordinates(
        { id: d.id, name: d.name, city: d.city, area: d.area, address: `${d.hospital}, ${d.area}, ${d.city}` },
        idx,
        searchCenter || undefined
      );
      list.push({
        id: `doc-${d.id}`,
        name: d.name,
        category: 'doctor',
        categoryLabel: 'Doctor / Clinic',
        subType: `${d.specialty} (${d.degrees})`,
        city: d.city,
        area: d.area,
        address: `${d.hospital}, ${d.area}, ${d.city}`,
        phone: d.phone,
        emergencyPhone: d.phone,
        distanceKm: d.distanceKm,
        rating: d.rating,
        open247: d.availableNow,
        ayushmanBharat: d.ayushmanEligible,
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: '#38bdf8',
        markerColor: '#38bdf8',
        iconSymbol: '👨‍⚕️',
        metrics: [
          { label: 'Specialty', value: d.specialty, highlight: true },
          { label: 'Fee', value: d.fee },
          { label: 'Status', value: d.availableNow ? 'Available' : 'On-Call' }
        ],
        originalItem: d
      });
    });

    // 5. Pharmacies
    pharmacies.forEach((p, idx) => {
      const coord = resolveFacilityCoordinates(
        { id: p.id, name: p.name, city: p.city, area: p.area, address: p.address },
        idx,
        searchCenter || undefined
      );
      list.push({
        id: `phm-${p.id}`,
        name: p.name,
        category: 'pharmacy',
        categoryLabel: 'Pharmacy / Chemist',
        subType: p.open247 ? '24x7 Emergency Chemist' : 'Medical Store',
        city: p.city,
        area: p.area,
        address: p.address,
        phone: p.phone,
        emergencyPhone: p.phone,
        distanceKm: p.distanceKm,
        rating: p.rating,
        open247: p.open247,
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: '#00ff9d',
        markerColor: '#00ff9d',
        iconSymbol: '💊',
        metrics: [
          { label: 'Hours', value: p.open247 ? '24/7 Open' : 'Day Store', highlight: true },
          { label: 'Delivery', value: p.homeDelivery ? `ETA ${p.deliveryEtaMinutes || 20}m` : 'Counter Only' },
          { label: 'Life Saving Meds', value: p.emergencyMedicinesStock ? 'In Stock' : 'Check' }
        ],
        originalItem: p
      });
    });

    // 6. Labs
    labs.forEach((l, idx) => {
      const coord = resolveFacilityCoordinates(
        { id: l.id, name: l.name, city: l.city, area: l.area, address: l.address },
        idx,
        searchCenter || undefined
      );
      list.push({
        id: `lab-${l.id}`,
        name: l.name,
        category: 'lab',
        categoryLabel: 'Diagnostic Lab',
        subType: l.open247EmergencyTesting ? '24x7 STAT Testing Lab' : 'Diagnostic Center',
        city: l.city,
        area: l.area,
        address: l.address,
        phone: l.phone,
        emergencyPhone: l.phone,
        distanceKm: l.distanceKm,
        rating: l.rating,
        open247: l.open247EmergencyTesting,
        lat: coord.lat,
        lon: coord.lon,
        badgeColor: '#c084fc',
        markerColor: '#c084fc',
        iconSymbol: '🧪',
        metrics: [
          { label: 'STAT Testing', value: l.open247EmergencyTesting ? '24x7 Ready' : 'Standard', highlight: true },
          { label: 'Turnaround', value: l.turnaroundTime },
          { label: 'Home Collection', value: l.homeSampleCollection ? 'Available' : 'At Lab' }
        ],
        originalItem: l
      });
    });

    return list;
  }, [hospitals, ambulances, bloodDonors, doctors, pharmacies, labs, searchCenter]);

  // Filter facilities by active category filter if specified
  const displayedFacilities = useMemo(() => {
    if (activeFilterCategory === 'all') {
      // By default prioritize current search category first, then others
      return allMappableFacilities;
    }
    return allMappableFacilities.filter(f => f.category === activeFilterCategory);
  }, [allMappableFacilities, activeFilterCategory]);

  // Update active filter category when main category prop changes
  useEffect(() => {
    setActiveFilterCategory(category);
  }, [category]);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Default center
    const initLat = searchCenter?.lat || displayedFacilities[0]?.lat || 26.8467;
    const initLon = searchCenter?.lon || displayedFacilities[0]?.lon || 80.9462;

    const map = L.map(mapContainerRef.current, {
      center: [initLat, initLon],
      zoom: 12,
      zoomControl: false,
      attributionControl: false
    });

    L.control.zoom({ position: 'topright' }).addTo(map);

    // High performance CartoDB / OSM tiles
    const tileUrl = mapTheme === 'dark' 
      ? 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png'
      : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';

    const tile = L.tileLayer(tileUrl, {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors | FAST MEDCAB'
    }).addTo(map);

    tileLayerRef.current = tile;

    const markersGroup = L.layerGroup().addTo(map);
    markersGroupRef.current = markersGroup;
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, [mapTheme]);

  // Update Markers on facilities change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const group = markersGroupRef.current;
    if (!map || !group) return;

    group.clearLayers();

    if (displayedFacilities.length === 0) return;

    const bounds = L.latLngBounds([]);

    displayedFacilities.forEach((facility) => {
      const latLng: [number, number] = [facility.lat, facility.lon];
      bounds.extend(latLng);

      const isSelected = activeFacility?.id === facility.id;

      const markerHtml = `
        <div class="group relative flex items-center justify-center cursor-pointer transition-transform duration-200 ${isSelected ? 'scale-125 z-50' : 'hover:scale-115'}" style="transform: translate(-50%, -50%);">
          <!-- Outer Pulsing Glow for Selected or 24/7 -->
          <div style="
            position: absolute;
            inset: -4px;
            border-radius: 9999px;
            background: ${facility.markerColor}35;
            animation: ${isSelected ? 'pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite' : 'none'};
          "></div>

          <!-- Main Pin Badge -->
          <div style="
            width: ${isSelected ? '44px' : '36px'};
            height: ${isSelected ? '44px' : '36px'};
            border-radius: 50%;
            background: #071722;
            border: 2.5px solid ${facility.markerColor};
            box-shadow: 0 0 16px ${facility.markerColor}99, 0 4px 10px rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: ${isSelected ? '18px' : '15px'};
            color: #ffffff;
            font-weight: 800;
          ">
            <span>${facility.iconSymbol}</span>
          </div>

          <!-- Mini Tooltip Tag -->
          <div style="
            position: absolute;
            bottom: -22px;
            background: rgba(4, 11, 18, 0.95);
            border: 1px solid rgba(255,255,255,0.2);
            color: #ffffff;
            font-size: 10px;
            font-weight: 700;
            padding: 1px 6px;
            border-radius: 6px;
            white-space: nowrap;
            box-shadow: 0 2px 8px rgba(0,0,0,0.5);
            pointer-events: none;
          ">
            ${facility.name.length > 18 ? facility.name.slice(0, 18) + '...' : facility.name}
          </div>
        </div>
      `;

      const customIcon = L.divIcon({
        className: 'facility-leaflet-marker',
        html: markerHtml,
        iconSize: [44, 44],
        iconAnchor: [22, 22]
      });

      const marker = L.marker(latLng, { icon: customIcon }).addTo(group);

      marker.on('click', () => {
        setActiveFacility(facility);
        map.setView(latLng, 15, { animate: true });
      });
    });

    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 15 });
    }

    if (displayedFacilities.length > 0 && !activeFacility) {
      setActiveFacility(displayedFacilities[0]);
    }
  }, [displayedFacilities, activeFacility]);

  // Render or remove user GPS location pin
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    if (userGpsLocation) {
      const userHtml = `
        <div class="relative flex items-center justify-center cursor-pointer" style="transform: translate(-50%, -50%);">
          <div style="
            position: absolute;
            inset: -10px;
            border-radius: 9999px;
            background: rgba(0, 229, 255, 0.35);
            animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
          "></div>
          <div style="
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #00e5ff;
            border: 3px solid #ffffff;
            box-shadow: 0 0 20px #00e5ff, 0 4px 12px rgba(0,0,0,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #040b12;
            font-size: 16px;
            font-weight: 900;
          ">
            🎯
          </div>
          <div style="
            position: absolute;
            top: 36px;
            background: rgba(4, 11, 18, 0.92);
            border: 1px solid #00e5ff;
            color: #00e5ff;
            font-size: 11px;
            font-weight: 800;
            padding: 2px 8px;
            border-radius: 9999px;
            white-space: nowrap;
            box-shadow: 0 2px 10px rgba(0,0,0,0.7);
            pointer-events: none;
          ">
            📍 My Location (${userGpsLocation.label})
          </div>
        </div>
      `;

      const userIcon = L.divIcon({
        className: 'user-gps-leaflet-marker',
        html: userHtml,
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      });

      const userMarker = L.marker([userGpsLocation.lat, userGpsLocation.lon], { icon: userIcon, zIndexOffset: 1000 }).addTo(map);
      userMarkerRef.current = userMarker;
    }
  }, [userGpsLocation]);

  // Recenter / Fit All Bounds handler
  const handleFitAll = () => {
    const map = mapInstanceRef.current;
    if (!map || displayedFacilities.length === 0) return;

    const bounds = L.latLngBounds([]);
    displayedFacilities.forEach(f => bounds.extend([f.lat, f.lon]));
    if (userGpsLocation) {
      bounds.extend([userGpsLocation.lat, userGpsLocation.lon]);
    }
    if (bounds.isValid()) {
      map.fitBounds(bounds, { padding: [50, 50], maxZoom: 14 });
    }
  };

  // Detect and Center on User's Current GPS Location
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert('Geolocation is not supported by your browser.');
      return;
    }

    setIsLocatingUser(true);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const { latitude, longitude } = pos.coords;
        const map = mapInstanceRef.current;

        // Instantly fly to the user coordinates
        if (map) {
          map.flyTo([latitude, longitude], 14, { duration: 1.2 });
        }

        let resolvedLocationName = '';

        try {
          // Attempt server reverse-geocode first for precision
          const res = await fetch(`/api/reverse-geocode?lat=${latitude}&lon=${longitude}`);
          if (res.ok) {
            const data = await res.json();
            if (data.placeName) {
              resolvedLocationName = data.placeName;
            } else if (data.district) {
              resolvedLocationName = data.district;
            }
          }
        } catch {
          // Network or server error fallback
        }

        // Fallback to nearest known Indian city if reverse-geocode fails or is empty
        if (!resolvedLocationName) {
          const nearest = findClosestKnownCity(latitude, longitude);
          if (nearest) {
            resolvedLocationName = nearest.city;
          } else {
            resolvedLocationName = `${latitude.toFixed(2)}°N, ${longitude.toFixed(2)}°E`;
          }
        }

        setUserGpsLocation({
          lat: latitude,
          lon: longitude,
          label: resolvedLocationName
        });

        setIsLocatingUser(false);

        // Notify parent App.tsx to update searchLocation and re-query live hospitals/facilities
        if (onLocationDetected && resolvedLocationName) {
          onLocationDetected(resolvedLocationName);
        }
      },
      (err) => {
        console.warn('Geolocation failed or permission denied:', err);
        setIsLocatingUser(false);
        // If denied, fallback to default Delhi center or notify smoothly
        alert('Could not access your location. Please check your browser location permissions.');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  };

  const handleSelectFacility = (fac: UnifiedFacility) => {
    setActiveFacility(fac);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([fac.lat, fac.lon], 15, { duration: 0.8 });
    }
  };

  const getMapsUrl = (name: string, address: string) => {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${name}, ${address}`)}`;
  };

  // Category counts for the map header filter
  const categoryCounts = useMemo(() => {
    return {
      all: allMappableFacilities.length,
      hospital: allMappableFacilities.filter(f => f.category === 'hospital').length,
      ambulance: allMappableFacilities.filter(f => f.category === 'ambulance').length,
      blood: allMappableFacilities.filter(f => f.category === 'blood').length,
      doctor: allMappableFacilities.filter(f => f.category === 'doctor').length,
      pharmacy: allMappableFacilities.filter(f => f.category === 'pharmacy').length,
      lab: allMappableFacilities.filter(f => f.category === 'lab').length,
    };
  }, [allMappableFacilities]);

  return (
    <div className="relative w-full rounded-3xl overflow-hidden border border-white/20 shadow-2xl bg-[#071722]">
      
      {/* MAP TOP TOOLBAR */}
      <div className="bg-[#030a10]/95 backdrop-blur-md px-4 py-3 border-b border-white/10 z-10 relative">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          
          {/* Status & Search Title */}
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00ff9d] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#00ff9d]"></span>
            </span>
            <div>
              <div className="text-xs sm:text-sm font-extrabold text-white tracking-wide flex items-center gap-2">
                <span>Interactive Emergency Radar</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#00e5ff]/15 text-[#00e5ff] border border-[#00e5ff]/30 font-mono">
                  {displayedFacilities.length} Pins
                </span>
              </div>
              <div className="text-[11px] text-gray-400">
                {searchLocation ? (
                  <span>Centered on: <strong className="text-white">"{searchLocation}"</strong></span>
                ) : (
                  <span>Pan-India Facility Network • Click any pin to inspect & call</span>
                )}
              </div>
            </div>
          </div>

          {/* Category Filter Chips Right on Map */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full scrollbar-none">
            <button
              type="button"
              onClick={() => setActiveFilterCategory('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${
                activeFilterCategory === 'all'
                  ? 'bg-white text-black border-white shadow-[0_0_10px_rgba(255,255,255,0.4)]'
                  : 'bg-white/5 text-gray-300 border-white/10 hover:border-white/30'
              }`}
            >
              All ({categoryCounts.all})
            </button>

            <button
              type="button"
              onClick={() => setActiveFilterCategory('hospital')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 flex items-center gap-1 ${
                activeFilterCategory === 'hospital'
                  ? 'bg-[#00e5ff] text-black border-[#00e5ff] shadow-[0_0_10px_rgba(0,229,255,0.4)]'
                  : 'bg-white/5 text-[#00e5ff] border-[#00e5ff]/30 hover:bg-[#00e5ff]/15'
              }`}
            >
              <span>🏥 Hospitals</span>
              <span className="opacity-75">({categoryCounts.hospital})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveFilterCategory('ambulance')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 flex items-center gap-1 ${
                activeFilterCategory === 'ambulance'
                  ? 'bg-[#ffd166] text-black border-[#ffd166] shadow-[0_0_10px_rgba(255,209,102,0.4)]'
                  : 'bg-white/5 text-[#ffd166] border-[#ffd166]/30 hover:bg-[#ffd166]/15'
              }`}
            >
              <span>🚑 Ambulance</span>
              <span className="opacity-75">({categoryCounts.ambulance})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveFilterCategory('blood')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 flex items-center gap-1 ${
                activeFilterCategory === 'blood'
                  ? 'bg-[#ff3150] text-white border-[#ff3150] shadow-[0_0_10px_rgba(255,49,80,0.4)]'
                  : 'bg-white/5 text-[#ff4d67] border-[#ff4d67]/30 hover:bg-[#ff4d67]/15'
              }`}
            >
              <span>🩸 Blood</span>
              <span className="opacity-75">({categoryCounts.blood})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveFilterCategory('doctor')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 flex items-center gap-1 ${
                activeFilterCategory === 'doctor'
                  ? 'bg-[#38bdf8] text-black border-[#38bdf8] shadow-[0_0_10px_rgba(56,189,248,0.4)]'
                  : 'bg-white/5 text-[#38bdf8] border-[#38bdf8]/30 hover:bg-[#38bdf8]/15'
              }`}
            >
              <span>👨‍⚕️ Doctors</span>
              <span className="opacity-75">({categoryCounts.doctor})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveFilterCategory('pharmacy')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all border shrink-0 flex items-center gap-1 ${
                activeFilterCategory === 'pharmacy'
                  ? 'bg-[#00ff9d] text-black border-[#00ff9d] shadow-[0_0_10px_rgba(0,255,157,0.4)]'
                  : 'bg-white/5 text-[#00ff9d] border-[#00ff9d]/30 hover:bg-[#00ff9d]/15'
              }`}
            >
              <span>💊 Chemist</span>
              <span className="opacity-75">({categoryCounts.pharmacy})</span>
            </button>
          </div>

          {/* Map Controls */}
          <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
            <button
              type="button"
              onClick={handleDetectLocation}
              disabled={isLocatingUser}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-all ${
                isLocatingUser
                  ? 'bg-[#00e5ff]/20 text-[#00e5ff] border-[#00e5ff]/40 animate-pulse cursor-wait'
                  : userGpsLocation
                  ? 'bg-[#00e5ff]/20 text-[#00e5ff] border-[#00e5ff] shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                  : 'bg-[#00e5ff]/15 hover:bg-[#00e5ff]/25 text-[#00e5ff] border-[#00e5ff]/40 hover:border-[#00e5ff]'
              }`}
              title="Center map on my GPS location & filter nearby facilities"
            >
              {isLocatingUser ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#00e5ff]" />
              ) : (
                <LocateFixed className="w-3.5 h-3.5 text-[#00e5ff]" />
              )}
              <span>{isLocatingUser ? 'Locating...' : 'My Current Location'}</span>
            </button>

            <button
              type="button"
              onClick={handleFitAll}
              className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1 border border-white/15 transition-all"
              title="Fit all markers in view"
            >
              <Crosshair className="w-3.5 h-3.5 text-[#00e5ff]" />
              <span>Fit All</span>
            </button>

            <button
              type="button"
              onClick={() => setMapTheme(prev => prev === 'dark' ? 'standard' : 'dark')}
              className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1 border border-white/15 transition-all"
              title="Toggle Tile Style"
            >
              <Layers className="w-3.5 h-3.5 text-[#ffd166]" />
              <span className="hidden sm:inline">{mapTheme === 'dark' ? 'Voyager' : 'Street'}</span>
            </button>
          </div>

        </div>
      </div>

      {/* MAP CANVAS CONTAINER */}
      <div 
        ref={mapContainerRef} 
        id="interactive-leaflet-map-canvas"
        className="w-full h-[540px] sm:h-[620px] bg-[#071722] z-0" 
      />

      {/* QUICK HORIZONTAL FACILITY PREVIEW TRAY (Bottom left/across) */}
      <div className="absolute top-16 left-3 right-3 sm:right-auto sm:max-w-md pointer-events-none z-10">
        <div className="flex items-center gap-1.5 overflow-x-auto p-1 pointer-events-auto scrollbar-none">
          {displayedFacilities.slice(0, 10).map((fac) => {
            const isSelected = activeFacility?.id === fac.id;
            return (
              <button
                key={fac.id}
                type="button"
                onClick={() => handleSelectFacility(fac)}
                className={`px-2.5 py-1 rounded-full text-xs font-bold whitespace-nowrap transition-all border backdrop-blur-md flex items-center gap-1 shrink-0 ${
                  isSelected
                    ? 'bg-[#071722] text-white border-[#00e5ff] shadow-[0_0_12px_rgba(0,229,255,0.5)] scale-105'
                    : 'bg-[#040b12]/80 text-gray-300 border-white/15 hover:border-white/30'
                }`}
              >
                <span>{fac.iconSymbol}</span>
                <span className="truncate max-w-[120px]">{fac.name}</span>
                <span className="text-[10px] text-gray-400">~{fac.distanceKm}km</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* ACTIVE FACILITY CARD OVERLAY */}
      {activeFacility && (
        <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:max-w-xl bg-[#071722]/95 backdrop-blur-xl border border-white/20 p-4 sm:p-5 rounded-2xl shadow-[0_12px_45px_rgba(0,0,0,0.85)] z-20 transition-all">
          <div className="flex items-start justify-between gap-3 mb-2">
            <div className="flex-1">
              {/* Category & Status Tags */}
              <div className="flex flex-wrap items-center gap-1.5 mb-1.5">
                <span 
                  className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider border"
                  style={{
                    backgroundColor: `${activeFacility.badgeColor}20`,
                    borderColor: `${activeFacility.badgeColor}60`,
                    color: activeFacility.badgeColor
                  }}
                >
                  {activeFacility.iconSymbol} {activeFacility.categoryLabel}
                </span>

                {activeFacility.open247 && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-[#00ff9d]/15 text-[#00ff9d] border border-[#00ff9d]/30 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> 24x7 Ready
                  </span>
                )}

                {activeFacility.ayushmanBharat && (
                  <span className="px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-[#00e5ff]/15 text-[#00e5ff] border border-[#00e5ff]/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> PM-JAY Free
                  </span>
                )}

                <span className="text-xs text-gray-400 font-bold ml-auto flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#00e5ff]" />
                  ~{activeFacility.distanceKm} km away
                </span>
              </div>

              {/* Title & Subtype */}
              <h3 className="text-sm sm:text-base font-extrabold text-white line-clamp-1">
                {activeFacility.name}
              </h3>
              <p className="text-xs text-[#a0b5c1] line-clamp-1 mt-0.5">
                {activeFacility.address}
              </p>
            </div>

            {activeFacility.rating && (
              <div className="flex items-center gap-1 bg-black/50 px-2 py-1 rounded-lg border border-white/10 text-xs font-bold text-[#ffd166] shrink-0">
                <Star className="w-3 h-3 fill-[#ffd166]" />
                <span>{activeFacility.rating}</span>
              </div>
            )}
          </div>

          {/* Metric Strip */}
          <div className="grid grid-cols-3 gap-2 my-3 py-2 px-3 rounded-xl bg-black/50 border border-white/10 text-center">
            {activeFacility.metrics.map((m, idx) => (
              <div key={idx}>
                <div className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">{m.label}</div>
                <div className={`text-xs sm:text-sm font-extrabold ${m.highlight ? 'text-[#00ff9d]' : 'text-white'} truncate`}>
                  {m.value}
                </div>
              </div>
            ))}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            {/* Direct Call Button */}
            <a
              href={`tel:${activeFacility.emergencyPhone || activeFacility.phone}`}
              className="flex-1 py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#ff3150] to-[#ff1744] hover:from-[#ff1744] hover:to-[#ff0033] text-white text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(255,49,80,0.4)] transition-all shrink-0"
            >
              <Phone className="w-3.5 h-3.5 animate-pulse" />
              <span>Call ({activeFacility.emergencyPhone || activeFacility.phone})</span>
            </a>

            {/* Contextual Action Button */}
            {activeFacility.category === 'hospital' && (
              <button
                type="button"
                onClick={() => onSelectHospital?.(activeFacility.originalItem as HospitalItem)}
                className="py-2.5 px-3 rounded-xl bg-[#00e5ff]/20 hover:bg-[#00e5ff]/30 text-[#00e5ff] border border-[#00e5ff]/40 text-xs font-extrabold flex items-center justify-center gap-1 transition-all shrink-0"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Full Sheet</span>
              </button>
            )}

            {activeFacility.category === 'ambulance' && (
              <button
                type="button"
                onClick={() => onTrackAmbulance?.(activeFacility.originalItem as AmbulanceItem)}
                className="py-2.5 px-3 rounded-xl bg-[#ffd166]/20 hover:bg-[#ffd166]/30 text-[#ffd166] border border-[#ffd166]/40 text-xs font-extrabold flex items-center justify-center gap-1 transition-all shrink-0"
              >
                <Ambulance className="w-3.5 h-3.5" />
                <span>Track GPS</span>
              </button>
            )}

            {activeFacility.category === 'blood' && (
              <button
                type="button"
                onClick={onRequestBlood}
                className="py-2.5 px-3 rounded-xl bg-[#ff4d67]/20 hover:bg-[#ff4d67]/30 text-[#ff4d67] border border-[#ff4d67]/40 text-xs font-extrabold flex items-center justify-center gap-1 transition-all shrink-0"
              >
                <Droplet className="w-3.5 h-3.5" />
                <span>Request Unit</span>
              </button>
            )}

            {/* Google Maps Route Button */}
            <a
              href={getMapsUrl(activeFacility.name, activeFacility.address)}
              target="_blank"
              rel="noreferrer"
              className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs flex items-center justify-center transition-all border border-white/15 shrink-0"
              title="Open Navigation in Google Maps"
            >
              <Navigation className="w-4 h-4 text-[#00ff9d]" />
            </a>
          </div>
        </div>
      )}

    </div>
  );
};
