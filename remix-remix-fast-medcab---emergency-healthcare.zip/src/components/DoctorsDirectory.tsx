import React, { useState } from 'react';
import { 
  Stethoscope, 
  Calendar, 
  Star, 
  Clock, 
  Languages, 
  Award, 
  CheckCircle2, 
  Phone,
  Video,
  Building
} from 'lucide-react';
import { SURYA_DOCTORS, SURYA_HOSPITAL } from '../data/suryaHospitalData';
import { SuryaDoctorProfile } from '../types';

interface DoctorsDirectoryProps {
  onBookDoctor: (doctorName: string, department: string) => void;
  isHindi: boolean;
}

export const DoctorsDirectory: React.FC<DoctorsDirectoryProps> = ({
  onBookDoctor,
  isHindi
}) => {
  const [selectedDept, setSelectedDept] = useState<string>('All');

  const departments = [
    'All',
    'Infectious Diseases & Tropical Medicine',
    'Pulmonology & Respiratory Medicine',
    '24/7 Emergency & Casualty',
    'Nephrology & Dialysis Unit'
  ];

  const filteredDoctors = selectedDept === 'All'
    ? SURYA_DOCTORS
    : SURYA_DOCTORS.filter(d => d.department.includes(selectedDept.split(' ')[0]));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* Header Banner */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-900 border border-amber-200 mb-3">
          <Stethoscope className="w-3.5 h-3.5 text-amber-700" />
          <span>{isHindi ? "वरिष्ठ चिकित्सक एवं विशेषज्ञ पैनल" : "Surya Hospital Clinical Specialist Faculty"}</span>
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-3">
          {isHindi ? "संक्रामक रोग एवं पल्मोनोलॉजी विशेषज्ञ" : "Specialist Doctors & Critical Care Faculty"}
        </h2>
        <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
          {isHindi
            ? "हंतावायरस, गंभीर श्वसन विफलता, जूनोटिक बुखार और आईसीयू प्रबंधन में अग्रणी राष्ट्रीय और अंतरराष्ट्रीय स्तर पर प्रशिक्षित विशेषज्ञ।"
            : "Consult with our board-certified infectious disease epidemiologists, pulmonologists, and emergency intensivists for in-clinic OPD or priority teleconsultation."}
        </p>
      </div>

      {/* Department Filter Bar */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-8">
        {departments.map((dept) => (
          <button
            key={dept}
            onClick={() => setSelectedDept(dept)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition border whitespace-nowrap ${
              selectedDept === dept
                ? 'bg-amber-500 text-white border-amber-500 shadow-sm'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {dept === 'All' ? 'All Specialists' : dept.split('&')[0].trim()}
          </button>
        ))}
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        {filteredDoctors.map((doctor) => (
          <div
            key={doctor.id}
            className="bg-white rounded-3xl border border-slate-200 hover:border-amber-400 p-6 sm:p-7 transition-all shadow-sm hover:shadow-md flex flex-col justify-between"
          >
            <div>
              {/* Doctor Top Row: Photo, Info, Rating */}
              <div className="flex items-start gap-4 mb-4">
                <img
                  src={doctor.image}
                  alt={doctor.name}
                  className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-amber-500/30 flex-shrink-0 shadow-sm"
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 px-2 py-0.5 rounded">
                      {doctor.experienceYears}+ Yrs Experience
                    </span>
                    <div className="flex items-center gap-1 text-xs font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500" />
                      <span>{doctor.rating}</span>
                      <span className="text-slate-400 font-normal">({doctor.reviewsCount})</span>
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-slate-900 truncate">
                    {isHindi && doctor.hindiName ? doctor.hindiName : doctor.name}
                  </h3>
                  <p className="text-xs text-amber-700 font-semibold mb-1 truncate">{doctor.designation}</p>
                  <p className="text-[11px] text-slate-500 truncate">{doctor.qualification}</p>
                </div>
              </div>

              {/* Department & OPD Timings */}
              <div className="bg-slate-50 rounded-xl p-3 mb-4 space-y-1.5 text-xs text-slate-700">
                <div className="flex items-center gap-2">
                  <Building className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span className="font-semibold text-slate-800">{doctor.department}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span>OPD: <strong>{doctor.opdTimings}</strong></span>
                </div>
                <div className="flex items-center gap-2">
                  <Languages className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                  <span>Languages: {doctor.languages.join(', ')}</span>
                </div>
              </div>

              {/* Clinical Focus Areas */}
              <div className="mb-4">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block mb-2">
                  Clinical Expertise:
                </span>
                <ul className="space-y-1">
                  {doctor.focusAreas.map((area, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 text-xs text-slate-600">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>{area}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Actions: Fee & Book Button */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
              <div>
                <span className="text-[10px] text-slate-500 uppercase font-semibold block">OPD Consultation</span>
                <span className="text-lg font-extrabold text-slate-900">{doctor.consultationFee}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onBookDoctor(doctor.name, doctor.department)}
                  className="bg-amber-600 hover:bg-amber-700 text-white text-xs sm:text-sm font-bold px-4 py-2 rounded-xl transition shadow-sm flex items-center gap-1.5"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{isHindi ? "अपॉइंटमेंट लें" : "Book OPD Slot"}</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Surya Hospital Emergency Contact Strip */}
      <div className="bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md">
        <div>
          <h3 className="font-bold text-lg mb-1">
            {isHindi ? "आपातकालीन या गंभीर श्वसन समस्या है?" : "Need Immediate Clinical or ICU Assistance?"}
          </h3>
          <p className="text-xs sm:text-sm text-amber-100">
            {isHindi
              ? "सूर्य हॉस्पिटल आपातकालीन विभाग 24 घंटे सातों दिन खुला है। गंभीर मामलों के लिए सीधा संपर्क करें।"
              : "Our casualty and trauma resuscitation team operates 24/7 with zero admission delays for acute cases."}
          </p>
        </div>
        <a
          href={`tel:${SURYA_HOSPITAL.emergencyPhone.replace(/\s+/g, '')}`}
          className="bg-white text-amber-900 hover:bg-amber-50 font-extrabold px-6 py-3 rounded-xl text-sm transition shadow flex items-center gap-2 whitespace-nowrap"
        >
          <Phone className="w-4 h-4 text-amber-700" />
          <span>Call: {SURYA_HOSPITAL.emergencyPhone}</span>
        </a>
      </div>

    </div>
  );
};
