export type ServiceCategory = 
  | 'hospital' 
  | 'ambulance' 
  | 'blood' 
  | 'doctor' 
  | 'pharmacy' 
  | 'lab';

export type HospitalTier = 
  | 'Apex / AIIMS' 
  | 'AIIMS & Apex Central Institute'
  | 'Govt Medical College' 
  | 'District Hospital' 
  | 'Community Health Center (CHC)' 
  | 'CHC/PHC Community Center'
  | 'Primary Health Center (PHC)' 
  | 'Private Multi-Specialty';

export interface HospitalItem {
  id: string;
  name: string;
  hindiName?: string;
  type: string; // e.g. 'Apex National Institute (AIIMS)', 'Govt Medical College', 'District Civil Hospital', 'Sub-Divisional / CHC', 'Primary Health Centre (PHC)', 'Super Specialty'
  city: string;
  district?: string;
  area: string;
  address: string;
  distanceKm: number;
  rating: number;
  phone: string;
  emergencyPhone: string;
  open247: boolean;
  icuBedsAvailable: number;
  totalIcuBeds: number;
  oxygenAvailable: boolean;
  bloodBankAttached: boolean;
  traumaCenter: boolean;
  specialties: string[];
  ambulanceOnStandby: boolean;
  verified: boolean;
  state?: string;
  tier?: HospitalTier;
  pincode?: string;
  ayushmanBharat?: boolean;
  bedsCapacity?: number | string;
  
  // Comprehensive detailed fields for full hospital information sheet
  generalBedsAvailable?: number;
  totalGeneralBeds?: number;
  oxygenBedsAvailable?: number;
  totalOxygenBeds?: number;
  ventilatorBedsAvailable?: number;
  totalVentilators?: number;
  nicuBedsAvailable?: number;
  totalNicuBeds?: number;
  facilitiesList?: string[];
  schemesAccepted?: string[];
  insurancePartners?: string[];
  casualtyHelpline?: string;
  ambulanceHelpline?: string;
  bloodBankHelpline?: string;
  cmoName?: string;
  opdTimings?: string;
  consultationFee?: string;
  admissionDeposit?: string;
  description?: string;
  landmarks?: string;
  establishedYear?: number;
  lat?: number;
  lon?: number;
}

export interface AmbulanceItem {
  id: string;
  vehicleNumber: string;
  providerName: string;
  ambulanceType: 'ALS (Advanced Life Support)' | 'BLS (Basic Life Support)' | 'ICU on Wheels (Ventilator)' | 'Neonatal Emergency' | 'Air Ambulance';
  driverName: string;
  phone: string;
  etaMinutes: number;
  distanceKm: number;
  baseLocation: string;
  city: string;
  state?: string;
  facilities: string[];
  priceEstimate: string;
  available: boolean;
  verified: boolean;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface BloodDonorItem {
  id: string;
  name: string;
  bloodGroup: BloodGroup;
  donorType: 'Individual Donor' | 'Blood Bank Stock' | 'Red Cross Center';
  unitsAvailable: number;
  city: string;
  area: string;
  state?: string;
  distanceKm: number;
  phone: string;
  verified: boolean;
  lastDonation: string;
  availability: 'Available Immediately' | 'On Call' | '24/7 Supply';
}

export interface DoctorItem {
  id: string;
  name: string;
  specialty: string;
  degrees: string;
  experienceYears: number;
  hospital: string;
  city: string;
  area: string;
  state?: string;
  distanceKm: number;
  phone: string;
  fee: string;
  availableNow: boolean;
  consultationType: 'In-Clinic' | 'Emergency On-Call' | 'Tele-Consultation';
  rating: number;
  verified: boolean;
  languages?: string[];
  doctorType?: 'Govt Senior Specialist' | 'Private Super-Specialist' | 'District Chief Medical Officer' | 'Community Physician';
  ayushmanEligible?: boolean;
  opdTimings?: string;
  teleConsultation?: boolean;
}

export interface PharmacyItem {
  id: string;
  name: string;
  address: string;
  city: string;
  area: string;
  distanceKm: number;
  phone: string;
  open247: boolean;
  homeDelivery: boolean;
  deliveryEtaMinutes?: number;
  emergencyMedicinesStock: boolean;
  rating: number;
  verified: boolean;
}

export interface DiagnosticLabItem {
  id: string;
  name: string;
  address: string;
  city: string;
  area: string;
  distanceKm: number;
  phone: string;
  turnaroundTime: string;
  homeSampleCollection: boolean;
  testsAvailable: string[];
  open247EmergencyTesting: boolean;
  rating: number;
  verified: boolean;
}

export interface BloodRequestSubmission {
  id: string;
  patientName: string;
  hospitalName: string;
  bloodGroup: BloodGroup;
  unitsNeeded: number;
  contactNumber: string;
  city: string;
  urgency: 'Critical (Under 1 hr)' | 'High (Today)' | 'Standard (Within 24 hrs)';
  createdAt: string;
}

export type DiseaseCategory = 
  | 'All'
  | 'Viral & Infectious'
  | 'Respiratory'
  | 'Zoonotic & Vector-Borne'
  | 'Cardiovascular & Renal'
  | 'Metabolic & Lifestyle';

export interface DiseaseSummary {
  id: string;
  name: string;
  scientificName?: string;
  hindiName: string;
  category: DiseaseCategory;
  shortDesc: string;
  hindiShortDesc?: string;
  transmission: string;
  incubation: string;
  commonSymptoms: string[];
  keyPrevention: string[];
  severity: 'Mild to Moderate' | 'Moderate to Severe' | 'Critical / Life-Threatening';
  hospitalDepartment: string;
  isFeatured?: boolean;
}

export interface HealthPackageItem {
  id: string;
  name: string;
  hindiName: string;
  category: string;
  tagline: string;
  price: number;
  originalPrice: number;
  discountPercentage: number;
  turnaroundTime: string;
  fastingRequired: string;
  testsCount: number;
  parameters: string[];
  popular?: boolean;
  recommendedFor: string;
}

export interface SuryaDoctorProfile {
  id: string;
  name: string;
  hindiName?: string;
  qualification: string;
  designation: string;
  department: string;
  experienceYears: number;
  languages: string[];
  opdTimings: string;
  rating: number;
  reviewsCount: number;
  consultationFee: string;
  focusAreas: string[];
  image: string;
}

